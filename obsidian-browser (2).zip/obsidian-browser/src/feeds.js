// News (public RSS) and prices (CoinGecko public API). Cached in the main process.
const FEEDS = [
  { name: 'CoinDesk', url: 'https://www.coindesk.com/arc/outboundfeeds/rss/' },
  { name: 'Cointelegraph', url: 'https://cointelegraph.com/rss' },
  { name: 'Decrypt', url: 'https://decrypt.co/feed' }
];
const COINS = [
  { id: 'bitcoin', sym: 'BTC', words: ['bitcoin', 'btc'] },
  { id: 'ethereum', sym: 'ETH', words: ['ethereum', 'eth', 'ether'] },
  { id: 'binancecoin', sym: 'BNB', words: ['bnb', 'bnb chain'] },
  { id: 'solana', sym: 'SOL', words: ['solana', 'sol'] },
  { id: 'ripple', sym: 'XRP', words: ['xrp', 'ripple'] },
  { id: 'dogecoin', sym: 'DOGE', words: ['dogecoin', 'doge'] },
  { id: 'the-open-network', sym: 'TON', words: ['toncoin', 'ton'] },
  { id: 'tron', sym: 'TRX', words: ['tron', 'trx'] }
];

function coinsIn(text) {
  const t = ' ' + text.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ') + ' ';
  return COINS.filter(c => c.words.some(w => t.includes(' ' + w + ' '))).map(c => c.id);
}

const tag = (b, n) => { const m = b.match(new RegExp(`<${n}[^>]*>([\\s\\S]*?)</${n}>`)); return m ? m[1] : ''; };
const clean = s => s.replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&#8217;|&#039;/g, '’')
  .replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();

function parseRss(xml, source) {
  const out = []; const re = /<item>([\s\S]*?)<\/item>/g; let m;
  while ((m = re.exec(xml)) && out.length < 12) {
    const title = clean(tag(m[1], 'title')), link = clean(tag(m[1], 'link'));
    if (!title || !/^https?:\/\//.test(link)) continue;
    const date = Date.parse(clean(tag(m[1], 'pubDate'))) || 0;
    out.push({ title, link, source, date, coins: coinsIn(title) });
  }
  return out;
}

let newsCache = { at: 0, data: [] }, priceCache = { at: 0, data: {} };

async function getNews() {
  if (Date.now() - newsCache.at < 5 * 60e3 && newsCache.data.length) return newsCache.data;
  const res = await Promise.allSettled(FEEDS.map(async f => {
    const r = await fetch(f.url, { headers: { 'User-Agent': 'ObsidianBrowser/0.1' }, signal: AbortSignal.timeout(8000) });
    return parseRss(await r.text(), f.name);
  }));
  const data = res.filter(r => r.status === 'fulfilled').flatMap(r => r.value).sort((a, b) => b.date - a.date).slice(0, 40);
  if (data.length) newsCache = { at: Date.now(), data };
  return newsCache.data;
}

async function getPrices() {
  if (Date.now() - priceCache.at < 60e3 && Object.keys(priceCache.data).length) return priceCache.data;
  try {
    const ids = COINS.map(c => c.id).join(',');
    const r = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&sparkline=true&price_change_percentage=24h`,
      { signal: AbortSignal.timeout(8000) });
    const j = await r.json();
    const data = {};
    for (const c of COINS) {
      const m = Array.isArray(j) && j.find(x => x.id === c.id);
      if (!m) continue;
      const sp = (m.sparkline_in_7d && m.sparkline_in_7d.price) || [];
      data[c.id] = { sym: c.sym, name: m.name, usd: m.current_price, change: m.price_change_percentage_24h_in_currency ?? m.price_change_percentage_24h ?? 0,
        spark: sp.filter((_, i) => i % 4 === 0) };
    }
    if (Object.keys(data).length) priceCache = { at: Date.now(), data };
  } catch {}
  return priceCache.data;
}

let fngCache = { at: 0, data: null };
async function getFearGreed() {
  if (Date.now() - fngCache.at < 30 * 60e3 && fngCache.data) return fngCache.data;
  try {
    const r = await fetch('https://api.alternative.me/fng/?limit=1', { signal: AbortSignal.timeout(8000) });
    const j = await r.json(); const d = j.data && j.data[0];
    if (d) fngCache = { at: Date.now(), data: { value: Number(d.value), label: d.value_classification } };
  } catch {}
  return fngCache.data;
}

module.exports = { getNews, getPrices, getFearGreed, coinsIn, COINS };
