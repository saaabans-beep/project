// Exchange-neutral partner layer.
// To switch partner (e.g. Binance -> Bybit) change `featured` only.
// `register` links are PLACEHOLDERS: put your real referral code in `ref`
// and verify the exact URL format in the exchange's affiliate program.
module.exports = {
  featured: 'binance',
  searchUrl: 'https://duckduckgo.com/?q=',
  exchanges: {
    binance: { name: 'Binance', url: 'https://www.binance.com/', register: 'https://www.binance.com/register?ref={ref}', ref: '' },
    bybit:   { name: 'Bybit',   url: 'https://www.bybit.com/',   register: 'https://www.bybit.com/invite?ref={ref}',    ref: '' },
    okx:     { name: 'OKX',     url: 'https://www.okx.com/',     register: 'https://www.okx.com/join/{ref}',            ref: '' }
  }
};
