// Exposes a small, whitelisted API ONLY to Obsidian's own pages (file://), never to websites.
const { contextBridge, ipcRenderer, webFrame } = require('electron');
const INVOKE = new Set(['state:get','tab:new','tab:close','tab:select','nav:go','nav:back','nav:forward','nav:reload',
  'ui:side','data:news','data:prices','data:config','shield:proceed','shield:home','alerts:list','alerts:add','alerts:remove','data:fng','data:stats','ui:overlay']);
const ON = new Set(['state','alert','palette']);
if (location.protocol === 'file:') {
  contextBridge.exposeInMainWorld('obsidian', {
    invoke: (ch, ...a) => INVOKE.has(ch) ? ipcRenderer.invoke(ch, ...a) : Promise.reject(new Error('blocked')),
    on: (ch, fn) => { if (ON.has(ch)) ipcRenderer.on(ch, (_e, d) => fn(d)); }
  });
}

// ---- Website pages (http/https): fingerprint hardening + seed-phrase form detector ----
if (/^https?:$/.test(location.protocol)) {
  try {
    webFrame.executeJavaScript(`(() => { try {
      const def = (o, k, v) => Object.defineProperty(o, k, { get: () => v, configurable: true });
      def(Navigator.prototype, 'hardwareConcurrency', 4);
      def(Navigator.prototype, 'deviceMemory', 8);
      const orig = HTMLCanvasElement.prototype.toDataURL;
      HTMLCanvasElement.prototype.toDataURL = function (...a) {
        try { const c = this.getContext('2d');
          if (c && this.width > 0 && this.height > 0 && this.width * this.height < 4e6) {
            const x = Math.floor(Math.random() * this.width), y = Math.floor(Math.random() * this.height);
            const d = c.getImageData(x, y, 1, 1); d.data[0] ^= 1; c.putImageData(d, x, y); } } catch (e) {}
        return orig.apply(this, a); };
    } catch (e) {} })()`);
  } catch {}

  let sent = false;
  const KW = /(seed|recovery|secret) ?(phrase|words)|private key|12[- ]word|24[- ]word|сид[- ]?фраз|секретн\S* фраз|приватн\S* ключ|мнемоническ/i;
  const scan = () => {
    if (sent || !document.body) return;
    const text = (document.body.innerText || '').slice(0, 20000);
    if (KW.test(text) && document.querySelector('textarea, input[type=password]')) { sent = true; ipcRenderer.send('shield:seed'); }
  };
  window.addEventListener('DOMContentLoaded', () => { setTimeout(scan, 1500); setTimeout(scan, 6000); });
}
