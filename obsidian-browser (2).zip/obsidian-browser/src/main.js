const { app, BrowserWindow, WebContentsView, ipcMain, clipboard, Notification, Menu, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const { assess, isTracker, isAddress } = require('./shield');
const feeds = require('./feeds');
const blocklist = require('./blocklist');

const UI = path.join(__dirname, 'ui');
const TOP = 88, SIDE = 340; // must match ui/theme.css
const tabs = new Map(); let order = [], activeId = null, nextId = 1, sideOpen = true, blocked = 0, win;
const prepared = new WeakSet();
const stats = { trackers: 0, threats: 0, https: 0, downloads: 0 };
const events = []; let syncT;
const hostOf = u => { try { return new URL(u).hostname; } catch { return ''; } };
const sync = () => { clearTimeout(syncT); syncT = setTimeout(() => pushState(), 800); };
function log(level, text) { events.unshift({ t: Date.now(), level, text }); if (events.length > 50) events.pop(); sync(); }
const RISKY_FILE = /\.(exe|msi|bat|cmd|scr|ps1|vbs|jar|apk|dmg|pkg|com|lnk|hta|reg)$/i;
const tabByWc = id => [...tabs.values()].find(t => t.view.webContents.id === id);

function prepareSession(ses) {
  if (prepared.has(ses)) return; prepared.add(ses);
  ses.setUserAgent(ses.getUserAgent().replace(/\s(Electron|obsidian-browser)\/\S+/g, '')); // do not announce "Electron"
  const allowed = new Set(['clipboard-sanitized-write', 'fullscreen']); // everything else (camera, mic, geo, notifications...) is denied
  ses.setPermissionRequestHandler((_wc, perm, cb) => cb(allowed.has(perm)));
  ses.setPermissionCheckHandler((_wc, perm) => allowed.has(perm));

  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => {
    let u; try { u = new URL(d.url); } catch { return cb({}); }
    if (isTracker(u.hostname)) { stats.trackers++; sync(); return cb({ cancel: true }); }
    if (blocklist.check(u.hostname)) {
      if (d.resourceType !== 'mainFrame') { stats.threats++; log('danger', 'Заблокирован запрос к фишинговому домену ' + u.hostname); return cb({ cancel: true }); }
      const tab = tabByWc(d.webContentsId);
      if (tab && !tab.allowed.has(u.hostname)) { // backstop for redirects that slipped past the navigation guards
        stats.threats++; log('danger', 'Остановлен переход на фишинговый сайт ' + u.hostname);
        setImmediate(() => showWarning(tab, d.url, assess(d.url))); return cb({ cancel: true });
      }
    }
    if (u.protocol === 'http:' && d.resourceType === 'mainFrame' && !/^(localhost|127\.0\.0\.1)$/.test(u.hostname)) {
      stats.https++; u.protocol = 'https:'; return cb({ redirectURL: u.toString() }); // HTTPS-only
    }
    cb({});
  });

  ses.webRequest.onBeforeSendHeaders((d, cb) => {
    const h = d.requestHeaders; h['Sec-GPC'] = '1'; h['DNT'] = '1';
    if (h.Referer) { try { const r = new URL(h.Referer); if (r.origin !== new URL(d.url).origin) h.Referer = r.origin + '/'; } catch {} } // cross-site: origin only
    cb({ requestHeaders: h });
  });

  ses.on('will-download', (_e, item) => {
    const name = item.getFilename();
    if (RISKY_FILE.test(name)) {
      const r = dialog.showMessageBoxSync(win, { type: 'warning', buttons: ['Отменить', 'Всё равно скачать'], defaultId: 0, cancelId: 0,
        title: 'Obsidian Shield', message: 'Опасный тип файла', detail: `${name}\n\nЭто исполняемый файл. Через такие файлы распространяются кошельки-подделки и майнеры. Скачивайте программы только с официального сайта разработчика.` });
      if (r === 0) { item.cancel(); stats.threats++; log('danger', 'Отменено скачивание: ' + name); return; }
      log('warn', 'Скачан исполняемый файл: ' + name);
    } else log('ok', 'Скачивание: ' + name);
    stats.downloads++;
  });
}

function normalize(raw) {
  raw = raw.trim();
  if (/^https?:\/\//i.test(raw)) return raw;
  if (/^localhost(:\d+)?(\/|$)/.test(raw)) return 'http://' + raw;
  if (!raw.includes(' ') && /^[^\s]+\.[^\s]{2,}$/.test(raw)) return 'https://' + raw;
  return config.searchUrl + encodeURIComponent(raw);
}

function shownUrl(tab) {
  const u = tab.view.webContents.getURL();
  if (u.startsWith('file:')) return tab.warnUrl && u.includes('warning.html') ? tab.warnUrl : '';
  return u;
}
const riskOf = tab => {
  const s = shownUrl(tab); if (!s) return { level: 'local', score: 0, reasons: [] };
  const r = assess(s);
  if (tab.flags.seed) {
    r.reasons.unshift('Страница просит seed-фразу или приватный ключ. Настоящие биржи и кошельки не запрашивают их на сайте.');
    r.level = r.level === 'official' ? 'warn' : 'danger';
  }
  return r;
};

function pushState() {
  if (!win || win.isDestroyed()) return;
  const t = tabs.get(activeId);
  win.webContents.send('state', {
    tabs: order.map(id => { const x = tabs.get(id); return { id, title: x.title, url: shownUrl(x), crypto: x.crypto, level: riskOf(x).level }; }),
    activeId, side: sideOpen, stats, events: events.slice(0, 10),
    risk: t ? riskOf(t) : null,
    coins: t ? feeds.coinsIn(t.title + ' ' + shownUrl(t)) : []
  });
}

function layout() {
  if (!win || win.isDestroyed()) return;
  const [w, h] = win.getContentSize(); const t = tabs.get(activeId);
  if (t) t.view.setBounds({ x: 0, y: TOP, width: Math.max(0, w - (sideOpen ? SIDE : 0)), height: Math.max(0, h - TOP) });
}

function showWarning(tab, url, r) {
  tab.warnUrl = url;
  tab.view.webContents.loadFile(path.join(UI, 'warning.html'), { query: { url, reasons: JSON.stringify(r.reasons) } }).catch(() => {});
}

function go(tab, raw) {
  const wc = tab.view.webContents;
  if (!raw) { tab.warnUrl = null; return wc.loadFile(path.join(UI, 'newtab.html')).catch(() => {}); }
  const url = normalize(raw), r = assess(url);
  if (r.level === 'danger' && !tab.allowed.has(new URL(url).hostname)) return showWarning(tab, url, r);
  tab.warnUrl = null; wc.loadURL(url).catch(() => {});
}

function select(id) {
  const prev = tabs.get(activeId);
  if (prev) win.contentView.removeChildView(prev.view);
  activeId = id; win.contentView.addChildView(tabs.get(id).view); layout(); pushState();
}

function createTab(url, crypto = false) {
  const id = nextId++;
  const view = new WebContentsView({ webPreferences: {
    partition: crypto ? 'persist:crypto' : `tab-${id}`, // every normal tab = its own throwaway storage
    sandbox: true, contextIsolation: true, nodeIntegration: false, preload: path.join(__dirname, 'preload.js') } });
  const tab = { id, view, title: 'Новая вкладка', crypto, allowed: new Set(), warnUrl: null, flags: {} };
  const wc = view.webContents;
  prepareSession(wc.session); wc.setWebRTCIPHandlingPolicy('disable_non_proxied_udp'); tabs.set(id, tab); order.push(id);

  wc.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) createTab(url, tab.crypto); return { action: 'deny' }; });
  const guard = (e, url) => {
    if (url.startsWith('file:')) { if (!wc.getURL().startsWith('file:')) e.preventDefault(); return; }
    if (!/^https?:/.test(url)) return e.preventDefault();
    const r = assess(url);
    if (r.level === 'danger' && !tab.allowed.has(new URL(url).hostname)) { e.preventDefault(); showWarning(tab, url, r); }
  };
  wc.on('will-navigate', guard); wc.on('will-redirect', guard);
  wc.on('page-title-updated', (_e, t) => { tab.title = t; pushState(); });
  wc.on('did-navigate', () => { tab.flags = {}; pushState(); }); wc.on('did-navigate-in-page', pushState);
  wc.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && i.key === 'F12') { wc.toggleDevTools(); return; }
    if (i.type !== 'keyDown' || !(i.control || i.meta)) return;
    if (i.key === 't') { e.preventDefault(); createTab(); }
    if (i.key === 'w') { e.preventDefault(); closeTab(id); }
    if (i.key === 'k') { e.preventDefault(); win.webContents.focus(); win.webContents.send('palette'); }
    if (i.key === 'l') { e.preventDefault(); win.webContents.focus(); win.webContents.send('state', null); }
  });

  select(id); go(tab, url);
}

function closeTab(id) {
  const tab = tabs.get(id); if (!tab) return;
  const idx = order.indexOf(id);
  win.contentView.removeChildView(tab.view); tab.view.webContents.close();
  tabs.delete(id); order = order.filter(x => x !== id);
  if (!order.length) return createTab();
  if (activeId === id) { activeId = null; select(order[Math.max(0, idx - 1)]); } else pushState();
}

const tabOf = e => [...tabs.values()].find(t => t.view.webContents.id === e.sender.id);
function handle(ch, fn) {
  ipcMain.handle(ch, (e, ...a) => {
    if (!(e.senderFrame && e.senderFrame.url.startsWith('file:'))) throw new Error('forbidden'); // only our own UI
    return fn(e, ...a);
  });
}

function setup() {
  ipcMain.on('shield:seed', e => {
    const t = tabOf(e); if (!t || t.flags.seed) return;
    t.flags.seed = true; stats.threats++;
    log('danger', 'Страница просит seed-фразу или приватный ключ: ' + hostOf(shownUrl(t)));
    if (win && !win.isDestroyed()) win.webContents.send('alert', 'Страница просит seed-фразу или приватный ключ. Не вводите их.');
    pushState();
  });
  handle('state:get', () => pushState());
  handle('tab:new', (_e, url, crypto) => createTab(url && /^https?:\/\//.test(url) ? url : undefined, !!crypto));
  handle('tab:close', (_e, id) => closeTab(id));
  handle('tab:select', (_e, id) => tabs.has(id) && select(id));
  handle('nav:go', (e, raw) => { const t = tabs.get(activeId); if (t) go(t, String(raw)); });
  handle('nav:back', () => { const wc = tabs.get(activeId)?.view.webContents; if (wc?.navigationHistory.canGoBack()) wc.navigationHistory.goBack(); });
  handle('nav:forward', () => { const wc = tabs.get(activeId)?.view.webContents; if (wc?.navigationHistory.canGoForward()) wc.navigationHistory.goForward(); });
  handle('nav:reload', () => tabs.get(activeId)?.view.webContents.reload());
  handle('ui:side', () => { sideOpen = !sideOpen; layout(); pushState(); });
  handle('data:fng', () => feeds.getFearGreed());
  handle('data:stats', () => ({ stats, events: events.slice(0, 6), phishing: blocklist.size() }));
  handle('alerts:list', () => alerts);
  handle('alerts:add', (_e, a) => {
    const price = Number(a && a.price);
    if (!a || !feeds.COINS.some(c => c.id === a.coin) || !['above', 'below'].includes(a.dir) || !(price > 0)) return alerts;
    alerts.push({ id: Date.now() + Math.random(), coin: a.coin, dir: a.dir, price }); saveAlerts(); return alerts;
  });
  handle('alerts:remove', (_e, id) => { alerts = alerts.filter(x => x.id !== id); saveAlerts(); return alerts; });
  handle('ui:overlay', (_e, open) => {
    const t = tabs.get(activeId); if (!t) return;
    win.contentView.removeChildView(t.view); // views sit above the UI layer, so hide the page while the palette is open
    if (!open) { win.contentView.addChildView(t.view); layout(); }
  });
  handle('data:news', () => feeds.getNews());
  handle('data:prices', () => feeds.getPrices());
  handle('data:config', () => ({ featured: config.featured, exchanges: Object.entries(config.exchanges).map(([id, x]) => ({
    id, name: x.name, url: x.ref ? x.register.replace('{ref}', x.ref) : x.url })) }));
  handle('shield:proceed', (e, url) => {
    const t = tabOf(e); if (!t || url !== t.warnUrl) return;
    t.allowed.add(new URL(url).hostname); t.warnUrl = null; t.view.webContents.loadURL(url).catch(() => {});
  });
  handle('shield:home', e => { const t = tabOf(e); if (t) go(t, ''); });
}

// Clipboard guard: warns when a copied crypto address is replaced by another within seconds
// (typical "clipboard hijacker" behaviour).
let lastAddr = '', lastAt = 0;
function watchClipboard() {
  setInterval(() => {
    const t = clipboard.readText().trim();
    if (!t || !isAddress(t) || t === lastAddr) return;
    if (lastAddr && Date.now() - lastAt < 8000) {
      const msg = 'Адрес в буфере обмена только что изменился. Сверьте его перед отправкой средств.';
      new Notification({ title: 'Obsidian Shield', body: msg }).show();
      if (win && !win.isDestroyed()) win.webContents.send('alert', msg);
    }
    lastAddr = t; lastAt = Date.now();
  }, 800);
}


// Price alerts: stored locally, checked every minute.
let alerts = [];
const alertsFile = () => path.join(app.getPath('userData'), 'alerts.json');
function loadAlerts() { try { alerts = JSON.parse(fs.readFileSync(alertsFile(), 'utf8')); } catch { alerts = []; } }
function saveAlerts() { try { fs.writeFileSync(alertsFile(), JSON.stringify(alerts)); } catch {} }
async function checkAlerts() {
  if (!alerts.length) return;
  const prices = await feeds.getPrices(); const hit = [];
  for (const a of alerts) {
    const p = prices[a.coin]; if (!p) continue;
    if ((a.dir === 'above' && p.usd >= a.price) || (a.dir === 'below' && p.usd <= a.price)) hit.push({ a, p });
  }
  if (!hit.length) return;
  alerts = alerts.filter(x => !hit.some(h => h.a.id === x.id)); saveAlerts();
  for (const { a, p } of hit) {
    const msg = `${p.sym} ${a.dir === 'above' ? 'выше' : 'ниже'} $${a.price}: сейчас $${p.usd}`;
    new Notification({ title: 'Obsidian: алерт по цене', body: msg }).show();
    if (win && !win.isDestroyed()) win.webContents.send('alert', msg);
  }
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }]) : null);
  blocklist.init(app.getPath('userData'));
  loadAlerts(); setInterval(checkAlerts, 60e3);
  setup();
  win = new BrowserWindow({ width: 1440, height: 900, minWidth: 900, minHeight: 600, backgroundColor: '#12151C', title: 'Obsidian',
    titleBarStyle: 'hidden', titleBarOverlay: { color: '#181D27', symbolColor: '#E6E8EC', height: 38 },
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true } });
  win.loadFile(path.join(UI, 'chrome.html'));
  win.webContents.once('did-finish-load', () => createTab());
  win.on('resize', layout);
  watchClipboard();
});
app.on('window-all-closed', () => app.quit());
