// Known phishing domains: community list from MetaMask "eth-phishing-detect" (~200k domains).
// Cached on disk, refreshed every 24h. Matches the domain and any of its subdomains.
const fs = require('fs'), path = require('path');
const SRC = 'https://raw.githubusercontent.com/MetaMask/eth-phishing-detect/master/src/config.json';
const DAY = 24 * 3600e3;
let set = new Set(), file = '', loadedAt = 0;

async function refresh() {
  try {
    const r = await fetch(SRC, { signal: AbortSignal.timeout(60000) });
    const j = await r.json();
    if (Array.isArray(j.blacklist) && j.blacklist.length > 1000) {
      const list = j.blacklist.map(s => String(s).toLowerCase());
      set = new Set(list); loadedAt = Date.now();
      fs.writeFileSync(file, JSON.stringify({ at: loadedAt, list }));
    }
  } catch {}
}

function init(dir) {
  file = path.join(dir, 'phishing-list.json');
  try { const j = JSON.parse(fs.readFileSync(file, 'utf8')); set = new Set(j.list); loadedAt = j.at || 0; } catch {}
  if (Date.now() - loadedAt > DAY) refresh();
  setInterval(() => { if (Date.now() - loadedAt > DAY) refresh(); }, 3600e3);
}

function check(host) {
  const p = String(host).toLowerCase().split('.');
  for (let i = 0; i < p.length - 1; i++) if (set.has(p.slice(i).join('.'))) return true;
  return false;
}

module.exports = { init, check, size: () => set.size };
