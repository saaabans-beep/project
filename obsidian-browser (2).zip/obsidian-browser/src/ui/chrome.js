const api = window.obsidian;
const $ = s => document.querySelector(s);
const LABEL = { official: 'Официальный домен', ok: 'Нет сигналов риска', warn: 'Осторожно', danger: 'Опасно', local: 'Obsidian' };
let S = null, prices = {}, news = [], cfg = null, alerts = [], alertCoin = null, sideTab = 'market', lastKey = '';
if (/Mac/.test(navigator.platform)) document.body.classList.add('mac');

function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  kids.forEach(k => e.append(k));
  return e;
}
const fmt = p => '$' + p.toLocaleString('en-US', { maximumFractionDigits: p < 1 ? 4 : 2 });
const pct = c => (c >= 0 ? '+' : '') + c.toFixed(1) + '%';

function renderTabs() {
  const box = $('#tabs'); box.replaceChildren();
  S.tabs.forEach(t => box.append(el('div', { class: 'tab' + (t.id === S.activeId ? ' active' : '') + (t.crypto ? ' crypto' : ''),
    title: t.crypto ? 'Crypto-профиль: вход на биржи хранится отдельно от обычного сёрфинга' : t.title,
    onclick: () => api.invoke('tab:select', t.id) },
    el('i', { class: 'dot ' + (t.level || 'local'), title: 'Проверка Shield' }),
    el('span', { class: 't', text: t.title }),
    el('button', { class: 'x', text: '×', 'aria-label': 'Закрыть', onclick: e => { e.stopPropagation(); api.invoke('tab:close', t.id); } }))));
  box.append(el('button', { class: 'add', text: '+', title: 'Новая вкладка (изолированная)', onclick: () => api.invoke('tab:new') }),
             el('button', { class: 'add', text: '+ Crypto', title: 'Вкладка Crypto-профиля', onclick: () => api.invoke('tab:new', null, true) }));
}

function renderBar() {
  const a = $('#addr'); if (document.activeElement !== a) a.value = (S.tabs.find(t => t.id === S.activeId) || {}).url || '';
  const b = $('#badge'), lvl = S.risk ? S.risk.level : 'local';
  b.className = 'badge ' + lvl; b.replaceChildren(el('i', { class: 'dot ' + lvl }), document.createTextNode(LABEL[lvl]));
  $('#sidebar').classList.toggle('hidden', !S.side);
}

function priceRow(id, clickable) {
  const p = prices[id]; if (!p) return null;
  const row = el('li', { class: 'prow' + (clickable ? ' click' : ''), title: clickable ? 'Нажмите, чтобы поставить алерт по цене' : '' },
    el('b', { text: p.sym }),
    el('span', {}, document.createTextNode(fmt(p.usd) + ' '), el('span', { class: p.change >= 0 ? 'up' : 'down', text: pct(p.change || 0) })));
  if (clickable) row.addEventListener('click', () => { alertCoin = alertCoin === id ? null : id; renderSide(); });
  return row;
}

function alertForm(id) {
  const p = prices[id];
  const dir = el('select', {}, el('option', { value: 'above', text: 'выше' }), el('option', { value: 'below', text: 'ниже' }));
  const inp = el('input', { type: 'number', placeholder: String(Math.round(p.usd)), 'aria-label': 'Цена' });
  const ok = el('button', { text: 'Добавить', onclick: async () => {
    if (!(Number(inp.value) > 0)) return inp.focus();
    alerts = await api.invoke('alerts:add', { coin: id, dir: dir.value, price: Number(inp.value) });
    alertCoin = null; renderSide();
  } });
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') ok.click(); });
  return el('li', { class: 'afm' }, el('span', { text: p.sym }), dir, inp, ok);
}

const ago = ts => { const m = Math.max(1, Math.round((Date.now() - ts) / 60000)); return m < 60 ? m + ' мин назад' : Math.round(m / 60) + ' ч назад'; };

function pageTab(side) {
  const lvl = S.risk ? S.risk.level : 'local';
  if (lvl === 'local') side.append(el('div', { class: 'status' }, el('b', { text: 'Новая вкладка' }), el('span', { class: 'note', text: 'Откройте сайт, и Shield покажет здесь результат проверки.' })));
  else side.append(el('div', { class: 'status ' + lvl }, el('b', { text: LABEL[lvl] }), el('ul', {}, ...S.risk.reasons.map(r => el('li', { text: r })))));
  const st = S.stats;
  side.append(el('div', { class: 'stats3' },
    el('div', { class: 'st' }, el('b', { text: String(st.threats) }), el('span', { text: 'угроз' })),
    el('div', { class: 'st' }, el('b', { text: String(st.trackers) }), el('span', { text: 'трекеров' })),
    el('div', { class: 'st' }, el('b', { text: String(st.https) }), el('span', { text: 'на HTTPS' }))));
  if (S.coins.length) side.append(el('h3', { text: 'Монеты на странице' }), el('ul', {}, ...S.coins.map(c => priceRow(c, false)).filter(Boolean)));
  side.append(el('h3', { text: 'Журнал Shield' }));
  side.append(S.events.length
    ? el('ul', { class: 'log' }, ...S.events.map(e => el('li', {}, el('i', { class: 'dot ' + (e.level === 'ok' ? 'official' : e.level) }), el('div', {}, document.createTextNode(e.text), el('small', { text: ago(e.t) })))))
    : el('p', { class: 'note', text: 'Пока всё спокойно: событий нет.' }));
}

function marketTab(side) {
  const rows = [];
  Object.keys(prices).forEach(id => { rows.push(priceRow(id, true)); if (alertCoin === id) rows.push(alertForm(id)); });
  side.append(el('ul', {}, ...rows), el('p', { class: 'note', text: 'Нажмите на монету, чтобы поставить алерт по цене.' }));
  if (alerts.length) side.append(el('h3', { text: 'Активные алерты' }), el('ul', {}, ...alerts.map(a => el('li', { class: 'alr' },
    el('span', { text: `${prices[a.coin] ? prices[a.coin].sym : a.coin} ${a.dir === 'above' ? 'выше' : 'ниже'} ${fmt(a.price)}` }),
    el('button', { text: '×', 'aria-label': 'Удалить алерт', onclick: async () => { alerts = await api.invoke('alerts:remove', a.id); renderSide(); } })))));
}

function newsTab(side) {
  const rel = news.filter(n => n.coins.some(c => S.coins.includes(c)));
  const list = (rel.length ? rel : news).slice(0, 14);
  side.append(el('h3', { text: rel.length ? 'Новости по теме страницы' : 'Главное в крипте' }),
    el('ul', { class: 'news' }, ...list.map(n => el('li', {},
      el('a', { text: n.title, tabindex: '0', onclick: () => api.invoke('tab:new', n.link, false) }), el('small', { text: n.source })))));
  if (cfg) side.append(el('h3', { text: 'Биржи' }), el('div', { class: 'ex' }, ...cfg.exchanges.map(x =>
    el('button', { class: x.id === cfg.featured ? 'feat' : '', text: x.name, onclick: () => api.invoke('tab:new', x.url, true) }))));
}

function renderSide() {
  if (!S) return;
  const side = $('#sidebar'); side.replaceChildren(
    el('div', { class: 'seg' }, ...[['page', 'Страница'], ['market', 'Рынок'], ['news', 'Новости']].map(([id, l]) =>
      el('button', { class: id === sideTab ? 'on' : '', text: l, onclick: () => { sideTab = id; renderSide(); } }))));
  (sideTab === 'page' ? pageTab : sideTab === 'market' ? marketTab : newsTab)(side);
}

async function refreshData() { prices = await api.invoke('data:prices'); renderSide(); }
async function refreshNews() { news = await api.invoke('data:news'); renderSide(); }

// ---------- command palette (Ctrl+K) ----------
let palItems = [], palSel = 0;
function palCommands() {
  const go = (url, crypto) => () => api.invoke('tab:new', url, crypto);
  const c = [
    { label: 'Новая вкладка', hint: 'изолированная', run: go(null, false) },
    { label: 'Новая Crypto-вкладка', hint: 'отдельный профиль', run: go(null, true) },
    { label: 'Показать или скрыть боковую панель', hint: 'интерфейс', run: () => api.invoke('ui:side') }
  ];
  if (cfg) cfg.exchanges.forEach(x => c.push({ label: 'Открыть ' + x.name, hint: 'биржа', run: go(x.url, true) }));
  Object.values(prices).forEach(p => c.push({ label: `${p.sym}  ${fmt(p.usd)}  ${pct(p.change || 0)}`, hint: 'график TradingView', run: go(`https://www.tradingview.com/symbols/${p.sym}USD/`, false) }));
  news.slice(0, 15).forEach(n => c.push({ label: n.title, hint: n.source, run: go(n.link, false) }));
  return c;
}
function palRender() {
  const q = $('#palq').value.trim().toLowerCase();
  palItems = palCommands().filter(i => !q || i.label.toLowerCase().includes(q)).slice(0, 30);
  if (q) palItems.unshift({ label: 'Перейти или найти: ' + $('#palq').value.trim(), hint: 'Enter', run: () => api.invoke('nav:go', $('#palq').value) });
  palSel = Math.min(palSel, Math.max(0, palItems.length - 1));
  const ul = $('#pall'); ul.replaceChildren();
  palItems.forEach((it, i) => ul.append(el('li', { class: i === palSel ? 'sel' : '', onclick: () => palRun(i) }, el('span', { text: it.label }), el('span', { text: it.hint }))));
}
async function palOpen() { await api.invoke('ui:overlay', true); $('#pal').hidden = false; $('#palq').value = ''; palSel = 0; palRender(); $('#palq').focus(); }
async function palClose() { if ($('#pal').hidden) return; $('#pal').hidden = true; await api.invoke('ui:overlay', false); }
async function palRun(i) { const it = palItems[i]; await palClose(); if (it) it.run(); }
$('#palq').addEventListener('input', () => { palSel = 0; palRender(); });
$('#palq').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { palSel = Math.min(palSel + 1, palItems.length - 1); palRender(); e.preventDefault(); }
  else if (e.key === 'ArrowUp') { palSel = Math.max(palSel - 1, 0); palRender(); e.preventDefault(); }
  else if (e.key === 'Enter') palRun(palSel);
  else if (e.key === 'Escape') palClose();
});
$('#pal').addEventListener('mousedown', e => { if (e.target.id === 'pal') palClose(); });

api.on('palette', palOpen);
api.on('state', s => {
  if (!s) return $('#addr').focus();
  const key = JSON.stringify([s.coins, s.risk, s.stats, s.events[0] && s.events[0].t]);
  S = s; renderTabs(); renderBar();
  if (key !== lastKey || !$('#sidebar').children.length) { lastKey = key; renderSide(); }
});
api.on('alert', async msg => {
  if (/seed|фишинг|скач/i.test(msg)) sideTab = 'page';
  const t = $('#toast'); t.textContent = msg; t.hidden = false; setTimeout(() => t.hidden = true, 8000);
  alerts = await api.invoke('alerts:list'); renderSide();
});

$('#addr').addEventListener('keydown', e => { if (e.key === 'Enter') { api.invoke('nav:go', e.target.value); e.target.blur(); } });
$('#addr').addEventListener('focus', e => e.target.select());
$('#back').onclick = () => api.invoke('nav:back');
$('#fwd').onclick = () => api.invoke('nav:forward');
$('#reload').onclick = () => api.invoke('nav:reload');
$('#side').onclick = () => api.invoke('ui:side');
$('#badge').onclick = () => { sideTab = 'page'; if (S && !S.side) api.invoke('ui:side'); renderSide(); };
document.addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey)) return;
  if (e.key === 't') { e.preventDefault(); api.invoke('tab:new'); }
  if (e.key === 'w') { e.preventDefault(); api.invoke('tab:close', S.activeId); }
  if (e.key === 'l') { e.preventDefault(); $('#addr').focus(); }
  if (e.key === 'k') { e.preventDefault(); palOpen(); }
});

(async () => {
  cfg = await api.invoke('data:config'); alerts = await api.invoke('alerts:list');
  await api.invoke('state:get');
  refreshData(); refreshNews();
  setInterval(refreshData, 60e3); setInterval(refreshNews, 5 * 60e3);
})();
