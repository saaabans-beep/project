const api = window.obsidian;
const p = new URLSearchParams(location.search);
const url = p.get('url') || '';
document.getElementById('host').textContent = url;
let reasons = []; try { reasons = JSON.parse(p.get('reasons') || '[]'); } catch {}
reasons.forEach(r => { const li = document.createElement('li'); li.textContent = r; document.getElementById('why').append(li); });
document.getElementById('home').onclick = () => api.invoke('shield:home');
document.getElementById('proceed').onclick = () => api.invoke('shield:proceed', url);
