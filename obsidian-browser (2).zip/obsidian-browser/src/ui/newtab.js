const api = window.obsidian;
const $ = s => document.querySelector(s);
const NS = 'http://www.w3.org/2000/svg';
let news = [], prices = {}, filter = null;

function sparkline(arr, up) {
  const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 120 38'); svg.setAttribute('preserveAspectRatio', 'none');
  if (!arr || arr.length < 2) return svg;
  const min = Math.min(...arr), max = Math.max(...arr), span = max - min || 1;
  const pts = arr.map((v, i) => [(i / (arr.length - 1)) * 120, 34 - ((v - min) / span) * 30]);
  const col = up ? 'var(--ok)' : 'var(--danger)';
  const line = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const area = document.createElementNS(NS, 'polygon'); area.setAttribute('points', `0,38 ${line} 120,38`); area.setAttribute('fill', col); area.setAttribute('opacity', '.12');
  const pl = document.createElementNS(NS, 'polyline'); pl.setAttribute('points', line); pl.setAttribute('fill', 'none'); pl.setAttribute('stroke', col);
  pl.setAttribute('stroke-width', '1.6'); pl.setAttribute('vector-effect', 'non-scaling-stroke');
  svg.append(area, pl); return svg;
}
const fmt = p => '$' + p.toLocaleString('en-US', { maximumFractionDigits: p < 1 ? 4 : 2 });
const ago = ts => {
  if (!ts) return ''; const m = Math.round((Date.now() - ts) / 60000), r = new Intl.RelativeTimeFormat('ru', { numeric: 'auto' });
  return m < 60 ? r.format(-Math.max(m, 1), 'minute') : m < 1440 ? r.format(-Math.round(m / 60), 'hour') : r.format(-Math.round(m / 1440), 'day');
};
const mk = (t, c, text) => { const e = document.createElement(t); if (c) e.className = c; if (text != null) e.textContent = text; return e; };

function renderMarket() {
  const g = $('#grid'); g.replaceChildren();
  Object.values(prices).forEach(p => {
    const up = (p.change || 0) >= 0, b = mk('button', 'card'); b.title = 'Открыть график на TradingView';
    const r = mk('div', 'r'); r.append(mk('span', 's', p.sym), mk('span', 'n', p.name));
    const ch = mk('div', 'ch ' + (up ? 'up' : 'down'), (up ? '+' : '') + (p.change || 0).toFixed(1) + '% за 24 ч');
    b.append(r, mk('div', 'pr', fmt(p.usd)), ch, sparkline(p.spark, up));
    b.onclick = () => api.invoke('nav:go', `https://www.tradingview.com/symbols/${p.sym}USD/`);
    g.append(b);
  });
}

function renderNews() {
  const ids = [...new Set(news.flatMap(n => n.coins))].filter(id => prices[id]);
  const chips = $('#chips'); chips.replaceChildren();
  const add = (label, id) => { const c = mk('button', 'chip' + (filter === id ? ' on' : ''), label); c.onclick = () => { filter = id; renderNews(); }; chips.append(c); };
  add('Все', null); ids.forEach(id => add(prices[id].sym, id));
  const ul = $('#news'); ul.replaceChildren();
  const list = news.filter(n => !filter || n.coins.includes(filter)).slice(0, 14);
  if (!list.length) return ul.append(mk('li', '', news.length ? 'По этой монете новостей пока нет.' : 'Новости не загрузились. Проверьте интернет и обновите вкладку.'));
  list.forEach(n => {
    const li = mk('li'), a = mk('a', '', n.title); a.tabIndex = 0; a.onclick = () => api.invoke('nav:go', n.link);
    li.append(a, mk('small', '', `${n.source} · ${ago(n.date)}`)); ul.append(li);
  });
}

$('#q').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.value.trim()) api.invoke('nav:go', e.target.value); });

api.invoke('data:prices').then(p => { prices = p; renderMarket(); renderNews(); });
api.invoke('data:news').then(n => { news = n; renderNews(); });
api.invoke('data:fng').then(f => {
  if (!f) return $('#fg').textContent = 'нет данных';
  const el = $('#fg'); el.textContent = String(f.value); el.append(mk('small', '', f.label));
  $('#fgm').style.left = Math.max(1, Math.min(99, f.value)) + '%';
});
api.invoke('data:stats').then(d => {
  $('#s1').textContent = d.stats.threats; $('#s2').textContent = d.stats.trackers; $('#s3').textContent = d.stats.https;
  $('#sdb').textContent = d.phishing ? `База фишинга: ${d.phishing.toLocaleString('ru')} доменов` : 'База фишинга загружается (нужен интернет)';
  const ul = $('#slog'); ul.replaceChildren();
  d.events.slice(0, 4).forEach(e => { const li = mk('li'), dot = mk('i', e.level === 'ok' ? '' : e.level); li.append(dot, mk('span', '', e.text)); ul.append(li); });
});
api.invoke('data:config').then(cfg => cfg.exchanges.forEach(x => {
  const b = mk('button', x.id === cfg.featured ? 'feat' : '', x.name); b.onclick = () => api.invoke('nav:go', x.url); $('#ex').append(b);
}));
