// Crypto Shield: offline heuristics for phishing / look-alike domains.
// This is a first layer, not a guarantee. Add real blocklist feeds later.
const blocklist = require('./blocklist');
const KNOWN = ['binance.com','bybit.com','okx.com','coinbase.com','kraken.com','kucoin.com','bitget.com','gate.io',
  'metamask.io','uniswap.org','opensea.io','trustwallet.com','ledger.com','trezor.io','phantom.app','etherscan.io',
  'coingecko.com','coinmarketcap.com','tradingview.com','pancakeswap.finance'];
const BRANDS = ['binance','bybit','okx','coinbase','kraken','kucoin','bitget','metamask','uniswap','opensea',
  'trustwallet','etherscan','coingecko','coinmarketcap','tradingview','pancakeswap'];
const KNOWN_SLDS = KNOWN.map(d => d.split('.')[0]).filter(s => s.length >= 5);
const RISKY_TLD = new Set(['zip','top','xyz','click','link','cfd','sbs','icu','monster','gq','tk','ml','cf','work','rest']);
const BAIT = ['airdrop','claim','giveaway','free-','verify-wallet','connect-wallet','walletconnect','seed-phrase','recovery','validate-wallet'];
const TWO_LEVEL = ['co.uk','com.au','com.tr','co.in','com.br','co.jp','com.cn'];

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
  return d[a.length][b.length];
}

function registrable(host) {
  const p = host.split('.');
  const last2 = p.slice(-2).join('.');
  return TWO_LEVEL.includes(last2) ? p.slice(-3).join('.') : last2;
}

function assess(urlStr) {
  let u;
  try { u = new URL(urlStr); } catch { return { level: 'warn', score: 2, reasons: ['Не удалось разобрать адрес'] }; }
  if (!/^https?:$/.test(u.protocol)) return { level: 'local', score: 0, reasons: [] };

  const host = u.hostname.toLowerCase();
  if (blocklist.check(host)) return { level: 'danger', score: 10, reasons: ['Сайт числится в базе известных фишинговых ресурсов (MetaMask Phishing Detect)'] };
  const reg = registrable(host);
  const sld = reg.split('.')[0];
  const reasons = [];
  let score = 0;
  const add = (n, text) => { score += n; reasons.push(text); };
  const isLocal = host === 'localhost' || host === '127.0.0.1';

  if (u.protocol === 'http:' && !isLocal) add(2, 'Соединение без HTTPS');
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(':')) add(3, 'Сайт открыт по IP-адресу, а не по домену');
  const punycode = host.split('.').some(l => l.startsWith('xn--'));
  if (punycode) add(4, 'Домен содержит похожие по виду символы (punycode)');

  const official = KNOWN.includes(reg) && !punycode;
  if (official && score === 0) return { level: 'official', score: 0, reasons: ['Домен совпадает с известным официальным'] };

  if (!official) {
    const brand = BRANDS.find(b => host.includes(b));
    if (brand) add(4, `Имитирует бренд ${brand}: домен не принадлежит ему`);
    else {
      const near = KNOWN_SLDS.find(k => k !== sld && lev(k, sld) <= (k.length <= 7 ? 1 : 2));
      if (near) add(4, `Название почти совпадает с «${near}» (возможная подделка)`);
    }
    const tld = host.split('.').pop();
    if (RISKY_TLD.has(tld)) add(1, `Зона .${tld} часто используется в скам-сайтах`);
    const bait = BAIT.find(b => host.includes(b) || u.pathname.toLowerCase().includes(b));
    if (bait) add(2, `Приманка в адресе: «${bait}»`);
    if ((host.match(/-/g) || []).length >= 3) add(1, 'Слишком много дефисов в домене');
  }

  const level = score >= 4 ? 'danger' : score >= 2 ? 'warn' : 'ok';
  if (!reasons.length) reasons.push('Тревожных признаков не найдено (это не гарантия безопасности)');
  return { level, score, reasons };
}

const TRACKERS = ['doubleclick.net','googlesyndication.com','google-analytics.com','googletagmanager.com','facebook.net',
  'hotjar.com','mixpanel.com','segment.io','adnxs.com','criteo.com','scorecardresearch.com','taboola.com',
  'outbrain.com','amplitude.com'];
const isTracker = host => TRACKERS.some(t => host === t || host.endsWith('.' + t));

// Clipboard address detection (BTC / ETH-like / TRON)
const ADDR = /^(0x[a-fA-F0-9]{40}|bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|T[1-9A-HJ-NP-Za-km-z]{33})$/;
const isAddress = s => ADDR.test(s);

module.exports = { assess, isTracker, isAddress };
