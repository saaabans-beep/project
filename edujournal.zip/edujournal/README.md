# EduJournal

Электронный журнал для школ, колледжей и вузов: расписание, журнал оценок и посещаемости, рубежный контроль, экзамены, транскрипт и GPA.

Стек: Node.js 18+, Express 5, SQLite (better-sqlite3), JWT. Фронтенд — чистый JS без сборки.

## Запуск

```bash
npm install
npm run seed
npm start
```

Открыть http://localhost:3000

`npm run seed` пересоздает базу с демо-данными (колледж и школа). Пароль у всех — `123456`.

| Логин | Роль |
|---|---|
| root | суперадмин, создает учебные заведения и их админов |
| col.admin | админ колледжа |
| sch.admin | админ школы |
| col.t1 … col.t4 | преподаватели колледжа |
| sch.t1 … sch.t3 | учителя школы |
| col.s101, col.s201 … | студенты колледжа |
| sch.s101 … | ученики школы |

Без seed при первом старте создается только `root / superadmin` (пароль можно задать через `SUPERADMIN_PASSWORD`).

## Переменные окружения

| Переменная | По умолчанию |
|---|---|
| PORT | 3000 |
| JWT_SECRET | change-me-in-production |
| JWT_TTL | 12h |
| DB_PATH | data/journal.db |
| EDIT_DAYS | 7 — сколько дней преподаватель может править журнал |
| SUPERADMIN_PASSWORD | superadmin |

## Роли

**Суперадмин** — учебные заведения, администраторы.

**Админ** — пользователи (в т.ч. массовый импорт студентов списком), группы/классы, предметы, аудитории, семестры, нагрузка (кто какой предмет ведет в какой группе), расписание с проверкой накладок (преподаватель, группа, аудитория), генерация занятий на семестр с учетом праздников, замены и переносы, экзамены и ведомости, отчеты, журнал действий.

**Преподаватель** — свои занятия на сегодня, отметка посещаемости, тема и ДЗ, оценки в журнале, РК1/РК2 (колледж) или четвертные (школа), ведомость экзамена, отчет по посещаемости, объявления для групп. Править журнал можно в течение `EDIT_DAYS` дней, дальше — только админ.

**Студент / ученик** — расписание, оценки по предметам, рейтинг допуска, итог, посещаемость, экзамены, транскрипт с GPA.

## Оценивание

Школа: шкала 1–5, средний балл и прогноз четвертной.

Колледж / вуз: шкала 0–100.
- Рейтинг допуска = среднее РК1 и РК2 (если РК нет — среднее текущих)
- Допуск к экзамену от 50
- Итог = допуск × 0.6 + экзамен × 0.4, экзамен должен быть не ниже 50
- Буквенная оценка и GPA по кредитной системе РК: A (95–100, 4.0) … D (50–54, 1.0), F (0–49)

Веса и пороги — в `src/config.js`.

## API

Все запросы, кроме логина, с заголовком `Authorization: Bearer <token>`.

```
POST   /api/auth/login                 {login, password}
GET    /api/auth/me
POST   /api/auth/change-password

GET|POST|PATCH|DELETE /api/institutions
GET|POST|PATCH|DELETE /api/users       ?role=&group_id=&q=
POST   /api/users/import               {users: [{full_name, group_id}]}
POST   /api/users/:id/reset-password

GET|POST|PATCH|DELETE /api/groups | /api/subjects | /api/rooms
GET|POST|DELETE       /api/terms
POST   /api/terms/:id/activate
GET|POST|PATCH|DELETE /api/course-loads

GET    /api/schedule                   ?group_id=&teacher_id=&room_id=&view=week
POST   /api/schedule                   {course_load_id, weekday, start_time, end_time, room_id, lesson_type}
POST   /api/schedule/check
PATCH  /api/schedule/:id               {..., update_future_lessons}
DELETE /api/schedule/:id
POST   /api/schedule/generate-lessons  {from, to, holidays: [], group_id}

GET    /api/lessons                    ?from=&to=&group_id=&course_load_id=
GET    /api/lessons/:id
POST   /api/lessons
PATCH  /api/lessons/:id                {topic, homework, status, substitute_teacher_id, ...}
PUT    /api/lessons/:id/attendance     {items: [{student_id, status}]}

GET    /api/grades/journal/:courseLoadId
GET    /api/grades/my
POST   /api/grades                     {course_load_id, student_id, value, kind, lesson_id}
POST   /api/grades/bulk                {course_load_id, kind, items: [{student_id, value}]}
PATCH  /api/grades/:id
DELETE /api/grades/:id

GET    /api/exams
POST   /api/exams
GET    /api/exams/:id
PUT    /api/exams/:id/results          {items: [{student_id, score, absent}]}
POST   /api/exams/:id/close
POST   /api/exams/:id/reopen

GET    /api/reports/dashboard
GET    /api/reports/transcript[/:studentId]
GET    /api/reports/group/:groupId
GET    /api/reports/attendance         ?group_id=&from=&to=
GET    /api/reports/teacher-load
GET    /api/reports/unmarked
GET    /api/reports/audit

GET|POST|DELETE /api/announcements
```

При накладке в расписании возвращается `409` со списком конфликтов. Чтобы сохранить все равно, передайте `ignore_conflicts: true`.

## Структура

```
src/
  server.js        запуск
  app.js           express, маршруты, обработка ошибок
  config.js
  db.js            подключение и схема
  schema.sql
  seed.js          демо-данные
  lib/             auth, grading, summary, http
  routes/          auth, institutions, users, structure, schedule, lessons, grades, exams, reports, announcements
public/            веб-интерфейс
data/              файл базы
```
