const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('./config');

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new Database(config.dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

function audit(userId, action, entity, entityId, payload) {
  db.prepare(
    'INSERT INTO audit_log (user_id, action, entity, entity_id, payload) VALUES (?, ?, ?, ?, ?)'
  ).run(userId || null, action, entity || null, entityId || null, payload ? JSON.stringify(payload) : null);
}

module.exports = db;
module.exports.audit = audit;
