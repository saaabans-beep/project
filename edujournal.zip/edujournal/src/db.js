const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new DatabaseSync(config.dbPath);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');
db.exec('PRAGMA busy_timeout = 5000');

const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

let depth = 0;

db.transaction = fn => (...args) => {
  if (depth > 0) return fn(...args);
  depth++;
  db.exec('BEGIN');
  try {
    const result = fn(...args);
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    depth--;
  }
};

db.audit = (userId, action, entity, entityId, payload) => {
  db.prepare(
    'INSERT INTO audit_log (user_id, action, entity, entity_id, payload) VALUES (?, ?, ?, ?, ?)'
  ).run(userId || null, action, entity || null, entityId || null, payload ? JSON.stringify(payload) : null);
};

module.exports = db;
