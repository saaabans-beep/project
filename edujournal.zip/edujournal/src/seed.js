const fs = require('fs');
const config = require('./config');

for (const suffix of ['', '-wal', '-shm']) {
  if (fs.existsSync(config.dbPath + suffix)) fs.unlinkSync(config.dbPath + suffix);
}

const bcrypt = require('bcryptjs');
const db = require('./db');

const hash = bcrypt.hashSync('123456', 8);
const today = new Date().toISOString().slice(0, 10);
const year = new Date().getUTCMonth() >= 7 ? new Date().getUTCFullYear() : new Date().getUTCFullYear() - 1;

let seedState = 42;
function rand() {
  seedState = (seedState * 1103515245 + 12345) % 2147483648;
  return seedState / 2147483648;
}
const pickOne = arr => arr[Math.floor(rand() * arr.length)];

const insUser = db.prepare(`
  INSERT INTO users (institution_id, role, login, password_hash, full_name, group_id) VALUES (?, ?, ?, ?, ?, ?)
`);
const user = (inst, role, login, name, group = null) => insUser.run(inst, role, login, hash, name, group).lastInsertRowid;

const lastNames = ['Ахметов', 'Сериков', 'Иванов', 'Нурланов', 'Ким', 'Жумабаев', 'Петров', 'Касымов', 'Оспанов', 'Смагулов', 'Ли', 'Бекова'];
const firstNames = ['Алихан', 'Дана', 'Арман', 'Айгерим', 'Тимур', 'Мадина', 'Ерлан', 'Аружан', 'Данияр', 'Сабина', 'Нурсултан', 'Камила'];

function buildInstitution({ name, type, prefix, groups, subjects, teachers, slots }) {
  const inst = db.prepare('INSERT INTO institutions (name, type, address) VALUES (?, ?, ?)').run(name, type, 'г. Алматы').lastInsertRowid;
  user(inst, 'admin', `${prefix}.admin`, `Администратор ${name}`);

  const term = db.prepare('INSERT INTO terms (institution_id, name, start_date, end_date, is_current) VALUES (?, ?, ?, ?, 1)')
    .run(inst, type === 'school' ? `1-2 четверть ${year}` : `Осенний семестр ${year}-${year + 1}`, `${year}-09-01`, `${year}-12-26`).lastInsertRowid;

  const roomIds = ['101', '102', '201', '202', '305', 'Спортзал'].map(r =>
    db.prepare('INSERT INTO rooms (institution_id, name, capacity) VALUES (?, ?, ?)').run(inst, r, 30).lastInsertRowid
  );

  const teacherIds = teachers.map((t, i) => user(inst, 'teacher', `${prefix}.t${i + 1}`, t));
  const subjectIds = subjects.map(([s, credits]) =>
    db.prepare('INSERT INTO subjects (institution_id, name, credits, hours) VALUES (?, ?, ?, ?)').run(inst, s, credits, credits * 30).lastInsertRowid
  );

  const groupIds = groups.map(([gname, gyear], gi) => {
    const gid = db.prepare('INSERT INTO groups (institution_id, name, year, curator_id) VALUES (?, ?, ?, ?)')
      .run(inst, gname, gyear, teacherIds[gi % teacherIds.length]).lastInsertRowid;
    for (let i = 0; i < 10; i++) {
      user(inst, 'student', `${prefix}.s${gi + 1}${String(i + 1).padStart(2, '0')}`, `${lastNames[(i + gi) % 12]} ${firstNames[(i * 5 + gi) % 12]}`, gid);
    }
    return gid;
  });

  const insLoad = db.prepare('INSERT INTO course_loads (term_id, group_id, subject_id, teacher_id) VALUES (?, ?, ?, ?)');
  const insSlot = db.prepare('INSERT INTO schedule (course_load_id, weekday, start_time, end_time, room_id, lesson_type) VALUES (?, ?, ?, ?, ?, ?)');

  groupIds.forEach((gid, gi) => {
    subjectIds.forEach((sid, si) => {
      const teacher = teacherIds[(si + gi) % teacherIds.length];
      const clid = insLoad.run(term, gid, sid, teacher).lastInsertRowid;
      const day = ((si + gi * 2) % 5) + 1;
      const slot = slots[(si + gi) % slots.length];
      insSlot.run(clid, day, slot[0], slot[1], roomIds[(si + gi) % roomIds.length], type === 'school' ? 'lesson' : pickOne(['lecture', 'practice']));
      insSlot.run(clid, ((day + 2) % 5) + 1, slot[0], slot[1], roomIds[(si + gi + 1) % roomIds.length], type === 'school' ? 'lesson' : 'practice');
    });
  });

  return { inst, term, type };
}

function fillLessons({ inst, term, type }) {
  const t = db.prepare('SELECT * FROM terms WHERE id = ?').get(term);
  const slots = db.prepare(`
    SELECT sc.*, cl.group_id, cl.teacher_id FROM schedule sc JOIN course_loads cl ON cl.id = sc.course_load_id WHERE cl.term_id = ?
  `).all(term);
  const insLesson = db.prepare(`
    INSERT OR IGNORE INTO lessons (course_load_id, schedule_id, date, start_time, end_time, room_id, topic, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insAtt = db.prepare('INSERT INTO attendance (lesson_id, student_id, status, marked_by) VALUES (?, ?, ?, ?)');
  const insGrade = db.prepare(`
    INSERT INTO grades (course_load_id, student_id, lesson_id, kind, value, teacher_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const students = {};
  const d = new Date(t.start_date + 'T00:00:00Z');
  const end = new Date(t.end_date + 'T00:00:00Z');
  let topicN = 1;
  while (d <= end) {
    const date = d.toISOString().slice(0, 10);
    const wd = d.getUTCDay() || 7;
    for (const s of slots.filter(x => x.weekday === wd)) {
      const past = date < today;
      const info = insLesson.run(s.course_load_id, s.id, date, s.start_time, s.end_time, s.room_id, past ? `Тема ${topicN++}` : null, past ? 'done' : 'planned');
      if (!past || !info.changes) continue;
      const lessonId = info.lastInsertRowid;
      students[s.group_id] ||= db.prepare("SELECT id FROM users WHERE group_id = ? AND role = 'student'").all(s.group_id).map(r => r.id);
      for (const sid of students[s.group_id]) {
        const r = rand();
        const status = r < 0.82 ? 'present' : r < 0.9 ? 'late' : r < 0.96 ? 'absent' : 'excused';
        insAtt.run(lessonId, sid, status, s.teacher_id);
        if ((status === 'present' || status === 'late') && rand() < 0.35) {
          const value = type === 'school' ? pickOne([3, 4, 4, 5, 5, 5, 2]) : Math.round(55 + rand() * 45);
          insGrade.run(s.course_load_id, sid, lessonId, 'current', value, s.teacher_id, `${date} 12:00:00`);
        }
      }
    }
    d.setUTCDate(d.getUTCDate() + 1);
  }

  if (type !== 'school') {
    const loads = db.prepare('SELECT * FROM course_loads WHERE term_id = ?').all(term);
    for (const cl of loads) {
      for (const sid of db.prepare("SELECT id FROM users WHERE group_id = ? AND role = 'student'").all(cl.group_id).map(r => r.id)) {
        if (today > `${year}-10-20`) insGrade.run(cl.id, sid, null, 'rk1', Math.round(50 + rand() * 50), cl.teacher_id, `${year}-10-20 12:00:00`);
      }
    }
    const first = loads[0];
    const room = db.prepare('SELECT id FROM rooms WHERE institution_id = ? LIMIT 1').get(inst).id;
    db.prepare("INSERT INTO exams (course_load_id, kind, date, start_time, room_id) VALUES (?, 'final', ?, '10:00', ?)")
      .run(first.id, `${year}-12-28`, room);
  }
}

db.transaction(() => {
  const college = buildInstitution({
    name: 'Алматинский колледж связи',
    type: 'college',
    prefix: 'col',
    groups: [['ПО-21', 2], ['ПО-22', 2], ['ВТ-31', 3]],
    subjects: [['Программирование на JavaScript', 5], ['Базы данных', 4], ['Компьютерные сети', 4], ['Математика', 3], ['Английский язык', 2]],
    teachers: ['Ахметова Гульнара Сериковна', 'Ким Виктор Алексеевич', 'Нурланова Асель Ерлановна', 'Петров Дмитрий Игоревич'],
    slots: [['08:30', '09:50'], ['10:00', '11:20'], ['11:40', '13:00'], ['13:30', '14:50']]
  });
  const school = buildInstitution({
    name: 'Школа-гимназия №25',
    type: 'school',
    prefix: 'sch',
    groups: [['9 А', 9], ['10 Б', 10]],
    subjects: [['Алгебра', 1], ['Русский язык', 1], ['Физика', 1], ['История Казахстана', 1], ['Информатика', 1]],
    teachers: ['Смагулова Раушан Болатовна', 'Иванова Ольга Петровна', 'Оспанов Ерик Маратович'],
    slots: [['08:00', '08:45'], ['08:55', '09:40'], ['09:50', '10:35'], ['10:55', '11:40']]
  });
  fillLessons(college);
  fillLessons(school);
  db.prepare("INSERT INTO users (role, login, password_hash, full_name) VALUES ('superadmin', 'root', ?, 'Суперадминистратор')").run(hash);
})();

const stats = db.prepare(`
  SELECT (SELECT COUNT(*) FROM users) users, (SELECT COUNT(*) FROM lessons) lessons,
         (SELECT COUNT(*) FROM grades) grades, (SELECT COUNT(*) FROM attendance) attendance
`).get();
console.log('База заполнена:', stats);
console.log('Пароль у всех: 123456');
console.log('root — суперадмин, col.admin / sch.admin — админы, col.t1 — преподаватель, col.s101 — студент, sch.s101 — ученик');
