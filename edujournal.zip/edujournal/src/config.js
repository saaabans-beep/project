const path = require('path');

module.exports = {
  port: Number(process.env.PORT) || 3000,
  jwtSecret: process.env.JWT_SECRET || 'change-me-in-production',
  jwtTtl: process.env.JWT_TTL || '12h',
  dbPath: process.env.DB_PATH || path.join(__dirname, '..', 'data', 'journal.db'),
  rating: {
    admissionWeight: 0.6,
    examWeight: 0.4,
    minAdmission: 50,
    minExam: 50
  }
};
