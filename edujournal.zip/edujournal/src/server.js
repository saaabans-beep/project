const app = require('./app');
const config = require('./config');
const db = require('./db');
const bcrypt = require('bcryptjs');

const hasSuper = db.prepare("SELECT 1 FROM users WHERE role = 'superadmin'").get();
if (!hasSuper) {
  const password = process.env.SUPERADMIN_PASSWORD || 'superadmin';
  db.prepare("INSERT INTO users (role, login, password_hash, full_name) VALUES ('superadmin', 'root', ?, 'Суперадминистратор')")
    .run(bcrypt.hashSync(password, 10));
  console.log(`Создан суперадмин: root / ${password}`);
}

const server = app.listen(config.port, () => {
  console.log(`Сервер запущен: http://localhost:${config.port}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
