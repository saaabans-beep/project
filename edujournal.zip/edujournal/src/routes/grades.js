const router = require('express').Router();
const db = require('../db');
const { allow, loadCourse } = require('../lib/auth');
const { required, badRequest, notFound, forbidden } = require('../lib/http');
const grading = require('../lib/grading');
const { courseSummary } = require('../lib/summary');
const { currentTerm } = require('./structure');
const { canEditJournal } = require('./lessons');

const EDIT_DAYS = Number(process.env.EDIT_DAYS) || 7;
const teacherOrAdmin = allow('superadmin', 'admin', 'teacher');

function kindsFor(type) {
  return type === 'school' ? ['current', 'quarter'] : ['current', 'rk1', 'rk2'];
}

function assertStudentInGroup(studentId, groupId) {
  const s = db.prepare("SELECT id FROM users WHERE id = ? AND role = 'student' AND group_id = ?").get(studentId, groupId);
  if (!s) throw badRequest('Студент не состоит в этой группе');
}

function validate(course, value, kind) {
  if (!kindsFor(course.institution_type).includes(kind)) {
    throw badRequest(`Тип оценки для этого заведения: ${kindsFor(course.institution_type).join(', ')}`);
  }
  if (!grading.isValidGrade(course.institution_type, value)) {
    const { min, max } = grading.scaleFor(course.institution_type);
    throw badRequest(`Оценка должна быть от ${min} до ${max}`);
  }
}

function canChange(req, grade) {
  if (req.user.role !== 'teacher') return;
  if (grade.teacher_id !== req.user.id) throw forbidden('Можно менять только свои оценки');
  const age = (Date.now() - Date.parse(grade.created_at + 'Z')) / 86_400_000;
  if (age > EDIT_DAYS) throw forbidden(`Оценку старше ${EDIT_DAYS} дней может изменить только администратор`);
}

router.get('/journal/:courseLoadId', teacherOrAdmin, (req, res) => {
  const course = loadCourse(req, req.params.courseLoadId);
  const students = db.prepare(`
    SELECT id, full_name FROM users WHERE group_id = ? AND role = 'student' AND is_active = 1 ORDER BY full_name
  `).all(course.group_id);
  const lessons = db.prepare(`
    SELECT id, date, start_time, topic, status FROM lessons
    WHERE course_load_id = ? AND status != 'cancelled' AND date <= ?
    ORDER BY date, start_time
  `).all(course.id, req.query.to || '9999-12-31');
  const grades = db.prepare('SELECT id, student_id, lesson_id, kind, value, comment, created_at FROM grades WHERE course_load_id = ?').all(course.id);
  const attendance = db.prepare(`
    SELECT a.lesson_id, a.student_id, a.status FROM attendance a
    JOIN lessons l ON l.id = a.lesson_id WHERE l.course_load_id = ?
  `).all(course.id);

  const cells = {};
  for (const a of attendance) cells[`${a.student_id}:${a.lesson_id}`] = { attendance: a.status, grades: [] };
  const extra = {};
  for (const g of grades) {
    if (g.lesson_id) {
      const key = `${g.student_id}:${g.lesson_id}`;
      (cells[key] ||= { attendance: null, grades: [] }).grades.push(g);
    } else {
      (extra[g.student_id] ||= []).push(g);
    }
  }

  res.json({
    course: {
      id: course.id, group: course.group_name, subject: course.subject_name,
      institution_type: course.institution_type, scale: grading.scaleFor(course.institution_type),
      kinds: kindsFor(course.institution_type)
    },
    lessons,
    students: students.map(s => ({
      ...s,
      cells: Object.fromEntries(lessons.map(l => [l.id, cells[`${s.id}:${l.id}`] || null])),
      control: extra[s.id] || [],
      summary: courseSummary(course, s.id)
    }))
  });
});

router.get('/my', allow('student'), (req, res) => {
  const term = req.query.term_id
    ? db.prepare('SELECT * FROM terms WHERE id = ? AND institution_id = ?').get(req.query.term_id, req.user.institution_id)
    : currentTerm(req.user.institution_id);
  if (!term) return res.json({ term: null, subjects: [] });
  const loads = db.prepare(`
    SELECT cl.id FROM course_loads cl WHERE cl.term_id = ? AND cl.group_id = ?
  `).all(term.id, req.user.group_id);
  const subjects = loads.map(({ id }) => {
    const course = loadCourse(req, id);
    const grades = db.prepare(`
      SELECT g.id, g.kind, g.value, g.comment, g.created_at, l.date, l.topic
      FROM grades g LEFT JOIN lessons l ON l.id = g.lesson_id
      WHERE g.course_load_id = ? AND g.student_id = ? ORDER BY COALESCE(l.date, g.created_at)
    `).all(id, req.user.id);
    return { course_load_id: id, subject: course.subject_name, credits: course.credits, grades, summary: courseSummary(course, req.user.id) };
  });
  res.json({ term, subjects });
});

router.post('/', teacherOrAdmin, (req, res) => {
  required(req.body, ['course_load_id', 'student_id', 'value']);
  const course = loadCourse(req, req.body.course_load_id);
  const kind = req.body.kind || 'current';
  validate(course, req.body.value, kind);
  assertStudentInGroup(req.body.student_id, course.group_id);

  let lessonId = req.body.lesson_id || null;
  if (lessonId) {
    const lesson = db.prepare('SELECT * FROM lessons WHERE id = ? AND course_load_id = ?').get(lessonId, course.id);
    if (!lesson) throw badRequest('Занятие не относится к этому предмету');
    canEditJournal(req, lesson);
    const att = db.prepare('SELECT status FROM attendance WHERE lesson_id = ? AND student_id = ?').get(lessonId, req.body.student_id);
    if (att?.status === 'absent' && !req.body.force) throw badRequest('Студент отмечен отсутствующим. Передайте force: true, если это отработка');
  }

  if (kind !== 'current') {
    const existing = db.prepare('SELECT id FROM grades WHERE course_load_id = ? AND student_id = ? AND kind = ?')
      .get(course.id, req.body.student_id, kind);
    if (existing) {
      db.prepare("UPDATE grades SET value = ?, comment = ?, teacher_id = ?, updated_at = datetime('now') WHERE id = ?")
        .run(req.body.value, req.body.comment || null, req.user.id, existing.id);
      db.audit(req.user.id, 'update', 'grades', existing.id, req.body);
      return res.json(db.prepare('SELECT * FROM grades WHERE id = ?').get(existing.id));
    }
  }

  const info = db.prepare(`
    INSERT INTO grades (course_load_id, student_id, lesson_id, kind, value, comment, teacher_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(course.id, req.body.student_id, lessonId, kind, req.body.value, req.body.comment || null, req.user.id);
  db.audit(req.user.id, 'create', 'grades', info.lastInsertRowid, req.body);
  res.status(201).json(db.prepare('SELECT * FROM grades WHERE id = ?').get(info.lastInsertRowid));
});

router.post('/bulk', teacherOrAdmin, (req, res) => {
  required(req.body, ['course_load_id', 'items']);
  const course = loadCourse(req, req.body.course_load_id);
  const kind = req.body.kind || 'current';
  if (!Array.isArray(req.body.items)) throw badRequest('items должен быть массивом');
  req.body.items.forEach(it => {
    validate(course, it.value, kind);
    assertStudentInGroup(it.student_id, course.group_id);
  });
  const find = db.prepare('SELECT id FROM grades WHERE course_load_id = ? AND student_id = ? AND kind = ?');
  const upd = db.prepare("UPDATE grades SET value = ?, teacher_id = ?, updated_at = datetime('now') WHERE id = ?");
  const ins = db.prepare('INSERT INTO grades (course_load_id, student_id, lesson_id, kind, value, teacher_id) VALUES (?, ?, ?, ?, ?, ?)');
  let saved = 0;
  db.transaction(() => {
    for (const it of req.body.items) {
      const ex = kind !== 'current' ? find.get(course.id, it.student_id, kind) : null;
      if (ex) upd.run(it.value, req.user.id, ex.id);
      else ins.run(course.id, it.student_id, req.body.lesson_id || null, kind, it.value, req.user.id);
      saved++;
    }
  })();
  db.audit(req.user.id, 'bulk_grades', 'course_loads', course.id, { kind, saved });
  res.json({ saved });
});

router.patch('/:id', teacherOrAdmin, (req, res) => {
  const grade = db.prepare('SELECT * FROM grades WHERE id = ?').get(req.params.id);
  if (!grade) throw notFound('Оценка не найдена');
  const course = loadCourse(req, grade.course_load_id);
  canChange(req, grade);
  const value = req.body.value ?? grade.value;
  validate(course, value, grade.kind);
  db.prepare("UPDATE grades SET value = ?, comment = ?, updated_at = datetime('now') WHERE id = ?")
    .run(value, req.body.comment ?? grade.comment, grade.id);
  db.audit(req.user.id, 'update', 'grades', grade.id, { from: grade.value, to: value });
  res.json(db.prepare('SELECT * FROM grades WHERE id = ?').get(grade.id));
});

router.delete('/:id', teacherOrAdmin, (req, res) => {
  const grade = db.prepare('SELECT * FROM grades WHERE id = ?').get(req.params.id);
  if (!grade) throw notFound('Оценка не найдена');
  loadCourse(req, grade.course_load_id);
  canChange(req, grade);
  db.prepare('DELETE FROM grades WHERE id = ?').run(grade.id);
  db.audit(req.user.id, 'delete', 'grades', grade.id, { value: grade.value });
  res.status(204).end();
});

module.exports = router;
