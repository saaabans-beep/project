const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf } = require('../lib/auth');
const { required, notFound, forbidden, badRequest } = require('../lib/http');

router.get('/', (req, res) => {
  const u = req.user;
  const instId = u.role === 'superadmin' ? institutionOf(req) : u.institution_id;
  const params = { instId };
  let extra = '';
  if (u.role === 'student') {
    extra = ' AND (a.group_id IS NULL OR a.group_id = @gid)';
    params.gid = u.group_id;
  }
  res.json(db.prepare(`
    SELECT a.*, u.full_name AS author_name, g.name AS group_name
    FROM announcements a JOIN users u ON u.id = a.author_id LEFT JOIN groups g ON g.id = a.group_id
    WHERE a.institution_id = @instId${extra}
    ORDER BY a.created_at DESC LIMIT 50
  `).all(params));
});

router.post('/', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  required(req.body, ['title', 'body']);
  const instId = institutionOf(req);
  if (req.body.group_id) {
    const g = db.prepare('SELECT institution_id FROM groups WHERE id = ?').get(req.body.group_id);
    if (!g || g.institution_id !== instId) throw badRequest('Группа не найдена');
  } else if (req.user.role === 'teacher') {
    throw forbidden('Преподаватель может писать только конкретной группе');
  }
  const info = db.prepare('INSERT INTO announcements (institution_id, author_id, group_id, title, body) VALUES (?, ?, ?, ?, ?)')
    .run(instId, req.user.id, req.body.group_id || null, req.body.title.trim(), req.body.body.trim());
  res.status(201).json(db.prepare('SELECT * FROM announcements WHERE id = ?').get(info.lastInsertRowid));
});

router.delete('/:id', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const a = db.prepare('SELECT * FROM announcements WHERE id = ?').get(req.params.id);
  if (!a) throw notFound();
  if (req.user.role === 'teacher' && a.author_id !== req.user.id) throw forbidden();
  if (req.user.role === 'admin' && a.institution_id !== req.user.institution_id) throw forbidden();
  db.prepare('DELETE FROM announcements WHERE id = ?').run(a.id);
  res.status(204).end();
});

module.exports = router;
