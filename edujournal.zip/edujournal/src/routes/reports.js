const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf, loadCourse, ensureSameInstitution } = require('../lib/auth');
const { forbidden, notFound, checkDate } = require('../lib/http');
const { courseSummary } = require('../lib/summary');
const grading = require('../lib/grading');
const { currentTerm } = require('./structure');

const staff = allow('superadmin', 'admin', 'teacher');
const admin = allow('superadmin', 'admin');
const today = () => new Date().toISOString().slice(0, 10);

function minutes(start, end) {
  const [h1, m1] = start.split(':').map(Number);
  const [h2, m2] = end.split(':').map(Number);
  return h2 * 60 + m2 - (h1 * 60 + m1);
}

router.get('/dashboard', (req, res) => {
  const u = req.user;
  const d = today();
  if (u.role === 'admin' || u.role === 'superadmin') {
    const instId = institutionOf(req);
    const count = (sql, ...p) => db.prepare(sql).get(instId, ...p).n;
    return res.json({
      students: count("SELECT COUNT(*) n FROM users WHERE institution_id = ? AND role = 'student' AND is_active = 1"),
      teachers: count("SELECT COUNT(*) n FROM users WHERE institution_id = ? AND role = 'teacher' AND is_active = 1"),
      groups: count('SELECT COUNT(*) n FROM groups WHERE institution_id = ?'),
      lessons_today: count(`
        SELECT COUNT(*) n FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id JOIN groups g ON g.id = cl.group_id
        WHERE g.institution_id = ? AND l.date = ? AND l.status != 'cancelled'`, d),
      unmarked_lessons: count(`
        SELECT COUNT(*) n FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id JOIN groups g ON g.id = cl.group_id
        WHERE g.institution_id = ? AND l.date < ? AND l.status = 'planned'`, d),
      term: currentTerm(instId) || null
    });
  }
  if (u.role === 'teacher') {
    const lessons = db.prepare(`
      SELECT l.id, l.start_time, l.end_time, l.status, g.name AS group_name, s.name AS subject_name, r.name AS room_name
      FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id
      JOIN groups g ON g.id = cl.group_id JOIN subjects s ON s.id = cl.subject_id
      LEFT JOIN rooms r ON r.id = l.room_id
      WHERE l.date = ? AND (cl.teacher_id = ? OR l.substitute_teacher_id = ?) AND l.status != 'cancelled'
      ORDER BY l.start_time
    `).all(d, u.id, u.id);
    const unmarked = db.prepare(`
      SELECT l.id, l.date, l.start_time, g.name AS group_name, s.name AS subject_name
      FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id
      JOIN groups g ON g.id = cl.group_id JOIN subjects s ON s.id = cl.subject_id
      WHERE l.date < ? AND l.status = 'planned' AND (cl.teacher_id = ? OR l.substitute_teacher_id = ?)
      ORDER BY l.date DESC LIMIT 20
    `).all(d, u.id, u.id);
    return res.json({ today: lessons, unmarked });
  }
  const lessons = db.prepare(`
    SELECT l.id, l.start_time, l.end_time, l.homework, s.name AS subject_name, t.full_name AS teacher_name, r.name AS room_name
    FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id
    JOIN subjects s ON s.id = cl.subject_id JOIN users t ON t.id = cl.teacher_id
    LEFT JOIN rooms r ON r.id = l.room_id
    WHERE l.date = ? AND cl.group_id = ? AND l.status != 'cancelled' ORDER BY l.start_time
  `).all(d, u.group_id);
  const exams = db.prepare(`
    SELECT e.id, e.date, e.start_time, e.kind, s.name AS subject_name, r.name AS room_name
    FROM exams e JOIN course_loads cl ON cl.id = e.course_load_id JOIN subjects s ON s.id = cl.subject_id
    LEFT JOIN rooms r ON r.id = e.room_id
    WHERE cl.group_id = ? AND e.date >= ? ORDER BY e.date LIMIT 10
  `).all(u.group_id, d);
  const recent = db.prepare(`
    SELECT g.value, g.kind, g.created_at, s.name AS subject_name FROM grades g
    JOIN course_loads cl ON cl.id = g.course_load_id JOIN subjects s ON s.id = cl.subject_id
    WHERE g.student_id = ? ORDER BY g.created_at DESC LIMIT 10
  `).all(u.id);
  res.json({ today: lessons, exams, recent_grades: recent });
});

function transcript(req, studentId) {
  const student = db.prepare(`
    SELECT u.id, u.full_name, u.institution_id, u.group_id, g.name AS group_name, i.name AS institution_name, i.type AS institution_type
    FROM users u LEFT JOIN groups g ON g.id = u.group_id JOIN institutions i ON i.id = u.institution_id
    WHERE u.id = ? AND u.role = 'student'
  `).get(studentId);
  if (!student) throw notFound('Студент не найден');
  if (req.user.role !== 'superadmin' && student.institution_id !== req.user.institution_id) throw forbidden();

  const loads = db.prepare(`
    SELECT cl.id, t.id AS term_id, t.name AS term_name, t.start_date
    FROM course_loads cl JOIN terms t ON t.id = cl.term_id
    WHERE cl.group_id = ? ORDER BY t.start_date, cl.id
  `).all(student.group_id);

  const asAdmin = { user: { ...req.user, role: 'superadmin' } };
  const terms = new Map();
  for (const l of loads) {
    const course = loadCourse(asAdmin, l.id);
    const sum = courseSummary(course, student.id);
    if (!terms.has(l.term_id)) terms.set(l.term_id, { term_id: l.term_id, term: l.term_name, subjects: [] });
    terms.get(l.term_id).subjects.push({
      subject: course.subject_name,
      credits: course.credits,
      ...sum
    });
  }
  const list = [...terms.values()].map(t => ({
    ...t,
    gpa: student.institution_type === 'school' ? null : grading.gpa(t.subjects),
    avg: student.institution_type === 'school'
      ? grading.round(grading.avg(t.subjects.map(s => s.quarter ?? s.suggestedQuarter)) ?? 0)
      : null
  }));
  const all = list.flatMap(t => t.subjects);
  return {
    student,
    terms: list,
    total_gpa: student.institution_type === 'school' ? null : grading.gpa(all),
    total_credits: all.filter(s => s.passed).reduce((a, s) => a + s.credits, 0),
    debts: all.filter(s => s.passed === false).map(s => s.subject)
  };
}

router.get('/transcript', allow('student'), (req, res) => res.json(transcript(req, req.user.id)));
router.get('/transcript/:studentId', staff, (req, res) => res.json(transcript(req, Number(req.params.studentId))));

router.get('/group/:groupId', staff, (req, res) => {
  const group = ensureSameInstitution(req, 'groups', req.params.groupId);
  const instId = group.institution_id;
  const termId = Number(req.query.term_id) || currentTerm(instId)?.id;
  const students = db.prepare("SELECT id, full_name FROM users WHERE group_id = ? AND role = 'student' AND is_active = 1 ORDER BY full_name").all(group.id);
  const loads = db.prepare('SELECT id FROM course_loads WHERE group_id = ? AND term_id = ?').all(group.id, termId || 0);
  const asAdmin = { user: { ...req.user, role: 'superadmin' } };
  const subjects = [];
  const risk = [];
  for (const { id } of loads) {
    const course = loadCourse(asAdmin, id);
    const rows = students.map(s => ({ student_id: s.id, full_name: s.full_name, ...courseSummary(course, s.id) }));
    const score = r => r.final ?? r.admission ?? r.currentAvg;
    const scores = rows.map(score).filter(v => v != null);
    subjects.push({
      course_load_id: id,
      subject: course.subject_name,
      average: scores.length ? grading.round(grading.avg(scores)) : null,
      students: rows
    });
    const lowLimit = course.institution_type === 'school' ? 3 : 50;
    rows.forEach(r => {
      const reasons = [];
      const sc = score(r);
      if (sc != null && sc < lowLimit) reasons.push(`низкий балл ${sc}`);
      if (r.attendance.percent != null && r.attendance.percent < 70) reasons.push(`посещаемость ${r.attendance.percent}%`);
      if (reasons.length) risk.push({ student_id: r.student_id, full_name: r.full_name, subject: course.subject_name, reasons });
    });
  }
  res.json({ group: { id: group.id, name: group.name }, term_id: termId || null, subjects, at_risk: risk });
});

router.get('/attendance', staff, (req, res) => {
  const instId = institutionOf(req);
  const from = req.query.from || new Date(Date.now() - 30 * 86_400_000).toISOString().slice(0, 10);
  const to = req.query.to || today();
  checkDate(from, to);
  const params = { instId, from, to };
  let extra = '';
  if (req.query.group_id) {
    extra = ' AND cl.group_id = @gid';
    params.gid = Number(req.query.group_id);
  }
  if (req.user.role === 'teacher') {
    extra += ' AND cl.teacher_id = @me';
    params.me = req.user.id;
  }
  const rows = db.prepare(`
    SELECT u.id AS student_id, u.full_name, g.name AS group_name,
      SUM(a.status = 'present') AS present, SUM(a.status = 'late') AS late,
      SUM(a.status = 'absent') AS absent, SUM(a.status = 'excused') AS excused, COUNT(*) AS total
    FROM attendance a
    JOIN lessons l ON l.id = a.lesson_id
    JOIN course_loads cl ON cl.id = l.course_load_id
    JOIN groups g ON g.id = cl.group_id
    JOIN users u ON u.id = a.student_id
    WHERE g.institution_id = @instId AND l.date BETWEEN @from AND @to${extra}
    GROUP BY u.id ORDER BY absent DESC, u.full_name
  `).all(params);
  res.json({
    from, to,
    rows: rows.map(r => ({ ...r, percent: r.total ? grading.round(((r.present + r.late) / r.total) * 100, 1) : null }))
  });
});

router.get('/teacher-load', admin, (req, res) => {
  const instId = institutionOf(req);
  const termId = Number(req.query.term_id) || currentTerm(instId)?.id || 0;
  const teachers = db.prepare("SELECT id, full_name FROM users WHERE institution_id = ? AND role = 'teacher' AND is_active = 1 ORDER BY full_name").all(instId);
  const slots = db.prepare(`
    SELECT cl.teacher_id, sc.start_time, sc.end_time FROM schedule sc JOIN course_loads cl ON cl.id = sc.course_load_id
    WHERE cl.term_id = ?
  `).all(termId);
  const lessons = db.prepare(`
    SELECT COALESCE(l.substitute_teacher_id, cl.teacher_id) AS teacher_id,
      SUM(l.status = 'done') AS done, SUM(l.status = 'planned') AS planned, SUM(l.status = 'cancelled') AS cancelled
    FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id
    WHERE cl.term_id = ? GROUP BY 1
  `).all(termId);
  const lmap = Object.fromEntries(lessons.map(l => [l.teacher_id, l]));
  res.json(teachers.map(t => {
    const mins = slots.filter(s => s.teacher_id === t.id).reduce((a, s) => a + minutes(s.start_time, s.end_time), 0);
    const l = lmap[t.id] || {};
    return {
      ...t,
      weekly_hours: grading.round(mins / 60, 1),
      pairs_per_week: slots.filter(s => s.teacher_id === t.id).length,
      done: l.done || 0, planned: l.planned || 0, cancelled: l.cancelled || 0
    };
  }));
});

router.get('/unmarked', admin, (req, res) => {
  const instId = institutionOf(req);
  res.json(db.prepare(`
    SELECT l.id, l.date, l.start_time, g.name AS group_name, s.name AS subject_name, t.full_name AS teacher_name
    FROM lessons l JOIN course_loads cl ON cl.id = l.course_load_id
    JOIN groups g ON g.id = cl.group_id JOIN subjects s ON s.id = cl.subject_id JOIN users t ON t.id = cl.teacher_id
    WHERE g.institution_id = ? AND l.date < ? AND l.status = 'planned'
    ORDER BY l.date DESC, t.full_name LIMIT 500
  `).all(instId, today()));
});

router.get('/audit', admin, (req, res) => {
  const instId = institutionOf(req);
  const limit = Math.min(Number(req.query.limit) || 100, 1000);
  res.json(db.prepare(`
    SELECT a.*, u.full_name FROM audit_log a LEFT JOIN users u ON u.id = a.user_id
    WHERE u.institution_id = ? OR (? = 1 AND u.role = 'superadmin')
    ORDER BY a.id DESC LIMIT ?
  `).all(instId, req.user.role === 'superadmin' ? 1 : 0, limit));
});

module.exports = router;
