const router = require('express').Router();
const db = require('../db');
const { allow } = require('../lib/auth');
const { required, pick, badRequest, notFound, updateRow } = require('../lib/http');

const TYPES = ['school', 'college', 'university'];

router.get('/', allow('superadmin'), (req, res) => {
  const rows = db.prepare(`
    SELECT i.*,
      (SELECT COUNT(*) FROM users u WHERE u.institution_id = i.id AND u.role = 'student') AS students,
      (SELECT COUNT(*) FROM users u WHERE u.institution_id = i.id AND u.role = 'teacher') AS teachers,
      (SELECT COUNT(*) FROM groups g WHERE g.institution_id = i.id) AS groups
    FROM institutions i ORDER BY i.name
  `).all();
  res.json(rows);
});

router.post('/', allow('superadmin'), (req, res) => {
  required(req.body, ['name', 'type']);
  if (!TYPES.includes(req.body.type)) throw badRequest('type: school | college | university');
  const info = db.prepare('INSERT INTO institutions (name, type, address) VALUES (?, ?, ?)')
    .run(req.body.name.trim(), req.body.type, req.body.address || null);
  db.audit(req.user.id, 'create', 'institutions', info.lastInsertRowid, req.body);
  res.status(201).json(db.prepare('SELECT * FROM institutions WHERE id = ?').get(info.lastInsertRowid));
});

router.patch('/:id', allow('superadmin'), (req, res) => {
  const data = pick(req.body, ['name', 'type', 'address']);
  if (data.type && !TYPES.includes(data.type)) throw badRequest('Неверный тип');
  if (!updateRow(db, 'institutions', req.params.id, data)) throw notFound();
  res.json(db.prepare('SELECT * FROM institutions WHERE id = ?').get(req.params.id));
});

router.delete('/:id', allow('superadmin'), (req, res) => {
  const r = db.prepare('DELETE FROM institutions WHERE id = ?').run(req.params.id);
  if (!r.changes) throw notFound();
  db.audit(req.user.id, 'delete', 'institutions', Number(req.params.id));
  res.status(204).end();
});

module.exports = router;
