const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf, ensureSameInstitution } = require('../lib/auth');
const { required, pick, badRequest, notFound, conflict, isUnique, checkDate, updateRow } = require('../lib/http');

const admin = allow('superadmin', 'admin');
const staff = allow('superadmin', 'admin', 'teacher');

function crud(name, fields, requiredFields, listSql) {
  router.get(`/${name}`, staff, (req, res) => {
    res.json(db.prepare(listSql).all(institutionOf(req)));
  });

  router.post(`/${name}`, admin, (req, res) => {
    required(req.body, requiredFields);
    const instId = institutionOf(req);
    const data = pick(req.body, fields);
    const cols = ['institution_id', ...Object.keys(data)];
    try {
      const info = db.prepare(
        `INSERT INTO ${name} (${cols.join(', ')}) VALUES (${cols.map(c => '@' + c).join(', ')})`
      ).run({ institution_id: instId, ...data });
      db.audit(req.user.id, 'create', name, info.lastInsertRowid, data);
      res.status(201).json(db.prepare(`SELECT * FROM ${name} WHERE id = ?`).get(info.lastInsertRowid));
    } catch (e) {
      if (isUnique(e)) throw conflict('Такая запись уже существует');
      throw e;
    }
  });

  router.patch(`/${name}/:id`, admin, (req, res) => {
    ensureSameInstitution(req, name, req.params.id);
    const data = pick(req.body, fields);
    updateRow(db, name, req.params.id, data);
    db.audit(req.user.id, 'update', name, Number(req.params.id), data);
    res.json(db.prepare(`SELECT * FROM ${name} WHERE id = ?`).get(req.params.id));
  });

  router.delete(`/${name}/:id`, admin, (req, res) => {
    ensureSameInstitution(req, name, req.params.id);
    db.prepare(`DELETE FROM ${name} WHERE id = ?`).run(req.params.id);
    db.audit(req.user.id, 'delete', name, Number(req.params.id));
    res.status(204).end();
  });
}

crud('groups', ['name', 'year', 'speciality', 'curator_id'], ['name'], `
  SELECT g.*, c.full_name AS curator_name,
    (SELECT COUNT(*) FROM users u WHERE u.group_id = g.id AND u.is_active = 1) AS students
  FROM groups g LEFT JOIN users c ON c.id = g.curator_id
  WHERE g.institution_id = ? ORDER BY g.year, g.name
`);

crud('subjects', ['name', 'code', 'credits', 'hours'], ['name'],
  'SELECT * FROM subjects WHERE institution_id = ? ORDER BY name');

crud('rooms', ['name', 'capacity'], ['name'],
  'SELECT * FROM rooms WHERE institution_id = ? ORDER BY name');

router.get('/terms', (req, res) => {
  const instId = req.user.role === 'superadmin' ? institutionOf(req) : req.user.institution_id;
  res.json(db.prepare('SELECT * FROM terms WHERE institution_id = ? ORDER BY start_date DESC').all(instId));
});

router.post('/terms', admin, (req, res) => {
  required(req.body, ['name', 'start_date', 'end_date']);
  checkDate(req.body.start_date, req.body.end_date);
  if (req.body.start_date > req.body.end_date) throw badRequest('Дата начала позже даты окончания');
  const instId = institutionOf(req);
  const tx = db.transaction(() => {
    if (req.body.is_current) db.prepare('UPDATE terms SET is_current = 0 WHERE institution_id = ?').run(instId);
    return db.prepare('INSERT INTO terms (institution_id, name, start_date, end_date, is_current) VALUES (?, ?, ?, ?, ?)')
      .run(instId, req.body.name, req.body.start_date, req.body.end_date, req.body.is_current ? 1 : 0);
  });
  const info = tx();
  res.status(201).json(db.prepare('SELECT * FROM terms WHERE id = ?').get(info.lastInsertRowid));
});

router.post('/terms/:id/activate', admin, (req, res) => {
  const term = ensureSameInstitution(req, 'terms', req.params.id);
  db.transaction(() => {
    db.prepare('UPDATE terms SET is_current = 0 WHERE institution_id = ?').run(term.institution_id);
    db.prepare('UPDATE terms SET is_current = 1 WHERE id = ?').run(term.id);
  })();
  res.json({ ok: true });
});

router.delete('/terms/:id', admin, (req, res) => {
  ensureSameInstitution(req, 'terms', req.params.id);
  db.prepare('DELETE FROM terms WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

function currentTerm(instId) {
  return db.prepare('SELECT * FROM terms WHERE institution_id = ? AND is_current = 1').get(instId);
}

router.get('/course-loads', (req, res) => {
  const u = req.user;
  const instId = u.role === 'superadmin' ? institutionOf(req) : u.institution_id;
  const termId = Number(req.query.term_id) || currentTerm(instId)?.id;
  if (!termId) return res.json([]);
  const where = ['cl.term_id = @termId', 'g.institution_id = @instId'];
  const params = { termId, instId };
  if (u.role === 'teacher') {
    where.push('cl.teacher_id = @me');
    params.me = u.id;
  } else if (u.role === 'student') {
    where.push('cl.group_id = @group');
    params.group = u.group_id;
  }
  if (req.query.group_id) {
    where.push('cl.group_id = @gid');
    params.gid = Number(req.query.group_id);
  }
  if (req.query.teacher_id) {
    where.push('cl.teacher_id = @tid');
    params.tid = Number(req.query.teacher_id);
  }
  res.json(db.prepare(`
    SELECT cl.id, cl.term_id, cl.group_id, g.name AS group_name, cl.subject_id, s.name AS subject_name, s.credits,
           cl.teacher_id, t.full_name AS teacher_name,
           (SELECT COUNT(*) FROM lessons l WHERE l.course_load_id = cl.id) AS lessons_total,
           (SELECT COUNT(*) FROM lessons l WHERE l.course_load_id = cl.id AND l.status = 'done') AS lessons_done
    FROM course_loads cl
    JOIN groups g ON g.id = cl.group_id
    JOIN subjects s ON s.id = cl.subject_id
    JOIN users t ON t.id = cl.teacher_id
    WHERE ${where.join(' AND ')}
    ORDER BY g.name, s.name
  `).all(params));
});

router.post('/course-loads', admin, (req, res) => {
  required(req.body, ['group_id', 'subject_id', 'teacher_id']);
  const instId = institutionOf(req);
  const termId = Number(req.body.term_id) || currentTerm(instId)?.id;
  if (!termId) throw badRequest('Нет активного семестра, создайте его');
  const group = ensureSameInstitution(req, 'groups', req.body.group_id);
  ensureSameInstitution(req, 'subjects', req.body.subject_id);
  const teacher = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'teacher' AND is_active = 1").get(req.body.teacher_id);
  if (!teacher || teacher.institution_id !== group.institution_id) throw badRequest('Преподаватель не найден');
  try {
    const info = db.prepare('INSERT INTO course_loads (term_id, group_id, subject_id, teacher_id) VALUES (?, ?, ?, ?)')
      .run(termId, group.id, req.body.subject_id, teacher.id);
    db.audit(req.user.id, 'create', 'course_loads', info.lastInsertRowid, req.body);
    res.status(201).json(db.prepare('SELECT * FROM course_loads WHERE id = ?').get(info.lastInsertRowid));
  } catch (e) {
    if (isUnique(e)) throw conflict('У группы уже есть этот предмет в семестре');
    throw e;
  }
});

router.patch('/course-loads/:id', admin, (req, res) => {
  const cl = db.prepare('SELECT cl.*, g.institution_id FROM course_loads cl JOIN groups g ON g.id = cl.group_id WHERE cl.id = ?').get(req.params.id);
  if (!cl) throw notFound();
  if (req.user.role !== 'superadmin' && cl.institution_id !== req.user.institution_id) throw notFound();
  required(req.body, ['teacher_id']);
  const teacher = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'teacher'").get(req.body.teacher_id);
  if (!teacher || teacher.institution_id !== cl.institution_id) throw badRequest('Преподаватель не найден');
  db.prepare('UPDATE course_loads SET teacher_id = ? WHERE id = ?').run(teacher.id, cl.id);
  db.audit(req.user.id, 'reassign_teacher', 'course_loads', cl.id, { from: cl.teacher_id, to: teacher.id });
  res.json({ ok: true });
});

router.delete('/course-loads/:id', admin, (req, res) => {
  const cl = db.prepare('SELECT cl.*, g.institution_id FROM course_loads cl JOIN groups g ON g.id = cl.group_id WHERE cl.id = ?').get(req.params.id);
  if (!cl || (req.user.role !== 'superadmin' && cl.institution_id !== req.user.institution_id)) throw notFound();
  const graded = db.prepare('SELECT COUNT(*) AS n FROM grades WHERE course_load_id = ?').get(cl.id).n;
  if (graded && req.query.force !== '1') throw conflict(`По предмету уже выставлено ${graded} оценок. Добавьте ?force=1 для удаления`);
  db.prepare('DELETE FROM course_loads WHERE id = ?').run(cl.id);
  db.audit(req.user.id, 'delete', 'course_loads', cl.id);
  res.status(204).end();
});

module.exports = router;
module.exports.currentTerm = currentTerm;
