const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf } = require('../lib/auth');
const { required, badRequest, notFound, conflict, checkTime, checkDate } = require('../lib/http');
const { currentTerm } = require('./structure');

const admin = allow('superadmin', 'admin');
const DAYS = ['', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const TYPES = ['lecture', 'practice', 'lab', 'lesson'];

const baseSelect = `
  SELECT sc.id, sc.weekday, sc.start_time, sc.end_time, sc.lesson_type, sc.room_id, r.name AS room_name,
         cl.id AS course_load_id, cl.term_id, g.id AS group_id, g.name AS group_name,
         s.id AS subject_id, s.name AS subject_name, t.id AS teacher_id, t.full_name AS teacher_name
  FROM schedule sc
  JOIN course_loads cl ON cl.id = sc.course_load_id
  JOIN groups g ON g.id = cl.group_id
  JOIN subjects s ON s.id = cl.subject_id
  JOIN users t ON t.id = cl.teacher_id
  LEFT JOIN rooms r ON r.id = sc.room_id
`;

function loadCourseLoad(req, id) {
  const cl = db.prepare(`
    SELECT cl.*, g.institution_id FROM course_loads cl JOIN groups g ON g.id = cl.group_id WHERE cl.id = ?
  `).get(id);
  if (!cl) throw notFound('Нагрузка не найдена');
  if (req.user.role !== 'superadmin' && cl.institution_id !== req.user.institution_id) throw notFound('Нагрузка не найдена');
  return cl;
}

function findConflicts({ termId, weekday, start, end, teacherId, groupId, roomId, excludeId }) {
  return db.prepare(`
    ${baseSelect}
    WHERE cl.term_id = @termId AND sc.weekday = @weekday
      AND sc.start_time < @end AND @start < sc.end_time
      AND sc.id != @excludeId
      AND (cl.teacher_id = @teacherId OR cl.group_id = @groupId OR (@roomId IS NOT NULL AND sc.room_id = @roomId))
  `).all({ termId, weekday, start, end, teacherId, groupId, roomId: roomId || null, excludeId: excludeId || 0 })
    .map(c => ({
      ...c,
      reason: c.teacher_id === teacherId ? 'Преподаватель занят' : c.group_id === groupId ? 'У группы другая пара' : 'Аудитория занята'
    }));
}

function validateSlot(body) {
  required(body, ['weekday', 'start_time', 'end_time']);
  const weekday = Number(body.weekday);
  if (!(weekday >= 1 && weekday <= 7)) throw badRequest('weekday от 1 (Пн) до 7 (Вс)');
  checkTime(body.start_time, body.end_time);
  if (body.start_time >= body.end_time) throw badRequest('Начало пары должно быть раньше конца');
  if (body.lesson_type && !TYPES.includes(body.lesson_type)) throw badRequest('Неверный тип занятия');
  return weekday;
}

function checkRoom(req, roomId, instId) {
  if (!roomId) return;
  const room = db.prepare('SELECT institution_id FROM rooms WHERE id = ?').get(roomId);
  if (!room || room.institution_id !== instId) throw badRequest('Аудитория не найдена');
}

router.get('/', (req, res) => {
  const u = req.user;
  const instId = u.role === 'superadmin' ? institutionOf(req) : u.institution_id;
  const termId = Number(req.query.term_id) || currentTerm(instId)?.id;
  if (!termId) return res.json([]);
  const where = ['cl.term_id = @termId', 'g.institution_id = @instId'];
  const params = { termId, instId };
  if (u.role === 'student') {
    where.push('cl.group_id = @gid');
    params.gid = u.group_id;
  } else if (req.query.group_id) {
    where.push('cl.group_id = @gid');
    params.gid = Number(req.query.group_id);
  }
  if (u.role === 'teacher' && !req.query.group_id && !req.query.room_id) {
    where.push('cl.teacher_id = @tid');
    params.tid = u.id;
  } else if (req.query.teacher_id) {
    where.push('cl.teacher_id = @tid');
    params.tid = Number(req.query.teacher_id);
  }
  if (req.query.room_id) {
    where.push('sc.room_id = @rid');
    params.rid = Number(req.query.room_id);
  }
  const rows = db.prepare(`${baseSelect} WHERE ${where.join(' AND ')} ORDER BY sc.weekday, sc.start_time, g.name`).all(params);
  if (req.query.view === 'week') {
    const week = {};
    for (let d = 1; d <= 7; d++) week[DAYS[d]] = [];
    rows.forEach(r => week[DAYS[r.weekday]].push(r));
    return res.json(week);
  }
  res.json(rows);
});

router.post('/', admin, (req, res) => {
  required(req.body, ['course_load_id']);
  const weekday = validateSlot(req.body);
  const cl = loadCourseLoad(req, req.body.course_load_id);
  checkRoom(req, req.body.room_id, cl.institution_id);
  const conflicts = findConflicts({
    termId: cl.term_id, weekday, start: req.body.start_time, end: req.body.end_time,
    teacherId: cl.teacher_id, groupId: cl.group_id, roomId: req.body.room_id
  });
  if (conflicts.length && !req.body.ignore_conflicts) throw conflict('Накладка в расписании', conflicts);
  const info = db.prepare(`
    INSERT INTO schedule (course_load_id, weekday, start_time, end_time, room_id, lesson_type)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(cl.id, weekday, req.body.start_time, req.body.end_time, req.body.room_id || null, req.body.lesson_type || 'lecture');
  db.audit(req.user.id, 'create', 'schedule', info.lastInsertRowid, req.body);
  res.status(201).json(db.prepare(`${baseSelect} WHERE sc.id = ?`).get(info.lastInsertRowid));
});

router.post('/check', admin, (req, res) => {
  required(req.body, ['course_load_id']);
  const weekday = validateSlot(req.body);
  const cl = loadCourseLoad(req, req.body.course_load_id);
  res.json(findConflicts({
    termId: cl.term_id, weekday, start: req.body.start_time, end: req.body.end_time,
    teacherId: cl.teacher_id, groupId: cl.group_id, roomId: req.body.room_id, excludeId: req.body.exclude_id
  }));
});

router.patch('/:id', admin, (req, res) => {
  const slot = db.prepare('SELECT * FROM schedule WHERE id = ?').get(req.params.id);
  if (!slot) throw notFound();
  const cl = loadCourseLoad(req, slot.course_load_id);
  const merged = { ...slot, ...req.body };
  const weekday = validateSlot(merged);
  checkRoom(req, merged.room_id, cl.institution_id);
  const conflicts = findConflicts({
    termId: cl.term_id, weekday, start: merged.start_time, end: merged.end_time,
    teacherId: cl.teacher_id, groupId: cl.group_id, roomId: merged.room_id, excludeId: slot.id
  });
  if (conflicts.length && !req.body.ignore_conflicts) throw conflict('Накладка в расписании', conflicts);
  db.prepare('UPDATE schedule SET weekday = ?, start_time = ?, end_time = ?, room_id = ?, lesson_type = ? WHERE id = ?')
    .run(weekday, merged.start_time, merged.end_time, merged.room_id || null, merged.lesson_type, slot.id);
  if (req.body.update_future_lessons) {
    const today = new Date().toISOString().slice(0, 10);
    db.prepare(`
      UPDATE lessons SET start_time = ?, end_time = ?, room_id = ?
      WHERE schedule_id = ? AND date >= ? AND status = 'planned'
    `).run(merged.start_time, merged.end_time, merged.room_id || null, slot.id, today);
  }
  db.audit(req.user.id, 'update', 'schedule', slot.id, req.body);
  res.json(db.prepare(`${baseSelect} WHERE sc.id = ?`).get(slot.id));
});

router.delete('/:id', admin, (req, res) => {
  const slot = db.prepare('SELECT * FROM schedule WHERE id = ?').get(req.params.id);
  if (!slot) throw notFound();
  loadCourseLoad(req, slot.course_load_id);
  const today = new Date().toISOString().slice(0, 10);
  db.transaction(() => {
    db.prepare(`
      DELETE FROM lessons WHERE schedule_id = ? AND date >= ? AND status = 'planned'
        AND NOT EXISTS (SELECT 1 FROM attendance a WHERE a.lesson_id = lessons.id)
    `).run(slot.id, today);
    db.prepare('DELETE FROM schedule WHERE id = ?').run(slot.id);
  })();
  db.audit(req.user.id, 'delete', 'schedule', slot.id);
  res.status(204).end();
});

function isoWeekday(dateStr) {
  const d = new Date(dateStr + 'T00:00:00Z').getUTCDay();
  return d === 0 ? 7 : d;
}

function* eachDate(from, to) {
  const d = new Date(from + 'T00:00:00Z');
  const end = new Date(to + 'T00:00:00Z');
  while (d <= end) {
    yield d.toISOString().slice(0, 10);
    d.setUTCDate(d.getUTCDate() + 1);
  }
}

router.post('/generate-lessons', admin, (req, res) => {
  const instId = institutionOf(req);
  const term = req.body.term_id
    ? db.prepare('SELECT * FROM terms WHERE id = ? AND institution_id = ?').get(req.body.term_id, instId)
    : currentTerm(instId);
  if (!term) throw badRequest('Семестр не найден');
  const from = req.body.from || term.start_date;
  const to = req.body.to || term.end_date;
  checkDate(from, to);
  if (from > to) throw badRequest('from позже to');
  const holidays = new Set(Array.isArray(req.body.holidays) ? req.body.holidays : []);

  const params = { termId: term.id, instId };
  let extra = '';
  if (req.body.group_id) {
    extra = ' AND cl.group_id = @gid';
    params.gid = Number(req.body.group_id);
  }
  const slots = db.prepare(`
    SELECT sc.*, cl.id AS clid FROM schedule sc
    JOIN course_loads cl ON cl.id = sc.course_load_id
    JOIN groups g ON g.id = cl.group_id
    WHERE cl.term_id = @termId AND g.institution_id = @instId${extra}
  `).all(params);

  const byDay = {};
  slots.forEach(s => (byDay[s.weekday] ||= []).push(s));
  const insert = db.prepare(`
    INSERT OR IGNORE INTO lessons (course_load_id, schedule_id, date, start_time, end_time, room_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  let created = 0;
  db.transaction(() => {
    for (const date of eachDate(from, to)) {
      if (holidays.has(date)) continue;
      for (const s of byDay[isoWeekday(date)] || []) {
        created += insert.run(s.clid, s.id, date, s.start_time, s.end_time, s.room_id).changes;
      }
    }
  })();
  db.audit(req.user.id, 'generate_lessons', 'lessons', null, { from, to, created });
  res.json({ from, to, slots: slots.length, created });
});

module.exports = router;
module.exports.isoWeekday = isoWeekday;
