const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { sign, authenticate } = require('../lib/auth');
const { HttpError, required, badRequest } = require('../lib/http');

const attempts = new Map();

router.post('/login', (req, res) => {
  required(req.body, ['login', 'password']);
  const key = `${req.ip}:${req.body.login}`;
  const rec = attempts.get(key) || { count: 0, until: 0 };
  if (rec.until > Date.now()) throw new HttpError(429, 'Слишком много попыток, подождите минуту');

  const user = db.prepare('SELECT * FROM users WHERE login = ?').get(String(req.body.login).trim());
  if (!user || !bcrypt.compareSync(String(req.body.password), user.password_hash)) {
    rec.count += 1;
    if (rec.count >= 5) {
      rec.until = Date.now() + 60_000;
      rec.count = 0;
    }
    attempts.set(key, rec);
    throw new HttpError(401, 'Неверный логин или пароль');
  }
  if (!user.is_active) throw new HttpError(403, 'Учетная запись заблокирована');
  attempts.delete(key);
  db.audit(user.id, 'login', 'users', user.id);
  res.json({
    token: sign(user),
    user: { id: user.id, role: user.role, full_name: user.full_name, institution_id: user.institution_id }
  });
});

router.get('/me', authenticate, (req, res) => {
  const me = db.prepare(`
    SELECT u.id, u.role, u.login, u.full_name, u.email, u.phone, u.institution_id, u.group_id,
           i.name AS institution_name, i.type AS institution_type, g.name AS group_name
    FROM users u
    LEFT JOIN institutions i ON i.id = u.institution_id
    LEFT JOIN groups g ON g.id = u.group_id
    WHERE u.id = ?
  `).get(req.user.id);
  res.json(me);
});

router.post('/change-password', authenticate, (req, res) => {
  required(req.body, ['old_password', 'new_password']);
  if (String(req.body.new_password).length < 6) throw badRequest('Пароль должен быть не короче 6 символов');
  const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
  if (!bcrypt.compareSync(String(req.body.old_password), user.password_hash)) throw badRequest('Старый пароль неверен');
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(String(req.body.new_password), 10), req.user.id);
  db.audit(req.user.id, 'change_password', 'users', req.user.id);
  res.json({ ok: true });
});

module.exports = router;
