const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf, loadCourse } = require('../lib/auth');
const { required, pick, badRequest, notFound, forbidden, conflict, isUnique, checkTime, checkDate, updateRow } = require('../lib/http');

const EDIT_DAYS = Number(process.env.EDIT_DAYS) || 7;
const STATUSES = ['present', 'absent', 'late', 'excused'];

const select = `
  SELECT l.*, r.name AS room_name, cl.group_id, g.name AS group_name, cl.subject_id, s.name AS subject_name,
         cl.teacher_id, t.full_name AS teacher_name, st.full_name AS substitute_name
  FROM lessons l
  JOIN course_loads cl ON cl.id = l.course_load_id
  JOIN groups g ON g.id = cl.group_id
  JOIN subjects s ON s.id = cl.subject_id
  JOIN users t ON t.id = cl.teacher_id
  LEFT JOIN users st ON st.id = l.substitute_teacher_id
  LEFT JOIN rooms r ON r.id = l.room_id
`;

const today = () => new Date().toISOString().slice(0, 10);

function daysBetween(a, b) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);
}

function getLesson(req, id) {
  const lesson = db.prepare(`${select} WHERE l.id = ?`).get(id);
  if (!lesson) throw notFound('Занятие не найдено');
  const course = loadCourse(req, lesson.course_load_id);
  const u = req.user;
  if (u.role === 'teacher' && lesson.teacher_id !== u.id && lesson.substitute_teacher_id !== u.id) throw forbidden();
  return { lesson, course };
}

function canEditJournal(req, lesson) {
  if (['admin', 'superadmin'].includes(req.user.role)) return;
  if (req.user.role !== 'teacher') throw forbidden();
  if (lesson.date > today()) throw badRequest('Занятие еще не наступило');
  if (daysBetween(lesson.date, today()) > EDIT_DAYS) {
    throw forbidden(`Журнал закрыт: прошло больше ${EDIT_DAYS} дней. Обратитесь к администратору`);
  }
  if (lesson.status === 'cancelled') throw badRequest('Занятие отменено');
}

router.get('/', (req, res) => {
  const u = req.user;
  const instId = u.role === 'superadmin' ? institutionOf(req) : u.institution_id;
  const where = ['g.institution_id = @instId'];
  const params = { instId };
  const from = req.query.from || req.query.date || today();
  const to = req.query.to || req.query.date || from;
  checkDate(from, to);
  where.push('l.date BETWEEN @from AND @to');
  Object.assign(params, { from, to });
  if (u.role === 'teacher') {
    where.push('(cl.teacher_id = @me OR l.substitute_teacher_id = @me)');
    params.me = u.id;
  }
  if (u.role === 'student') {
    where.push('cl.group_id = @gid');
    params.gid = u.group_id;
  } else if (req.query.group_id) {
    where.push('cl.group_id = @gid');
    params.gid = Number(req.query.group_id);
  }
  if (req.query.course_load_id) {
    where.push('l.course_load_id = @clid');
    params.clid = Number(req.query.course_load_id);
  }
  if (req.query.teacher_id && u.role !== 'teacher') {
    where.push('(cl.teacher_id = @tid OR l.substitute_teacher_id = @tid)');
    params.tid = Number(req.query.teacher_id);
  }
  res.json(db.prepare(`${select} WHERE ${where.join(' AND ')} ORDER BY l.date, l.start_time`).all(params));
});

router.get('/:id', (req, res) => {
  const { lesson, course } = getLesson(req, req.params.id);
  if (req.user.role === 'student') {
    const att = db.prepare('SELECT status FROM attendance WHERE lesson_id = ? AND student_id = ?').get(lesson.id, req.user.id);
    const grades = db.prepare('SELECT id, kind, value, comment FROM grades WHERE lesson_id = ? AND student_id = ?').all(lesson.id, req.user.id);
    return res.json({ ...lesson, my_attendance: att?.status || null, my_grades: grades });
  }
  const students = db.prepare(`
    SELECT u.id, u.full_name, a.status AS attendance
    FROM users u LEFT JOIN attendance a ON a.student_id = u.id AND a.lesson_id = ?
    WHERE u.group_id = ? AND u.role = 'student' AND u.is_active = 1
    ORDER BY u.full_name
  `).all(lesson.id, course.group_id);
  const grades = db.prepare('SELECT id, student_id, kind, value, comment FROM grades WHERE lesson_id = ?').all(lesson.id);
  const byStudent = {};
  grades.forEach(g => (byStudent[g.student_id] ||= []).push(g));
  res.json({ ...lesson, students: students.map(s => ({ ...s, grades: byStudent[s.id] || [] })) });
});

function teacherBusy(teacherId, date, start, end, excludeId) {
  return db.prepare(`
    SELECT l.id, l.date, l.start_time, l.end_time, g.name AS group_name FROM lessons l
    JOIN course_loads cl ON cl.id = l.course_load_id
    JOIN groups g ON g.id = cl.group_id
    WHERE l.date = ? AND l.status != 'cancelled' AND l.id != ?
      AND (cl.teacher_id = ? OR l.substitute_teacher_id = ?)
      AND l.start_time < ? AND ? < l.end_time
  `).all(date, excludeId || 0, teacherId, teacherId, end, start);
}

router.post('/', allow('superadmin', 'admin'), (req, res) => {
  required(req.body, ['course_load_id', 'date', 'start_time', 'end_time']);
  checkDate(req.body.date);
  checkTime(req.body.start_time, req.body.end_time);
  if (req.body.start_time >= req.body.end_time) throw badRequest('Неверный интервал');
  const course = loadCourse(req, req.body.course_load_id);
  const busy = teacherBusy(course.teacher_id, req.body.date, req.body.start_time, req.body.end_time);
  if (busy.length && !req.body.ignore_conflicts) throw conflict('Преподаватель занят в это время', busy);
  try {
    const info = db.prepare(`
      INSERT INTO lessons (course_load_id, date, start_time, end_time, room_id, topic)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(course.id, req.body.date, req.body.start_time, req.body.end_time, req.body.room_id || null, req.body.topic || null);
    db.audit(req.user.id, 'create', 'lessons', info.lastInsertRowid, req.body);
    res.status(201).json(db.prepare(`${select} WHERE l.id = ?`).get(info.lastInsertRowid));
  } catch (e) {
    if (isUnique(e)) throw conflict('Занятие на это время уже есть');
    throw e;
  }
});

router.patch('/:id', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const { lesson } = getLesson(req, req.params.id);
  const isAdmin = req.user.role !== 'teacher';
  const fields = isAdmin
    ? ['topic', 'homework', 'status', 'date', 'start_time', 'end_time', 'room_id', 'substitute_teacher_id']
    : ['topic', 'homework', 'status'];
  const data = pick(req.body, fields);
  if (data.status && !['planned', 'done', 'cancelled'].includes(data.status)) throw badRequest('Неверный статус');
  if (!isAdmin && data.status === 'cancelled') throw forbidden('Отменять занятия может только администратор');
  if (data.date) checkDate(data.date);
  if (data.start_time || data.end_time) checkTime(data.start_time || lesson.start_time, data.end_time || lesson.end_time);
  if (data.substitute_teacher_id) {
    const sub = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'teacher' AND is_active = 1").get(data.substitute_teacher_id);
    if (!sub || (req.user.role !== 'superadmin' && sub.institution_id !== req.user.institution_id)) throw badRequest('Преподаватель не найден');
    const busy = teacherBusy(sub.id, data.date || lesson.date, data.start_time || lesson.start_time, data.end_time || lesson.end_time, lesson.id);
    if (busy.length && !req.body.ignore_conflicts) throw conflict('Заменяющий преподаватель занят', busy);
  }
  if (!isAdmin) canEditJournal(req, lesson);
  updateRow(db, 'lessons', lesson.id, data);
  db.audit(req.user.id, 'update', 'lessons', lesson.id, data);
  res.json(db.prepare(`${select} WHERE l.id = ?`).get(lesson.id));
});

router.delete('/:id', allow('superadmin', 'admin'), (req, res) => {
  const { lesson } = getLesson(req, req.params.id);
  db.prepare('DELETE FROM lessons WHERE id = ?').run(lesson.id);
  db.audit(req.user.id, 'delete', 'lessons', lesson.id);
  res.status(204).end();
});

router.put('/:id/attendance', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const { lesson, course } = getLesson(req, req.params.id);
  canEditJournal(req, lesson);
  const items = req.body.items;
  if (!Array.isArray(items) || !items.length) throw badRequest('Передайте items: [{student_id, status}]');
  const groupStudents = new Set(
    db.prepare("SELECT id FROM users WHERE group_id = ? AND role = 'student'").all(course.group_id).map(r => r.id)
  );
  for (const it of items) {
    if (!groupStudents.has(Number(it.student_id))) throw badRequest(`Студент ${it.student_id} не из этой группы`);
    if (!STATUSES.includes(it.status)) throw badRequest(`Статус: ${STATUSES.join(', ')}`);
  }
  const upsert = db.prepare(`
    INSERT INTO attendance (lesson_id, student_id, status, marked_by) VALUES (?, ?, ?, ?)
    ON CONFLICT (lesson_id, student_id) DO UPDATE SET status = excluded.status, marked_by = excluded.marked_by, marked_at = datetime('now')
  `);
  db.transaction(() => {
    items.forEach(it => upsert.run(lesson.id, it.student_id, it.status, req.user.id));
    if (lesson.status === 'planned') db.prepare("UPDATE lessons SET status = 'done' WHERE id = ?").run(lesson.id);
  })();
  db.audit(req.user.id, 'attendance', 'lessons', lesson.id, { count: items.length });
  res.json({ ok: true, saved: items.length });
});

module.exports = router;
module.exports.getLesson = getLesson;
module.exports.canEditJournal = canEditJournal;
