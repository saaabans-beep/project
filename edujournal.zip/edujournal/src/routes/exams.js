const router = require('express').Router();
const db = require('../db');
const { allow, institutionOf, loadCourse } = require('../lib/auth');
const { required, badRequest, notFound, forbidden, conflict, checkDate, checkTime } = require('../lib/http');
const { courseSummary } = require('../lib/summary');
const grading = require('../lib/grading');

const admin = allow('superadmin', 'admin');
const KINDS = ['final', 'midterm', 'retake', 'credit'];

const select = `
  SELECT e.*, cl.group_id, g.name AS group_name, s.name AS subject_name, cl.teacher_id,
         COALESCE(ex.full_name, t.full_name) AS examiner_name, r.name AS room_name
  FROM exams e
  JOIN course_loads cl ON cl.id = e.course_load_id
  JOIN groups g ON g.id = cl.group_id
  JOIN subjects s ON s.id = cl.subject_id
  JOIN users t ON t.id = cl.teacher_id
  LEFT JOIN users ex ON ex.id = e.examiner_id
  LEFT JOIN rooms r ON r.id = e.room_id
`;

function getExam(req, id) {
  const exam = db.prepare(`${select} WHERE e.id = ?`).get(id);
  if (!exam) throw notFound('Экзамен не найден');
  const course = loadCourse(req, exam.course_load_id, { anyTeacher: exam.examiner_id === req.user.id });
  return { exam, course };
}

function isExaminer(req, exam) {
  if (req.user.role !== 'teacher') return true;
  return (exam.examiner_id || exam.teacher_id) === req.user.id;
}

router.get('/', (req, res) => {
  const u = req.user;
  const instId = u.role === 'superadmin' ? institutionOf(req) : u.institution_id;
  const where = ['g.institution_id = @instId'];
  const params = { instId };
  if (u.role === 'student') {
    where.push('cl.group_id = @gid');
    params.gid = u.group_id;
  } else if (req.query.group_id) {
    where.push('cl.group_id = @gid');
    params.gid = Number(req.query.group_id);
  }
  if (u.role === 'teacher') {
    where.push('(cl.teacher_id = @me OR e.examiner_id = @me)');
    params.me = u.id;
  }
  if (req.query.from) {
    where.push('e.date >= @from');
    params.from = req.query.from;
  }
  if (req.query.to) {
    where.push('e.date <= @to');
    params.to = req.query.to;
  }
  const rows = db.prepare(`${select} WHERE ${where.join(' AND ')} ORDER BY e.date, e.start_time`).all(params);
  if (u.role === 'student') {
    const res2 = db.prepare('SELECT score, absent FROM exam_results WHERE exam_id = ? AND student_id = ?');
    return res.json(rows.map(r => ({ ...r, my_result: r.is_closed ? res2.get(r.id, u.id) || null : null })));
  }
  res.json(rows);
});

router.post('/', admin, (req, res) => {
  required(req.body, ['course_load_id', 'date', 'start_time']);
  checkDate(req.body.date);
  checkTime(req.body.start_time);
  const kind = req.body.kind || 'final';
  if (!KINDS.includes(kind)) throw badRequest(`kind: ${KINDS.join(', ')}`);
  const course = loadCourse(req, req.body.course_load_id);
  const groupBusy = db.prepare(`
    SELECT e.id FROM exams e JOIN course_loads cl ON cl.id = e.course_load_id
    WHERE cl.group_id = ? AND e.date = ? AND e.kind != 'retake'
  `).get(course.group_id, req.body.date);
  if (groupBusy && kind !== 'retake' && !req.body.ignore_conflicts) throw conflict('У группы уже есть экзамен в этот день');
  const info = db.prepare(`
    INSERT INTO exams (course_load_id, kind, date, start_time, room_id, examiner_id) VALUES (?, ?, ?, ?, ?, ?)
  `).run(course.id, kind, req.body.date, req.body.start_time, req.body.room_id || null, req.body.examiner_id || null);
  db.audit(req.user.id, 'create', 'exams', info.lastInsertRowid, req.body);
  res.status(201).json(db.prepare(`${select} WHERE e.id = ?`).get(info.lastInsertRowid));
});

router.get('/:id', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const { exam, course } = getExam(req, req.params.id);
  const students = db.prepare(`
    SELECT u.id, u.full_name, er.score, er.absent
    FROM users u LEFT JOIN exam_results er ON er.student_id = u.id AND er.exam_id = ?
    WHERE u.group_id = ? AND u.role = 'student' AND u.is_active = 1
    ORDER BY u.full_name
  `).all(exam.id, course.group_id);
  res.json({
    ...exam,
    students: students.map(s => {
      const sum = courseSummary(course, s.id);
      return { ...s, admission: sum.admission ?? sum.currentAvg, admitted: sum.admitted ?? true, final: sum.final, letter: sum.letter };
    })
  });
});

router.put('/:id/results', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const { exam, course } = getExam(req, req.params.id);
  if (!isExaminer(req, exam)) throw forbidden('Вы не экзаменатор');
  if (exam.is_closed && req.user.role === 'teacher') throw forbidden('Ведомость закрыта');
  const items = req.body.items;
  if (!Array.isArray(items) || !items.length) throw badRequest('items: [{student_id, score, absent}]');
  const { min, max } = grading.scaleFor(course.institution_type);
  const inGroup = db.prepare("SELECT 1 FROM users WHERE id = ? AND group_id = ? AND role = 'student'");
  for (const it of items) {
    if (!inGroup.get(it.student_id, course.group_id)) throw badRequest(`Студент ${it.student_id} не из группы`);
    if (!it.absent && (it.score == null || it.score < min || it.score > max)) throw badRequest(`Балл от ${min} до ${max}`);
    if (course.institution_type !== 'school' && !it.absent && exam.kind !== 'retake') {
      const sum = courseSummary(course, it.student_id);
      if (sum.admitted === false && !req.body.force) throw badRequest(`Студент ${it.student_id} не допущен (рейтинг ${sum.admission})`);
    }
  }
  const upsert = db.prepare(`
    INSERT INTO exam_results (exam_id, student_id, score, absent) VALUES (?, ?, ?, ?)
    ON CONFLICT (exam_id, student_id) DO UPDATE SET score = excluded.score, absent = excluded.absent, updated_at = datetime('now')
  `);
  db.transaction(() => items.forEach(it => upsert.run(exam.id, it.student_id, it.absent ? null : it.score, it.absent ? 1 : 0)))();
  db.audit(req.user.id, 'exam_results', 'exams', exam.id, { count: items.length });
  res.json({ saved: items.length });
});

router.post('/:id/close', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const { exam } = getExam(req, req.params.id);
  if (!isExaminer(req, exam)) throw forbidden();
  db.prepare('UPDATE exams SET is_closed = 1 WHERE id = ?').run(exam.id);
  db.audit(req.user.id, 'close', 'exams', exam.id);
  res.json({ ok: true });
});

router.post('/:id/reopen', admin, (req, res) => {
  const { exam } = getExam(req, req.params.id);
  db.prepare('UPDATE exams SET is_closed = 0 WHERE id = ?').run(exam.id);
  db.audit(req.user.id, 'reopen', 'exams', exam.id);
  res.json({ ok: true });
});

router.delete('/:id', admin, (req, res) => {
  const { exam } = getExam(req, req.params.id);
  db.prepare('DELETE FROM exams WHERE id = ?').run(exam.id);
  db.audit(req.user.id, 'delete', 'exams', exam.id);
  res.status(204).end();
});

module.exports = router;
