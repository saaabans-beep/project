const router = require('express').Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');
const { allow, institutionOf } = require('../lib/auth');
const { required, pick, badRequest, notFound, forbidden, conflict, updateRow } = require('../lib/http');

const ROLES = ['admin', 'teacher', 'student'];

function genPassword() {
  return crypto.randomBytes(6).toString('base64url');
}

function translit(str) {
  const map = {
    а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm',
    н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch',
    ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya', ә: 'a', ғ: 'g', қ: 'k', ң: 'n', ө: 'o', ұ: 'u', ү: 'u', һ: 'h', і: 'i'
  };
  return str.toLowerCase().split('').map(c => map[c] ?? c).join('').replace(/[^a-z0-9]/g, '');
}

function makeLogin(fullName) {
  const parts = fullName.trim().split(/\s+/);
  const base = (translit(parts[0] || 'user') + (parts[1] ? '.' + translit(parts[1]).slice(0, 1) : '')) || 'user';
  let login = base;
  let n = 1;
  while (db.prepare('SELECT 1 FROM users WHERE login = ?').get(login)) login = `${base}${n++}`;
  return login;
}

function getUser(req, id) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!user) throw notFound('Пользователь не найден');
  if (req.user.role !== 'superadmin' && user.institution_id !== req.user.institution_id) throw forbidden();
  return user;
}

function checkGroup(instId, groupId) {
  if (!groupId) return;
  const g = db.prepare('SELECT institution_id FROM groups WHERE id = ?').get(groupId);
  if (!g || g.institution_id !== instId) throw badRequest('Группа не найдена в этом учебном заведении');
}

function createUser(instId, body) {
  required(body, ['full_name', 'role']);
  if (!ROLES.includes(body.role)) throw badRequest('role: admin | teacher | student');
  if (body.role === 'student') checkGroup(instId, body.group_id);
  const login = body.login ? String(body.login).trim() : makeLogin(body.full_name);
  if (db.prepare('SELECT 1 FROM users WHERE login = ?').get(login)) throw conflict(`Логин ${login} уже занят`);
  const password = body.password || genPassword();
  const info = db.prepare(`
    INSERT INTO users (institution_id, role, login, password_hash, full_name, email, phone, group_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    instId, body.role, login, bcrypt.hashSync(String(password), 10), body.full_name.trim(),
    body.email || null, body.phone || null, body.role === 'student' ? body.group_id || null : null
  );
  return { id: info.lastInsertRowid, login, password };
}

router.get('/', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const instId = institutionOf(req);
  const where = ['u.institution_id = @instId'];
  const params = { instId };
  if (req.query.role) {
    where.push('u.role = @role');
    params.role = req.query.role;
  }
  if (req.query.group_id) {
    where.push('u.group_id = @group_id');
    params.group_id = Number(req.query.group_id);
  }
  if (req.query.q) {
    where.push('(u.full_name LIKE @q OR u.login LIKE @q)');
    params.q = `%${req.query.q}%`;
  }
  if (req.user.role === 'teacher') where.push("u.role IN ('student', 'teacher')");
  const rows = db.prepare(`
    SELECT u.id, u.role, u.login, u.full_name, u.email, u.phone, u.group_id, g.name AS group_name, u.is_active, u.created_at
    FROM users u LEFT JOIN groups g ON g.id = u.group_id
    WHERE ${where.join(' AND ')}
    ORDER BY u.role, g.name, u.full_name
  `).all(params);
  res.json(rows);
});

router.get('/:id', allow('superadmin', 'admin', 'teacher'), (req, res) => {
  const u = getUser(req, req.params.id);
  delete u.password_hash;
  res.json(u);
});

router.post('/', allow('superadmin', 'admin'), (req, res) => {
  const instId = institutionOf(req);
  if (req.body.role === 'admin' && req.user.role !== 'superadmin') {
    throw forbidden('Создавать администраторов может только суперадмин');
  }
  const created = createUser(instId, req.body);
  db.audit(req.user.id, 'create', 'users', created.id, { role: req.body.role, login: created.login });
  res.status(201).json(created);
});

router.post('/import', allow('superadmin', 'admin'), (req, res) => {
  const instId = institutionOf(req);
  const list = req.body.users;
  if (!Array.isArray(list) || !list.length) throw badRequest('Передайте массив users');
  const result = [];
  const errors = [];
  const tx = db.transaction(() => {
    list.forEach((item, idx) => {
      try {
        if (item.role === 'admin') throw badRequest('Импорт админов запрещен');
        result.push({ full_name: item.full_name, ...createUser(instId, { role: 'student', ...item }) });
      } catch (e) {
        errors.push({ row: idx + 1, error: e.message });
      }
    });
  });
  tx();
  db.audit(req.user.id, 'import', 'users', null, { created: result.length, errors: errors.length });
  res.status(201).json({ created: result, errors });
});

router.patch('/:id', allow('superadmin', 'admin'), (req, res) => {
  const user = getUser(req, req.params.id);
  const data = pick(req.body, ['full_name', 'email', 'phone', 'group_id', 'is_active']);
  if (data.group_id !== undefined) {
    if (user.role !== 'student') throw badRequest('Группа назначается только студентам');
    checkGroup(user.institution_id, data.group_id);
  }
  if (data.is_active !== undefined) data.is_active = data.is_active ? 1 : 0;
  if (user.id === req.user.id && data.is_active === 0) throw badRequest('Нельзя заблокировать самого себя');
  updateRow(db, 'users', user.id, data);
  db.audit(req.user.id, 'update', 'users', user.id, data);
  const fresh = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  delete fresh.password_hash;
  res.json(fresh);
});

router.post('/:id/reset-password', allow('superadmin', 'admin'), (req, res) => {
  const user = getUser(req, req.params.id);
  const password = req.body.password || genPassword();
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(String(password), 10), user.id);
  db.audit(req.user.id, 'reset_password', 'users', user.id);
  res.json({ login: user.login, password });
});

router.delete('/:id', allow('superadmin', 'admin'), (req, res) => {
  const user = getUser(req, req.params.id);
  if (user.id === req.user.id) throw badRequest('Нельзя удалить самого себя');
  const hasData = db.prepare('SELECT 1 FROM grades WHERE student_id = ? OR teacher_id = ? LIMIT 1').get(user.id, user.id);
  if (hasData && req.query.force !== '1') {
    db.prepare('UPDATE users SET is_active = 0 WHERE id = ?').run(user.id);
    return res.json({ deactivated: true, message: 'У пользователя есть оценки, учетная запись заблокирована' });
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(user.id);
  db.audit(req.user.id, 'delete', 'users', user.id);
  res.status(204).end();
});

module.exports = router;
