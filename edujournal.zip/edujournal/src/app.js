const path = require('path');
const express = require('express');
const { authenticate } = require('./lib/auth');
const { HttpError } = require('./lib/http');

const app = express();

app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use('/api/auth', require('./routes/auth'));

const api = express.Router();
api.use(authenticate);
api.use('/institutions', require('./routes/institutions'));
api.use('/users', require('./routes/users'));
api.use('/', require('./routes/structure'));
api.use('/schedule', require('./routes/schedule'));
api.use('/lessons', require('./routes/lessons'));
api.use('/grades', require('./routes/grades'));
api.use('/exams', require('./routes/exams'));
api.use('/reports', require('./routes/reports'));
api.use('/announcements', require('./routes/announcements'));
app.use('/api', api);

app.use('/api', (req, res) => res.status(404).json({ error: 'Метод не найден' }));

app.use((err, req, res, next) => {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ error: err.message, details: err.details });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Некорректный JSON' });
  if (String(err.code).startsWith('SQLITE_CONSTRAINT')) {
    return res.status(409).json({ error: 'Нарушение целостности данных', details: err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

module.exports = app;
