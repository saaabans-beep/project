const state = {
  token: localStorage.getItem('token'),
  me: null
};

const $ = sel => document.querySelector(sel);
const view = () => $('#view');

const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const today = () => new Date().toISOString().slice(0, 10);
const addDays = (d, n) => {
  const x = new Date(d + 'T00:00:00Z');
  x.setUTCDate(x.getUTCDate() + n);
  return x.toISOString().slice(0, 10);
};
const fmtDate = d => (d ? d.slice(8, 10) + '.' + d.slice(5, 7) : '');
const DAYS = ['', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
const ROLE = { superadmin: 'Суперадмин', admin: 'Администратор', teacher: 'Преподаватель', student: 'Студент' };
const ATT = { present: 'Был', absent: 'Н', late: 'Опоздал', excused: 'Уваж.' };
const ATT_SHORT = { present: '', absent: 'н', late: 'оп', excused: 'у' };
const KIND = { current: 'Текущая', rk1: 'РК1', rk2: 'РК2', quarter: 'Четвертная' };
const LTYPE = { lecture: 'Лекция', practice: 'Практика', lab: 'Лаб.', lesson: 'Урок' };
const EXAM = { final: 'Экзамен', midterm: 'Промежуточный', retake: 'Пересдача', credit: 'Зачет' };

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  if (res.status === 401 && path !== '/auth/login') {
    logout();
    throw new Error('Сессия истекла');
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Ошибка');
    err.details = data.details;
    throw err;
  }
  return data;
}

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (bad ? ' bad' : '');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add('hidden'), 3500);
}

function showError(e) {
  let msg = e.message;
  if (Array.isArray(e.details) && e.details[0]?.reason) {
    msg += ': ' + e.details.map(d => `${d.reason} (${d.group_name}, ${d.subject_name} ${d.start_time}-${d.end_time})`).join('; ');
  }
  toast(msg, true);
}

function closeModal() {
  $('#modal').classList.add('hidden');
}

function modal(html, onReady) {
  $('#modalBody').innerHTML = html;
  $('#modal').classList.remove('hidden');
  onReady && onReady($('#modalBody'));
}

$('#modal').addEventListener('click', e => {
  if (e.target.id === 'modal') closeModal();
});

function field(f, value) {
  const v = value ?? f.value ?? '';
  if (f.type === 'select') {
    const opts = (f.options || []).map(o => `<option value="${esc(o.value)}" ${String(o.value) === String(v) ? 'selected' : ''}>${esc(o.label)}</option>`).join('');
    return `<label>${esc(f.label)}<select name="${f.name}">${f.empty ? `<option value="">${esc(f.empty)}</option>` : ''}${opts}</select></label>`;
  }
  if (f.type === 'textarea') return `<label>${esc(f.label)}<textarea name="${f.name}">${esc(v)}</textarea></label>`;
  if (f.type === 'checkbox') return `<label><span><input type="checkbox" name="${f.name}" style="width:auto" ${v ? 'checked' : ''}> ${esc(f.label)}</span></label>`;
  return `<label>${esc(f.label)}<input name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" ${f.required ? 'required' : ''} ${f.step ? `step="${f.step}"` : ''}></label>`;
}

function formModal(title, fields, data, onSubmit) {
  modal(`
    <h3>${esc(title)}</h3>
    <form class="form">
      ${fields.map(f => field(f, data?.[f.name])).join('')}
      <div class="actions">
        <button type="button" class="btn" data-close>Отмена</button>
        <button class="btn primary">Сохранить</button>
      </div>
    </form>
  `, root => {
    root.querySelector('[data-close]').onclick = closeModal;
    root.querySelector('form').onsubmit = async e => {
      e.preventDefault();
      const out = {};
      for (const f of fields) {
        const el = e.target.elements[f.name];
        if (f.type === 'checkbox') out[f.name] = el.checked;
        else if (el.value === '') out[f.name] = f.type === 'select' ? null : undefined;
        else out[f.name] = f.type === 'number' || f.numeric ? Number(el.value) : el.value;
      }
      try {
        await onSubmit(out);
        closeModal();
      } catch (err) {
        showError(err);
      }
    };
  });
}

function table(cols, rows, empty = 'Нет данных') {
  if (!rows.length) return `<p class="muted">${empty}</p>`;
  return `<table><thead><tr>${cols.map(c => `<th>${esc(c.title)}</th>`).join('')}</tr></thead><tbody>${
    rows.map(r => `<tr>${cols.map(c => `<td>${c.html ? c.html(r) : esc(c.get ? c.get(r) : r[c.key])}</td>`).join('')}</tr>`).join('')
  }</tbody></table>`;
}

function badgeScore(v, type) {
  if (v == null) return '<span class="muted">—</span>';
  const low = type === 'school' ? 3 : 50;
  const high = type === 'school' ? 4.5 : 85;
  return `<span class="badge ${v < low ? 'bad' : v >= high ? 'ok' : 'warn'}">${v}</span>`;
}

const cache = {};
async function lookup(name, path) {
  if (!cache[name]) cache[name] = await api(path);
  return cache[name];
}
const resetCache = (...names) => names.forEach(n => delete cache[n]);

const routes = {};
const menus = {
  superadmin: [['institutions', 'Учебные заведения']],
  admin: [
    ['home', 'Главная'], ['users', 'Пользователи'], ['groups', 'Группы'], ['subjects', 'Предметы'],
    ['rooms', 'Аудитории'], ['terms', 'Семестры'], ['loads', 'Нагрузка'], ['schedule', 'Расписание'],
    ['lessons', 'Занятия'], ['exams', 'Экзамены'], ['reports', 'Отчеты'], ['news', 'Объявления']
  ],
  teacher: [
    ['home', 'Главная'], ['loads', 'Мои предметы'], ['schedule', 'Расписание'], ['lessons', 'Занятия'],
    ['exams', 'Экзамены'], ['reports', 'Посещаемость'], ['news', 'Объявления']
  ],
  student: [
    ['home', 'Главная'], ['schedule', 'Расписание'], ['grades', 'Оценки'], ['transcript', 'Транскрипт'],
    ['exams', 'Экзамены'], ['news', 'Объявления']
  ]
};

function renderNav() {
  const items = menus[state.me.role];
  const current = location.hash.slice(1).split('/')[0] || items[0][0];
  $('#nav').innerHTML = items.map(([k, t]) => `<a href="#${k}" class="${k === current ? 'active' : ''}">${t}</a>`).join('');
}

async function router() {
  if (!state.me) return;
  const [name, ...args] = location.hash.slice(1).split('/');
  const items = menus[state.me.role];
  const route = name && routes[name] ? name : items[0][0];
  renderNav();
  $('.side').classList.remove('open');
  const label = items.find(i => i[0] === route)?.[1] || '';
  $('#title').textContent = label;
  view().innerHTML = '<p class="muted">Загрузка...</p>';
  try {
    await routes[route](...args);
  } catch (e) {
    view().innerHTML = `<div class="panel error">${esc(e.message)}</div>`;
  }
}

routes.home = async () => {
  const d = await api('/reports/dashboard');
  const role = state.me.role;
  if (role === 'admin') {
    view().innerHTML = `
      <div class="cards">
        <div class="card"><div class="muted">Студентов</div><div class="num">${d.students}</div></div>
        <div class="card"><div class="muted">Преподавателей</div><div class="num">${d.teachers}</div></div>
        <div class="card"><div class="muted">Групп</div><div class="num">${d.groups}</div></div>
        <div class="card"><div class="muted">Занятий сегодня</div><div class="num">${d.lessons_today}</div></div>
        <div class="card"><div class="muted">Незаполненных занятий</div><div class="num" style="color:${d.unmarked_lessons ? 'var(--bad)' : 'inherit'}">${d.unmarked_lessons}</div></div>
      </div>
      <div class="panel"><h3>Текущий семестр</h3>${d.term ? `${esc(d.term.name)} · ${d.term.start_date} — ${d.term.end_date}` : '<span class="muted">Не задан. Создайте его в разделе «Семестры»</span>'}</div>
      <div class="panel"><h3>Незаполненные журналы</h3><div id="unmarked"></div></div>
    `;
    const rows = await api('/reports/unmarked');
    $('#unmarked').innerHTML = table([
      { title: 'Дата', get: r => r.date }, { title: 'Время', key: 'start_time' }, { title: 'Группа', key: 'group_name' },
      { title: 'Предмет', key: 'subject_name' }, { title: 'Преподаватель', key: 'teacher_name' }
    ], rows.slice(0, 30), 'Все журналы заполнены');
    return;
  }
  if (role === 'teacher') {
    view().innerHTML = `
      <div class="grid2">
        <div class="panel"><h3>Сегодня</h3>${table([
          { title: 'Время', get: r => `${r.start_time}–${r.end_time}` }, { title: 'Группа', key: 'group_name' },
          { title: 'Предмет', key: 'subject_name' }, { title: 'Ауд.', key: 'room_name' },
          { title: '', html: r => `<a class="btn sm primary" href="#lesson/${r.id}">Отметить</a>` }
        ], d.today, 'Сегодня занятий нет')}</div>
        <div class="panel"><h3>Не отмечены</h3>${table([
          { title: 'Дата', get: r => fmtDate(r.date) }, { title: 'Группа', key: 'group_name' }, { title: 'Предмет', key: 'subject_name' },
          { title: '', html: r => `<a class="btn sm" href="#lesson/${r.id}">Открыть</a>` }
        ], d.unmarked, 'Все занятия отмечены')}</div>
      </div>`;
    return;
  }
  view().innerHTML = `
    <div class="grid2">
      <div class="panel"><h3>Сегодня</h3>${table([
        { title: 'Время', get: r => `${r.start_time}–${r.end_time}` }, { title: 'Предмет', key: 'subject_name' },
        { title: 'Преподаватель', key: 'teacher_name' }, { title: 'Ауд.', key: 'room_name' }
      ], d.today, 'Сегодня занятий нет')}</div>
      <div class="panel"><h3>Последние оценки</h3>${table([
        { title: 'Предмет', key: 'subject_name' }, { title: 'Тип', get: r => KIND[r.kind] },
        { title: 'Оценка', html: r => badgeScore(r.value, state.me.institution_type) }, { title: 'Дата', get: r => fmtDate(r.created_at) }
      ], d.recent_grades, 'Оценок пока нет')}</div>
    </div>
    <div class="panel"><h3>Ближайшие экзамены</h3>${table([
      { title: 'Дата', key: 'date' }, { title: 'Время', key: 'start_time' }, { title: 'Предмет', key: 'subject_name' },
      { title: 'Тип', get: r => EXAM[r.kind] }, { title: 'Ауд.', key: 'room_name' }
    ], d.exams, 'Экзаменов не запланировано')}</div>`;
};

routes.institutions = async () => {
  const rows = await api('/institutions');
  view().innerHTML = `
    <div class="toolbar"><button class="btn primary" id="add">Добавить заведение</button></div>
    <div class="panel">${table([
      { title: 'Название', key: 'name' }, { title: 'Тип', get: r => ({ school: 'Школа', college: 'Колледж', university: 'Университет' }[r.type]) },
      { title: 'Студентов', key: 'students' }, { title: 'Преподавателей', key: 'teachers' }, { title: 'Групп', key: 'groups' },
      { title: '', html: r => `<button class="btn sm" data-admin="${r.id}">Создать админа</button> <button class="btn sm danger" data-del="${r.id}">Удалить</button>` }
    ], rows)}</div>`;
  const typeField = { name: 'type', label: 'Тип', type: 'select', options: [
    { value: 'school', label: 'Школа' }, { value: 'college', label: 'Колледж' }, { value: 'university', label: 'Университет' }
  ] };
  $('#add').onclick = () => formModal('Новое учебное заведение', [
    { name: 'name', label: 'Название', required: true }, typeField, { name: 'address', label: 'Адрес' }
  ], null, async v => {
    await api('/institutions', { method: 'POST', body: v });
    router();
  });
  view().querySelectorAll('[data-admin]').forEach(b => (b.onclick = () => formModal('Администратор', [
    { name: 'full_name', label: 'ФИО', required: true }, { name: 'login', label: 'Логин (необязательно)' }, { name: 'password', label: 'Пароль (необязательно)' }
  ], null, async v => {
    const r = await api('/users', { method: 'POST', body: { ...v, role: 'admin', institution_id: Number(b.dataset.admin) } });
    alert(`Логин: ${r.login}\nПароль: ${r.password}`);
  })));
  view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
    if (!confirm('Удалить заведение со всеми данными?')) return;
    await api('/institutions/' + b.dataset.del, { method: 'DELETE' });
    router();
  }));
};

routes.users = async () => {
  const groups = await lookup('groups', '/groups');
  const params = new URLSearchParams(routes.users.filter || {});
  const rows = await api('/users?' + params);
  const f = routes.users.filter || {};
  view().innerHTML = `
    <div class="toolbar">
      <label>Роль<select id="fRole"><option value="">Все</option>${['admin', 'teacher', 'student'].map(r => `<option value="${r}" ${f.role === r ? 'selected' : ''}>${ROLE[r]}</option>`).join('')}</select></label>
      <label>Группа<select id="fGroup"><option value="">Все</option>${groups.map(g => `<option value="${g.id}" ${String(f.group_id) === String(g.id) ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></label>
      <label>Поиск<input id="fQ" value="${esc(f.q || '')}" placeholder="ФИО или логин"></label>
      <button class="btn" id="apply">Найти</button>
      <span style="flex:1"></span>
      <button class="btn" id="import">Импорт студентов</button>
      <button class="btn primary" id="add">Добавить</button>
    </div>
    <div class="panel">${table([
      { title: 'ФИО', key: 'full_name' }, { title: 'Логин', key: 'login' }, { title: 'Роль', get: r => ROLE[r.role] },
      { title: 'Группа', key: 'group_name' },
      { title: 'Статус', html: r => r.is_active ? '<span class="badge ok">Активен</span>' : '<span class="badge bad">Заблокирован</span>' },
      { title: '', html: r => `
        <button class="btn sm" data-edit="${r.id}">Изменить</button>
        <button class="btn sm" data-pass="${r.id}">Сброс пароля</button>
        ${r.role === 'student' ? `<a class="btn sm" href="#transcript/${r.id}">Транскрипт</a>` : ''}` }
    ], rows)}</div>`;
  const groupOptions = groups.map(g => ({ value: g.id, label: g.name }));
  $('#apply').onclick = () => {
    routes.users.filter = Object.fromEntries(Object.entries({ role: $('#fRole').value, group_id: $('#fGroup').value, q: $('#fQ').value }).filter(([, v]) => v));
    router();
  };
  $('#add').onclick = () => formModal('Новый пользователь', [
    { name: 'full_name', label: 'ФИО', required: true },
    { name: 'role', label: 'Роль', type: 'select', options: [{ value: 'student', label: 'Студент' }, { value: 'teacher', label: 'Преподаватель' }] },
    { name: 'group_id', label: 'Группа (для студента)', type: 'select', empty: '—', options: groupOptions, numeric: true },
    { name: 'login', label: 'Логин (сгенерируется, если пусто)' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'phone', label: 'Телефон' }
  ], null, async v => {
    const r = await api('/users', { method: 'POST', body: v });
    alert(`Пользователь создан\nЛогин: ${r.login}\nПароль: ${r.password}`);
    router();
  });
  $('#import').onclick = () => modal(`
    <h3>Импорт студентов</h3>
    <p class="muted">Одна строка — один студент: ФИО</p>
    <div class="form">
      <label>Группа<select id="impGroup">${groupOptions.map(o => `<option value="${o.value}">${esc(o.label)}</option>`).join('')}</select></label>
      <label>Список<textarea id="impList" style="min-height:180px"></textarea></label>
      <div class="actions"><button class="btn" data-close>Отмена</button><button class="btn primary" id="impGo">Импортировать</button></div>
    </div>`, root => {
    root.querySelector('[data-close]').onclick = closeModal;
    root.querySelector('#impGo').onclick = async () => {
      const users = $('#impList').value.split('\n').map(s => s.trim()).filter(Boolean)
        .map(full_name => ({ full_name, group_id: Number($('#impGroup').value) }));
      try {
        const r = await api('/users/import', { method: 'POST', body: { users } });
        const text = r.created.map(u => `${u.full_name};${u.login};${u.password}`).join('\n');
        modal(`<h3>Создано: ${r.created.length}</h3>${r.errors.length ? `<p class="error">Ошибок: ${r.errors.length}</p>` : ''}
          <p class="muted">Сохраните логины и пароли — повторно пароли не показываются</p>
          <textarea style="min-height:220px">${esc('ФИО;Логин;Пароль\n' + text)}</textarea>
          <div class="actions"><button class="btn primary" data-close>Готово</button></div>`, m => {
          m.querySelector('[data-close]').onclick = () => { closeModal(); router(); };
        });
      } catch (e) {
        showError(e);
      }
    };
  });
  view().querySelectorAll('[data-edit]').forEach(b => (b.onclick = () => {
    const u = rows.find(r => r.id === Number(b.dataset.edit));
    const fields = [
      { name: 'full_name', label: 'ФИО', required: true }, { name: 'email', label: 'Email' }, { name: 'phone', label: 'Телефон' },
      { name: 'is_active', label: 'Активен', type: 'checkbox' }
    ];
    if (u.role === 'student') fields.splice(1, 0, { name: 'group_id', label: 'Группа', type: 'select', options: groupOptions, numeric: true });
    formModal('Редактирование', fields, u, async v => {
      await api('/users/' + u.id, { method: 'PATCH', body: v });
      router();
    });
  }));
  view().querySelectorAll('[data-pass]').forEach(b => (b.onclick = async () => {
    if (!confirm('Сгенерировать новый пароль?')) return;
    const r = await api(`/users/${b.dataset.pass}/reset-password`, { method: 'POST', body: {} });
    alert(`Логин: ${r.login}\nНовый пароль: ${r.password}`);
  }));
};

function simpleCrud(name, path, cols, fields, extra) {
  routes[name] = async () => {
    const rows = await api(path);
    view().innerHTML = `
      <div class="toolbar"><button class="btn primary" id="add">Добавить</button></div>
      <div class="panel">${table([...cols, {
        title: '', html: r => `<button class="btn sm" data-edit="${r.id}">Изменить</button> <button class="btn sm danger" data-del="${r.id}">Удалить</button>`
      }], rows)}</div>`;
    const fs = typeof fields === 'function' ? await fields() : fields;
    $('#add').onclick = () => formModal('Добавить', fs, null, async v => {
      await api(path, { method: 'POST', body: v });
      resetCache(name);
      router();
    });
    view().querySelectorAll('[data-edit]').forEach(b => (b.onclick = () => {
      const row = rows.find(r => r.id === Number(b.dataset.edit));
      formModal('Изменить', fs, row, async v => {
        await api(`${path}/${row.id}`, { method: 'PATCH', body: v });
        resetCache(name);
        router();
      });
    }));
    view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
      if (!confirm('Удалить запись?')) return;
      try {
        await api(`${path}/${b.dataset.del}`, { method: 'DELETE' });
        resetCache(name);
        router();
      } catch (e) {
        showError(e);
      }
    }));
    extra && extra(rows);
  };
}

simpleCrud('groups', '/groups', [
  { title: 'Группа / класс', key: 'name' }, { title: 'Курс', key: 'year' }, { title: 'Специальность', key: 'speciality' },
  { title: 'Куратор', key: 'curator_name' }, { title: 'Студентов', key: 'students' },
  { title: '', html: r => `<a class="btn sm" href="#groupreport/${r.id}">Успеваемость</a>` }
], async () => {
  const teachers = await api('/users?role=teacher');
  return [
    { name: 'name', label: 'Название', required: true }, { name: 'year', label: 'Курс / класс', type: 'number' },
    { name: 'speciality', label: 'Специальность' },
    { name: 'curator_id', label: 'Куратор', type: 'select', empty: '—', numeric: true, options: teachers.map(t => ({ value: t.id, label: t.full_name })) }
  ];
});

simpleCrud('subjects', '/subjects', [
  { title: 'Предмет', key: 'name' }, { title: 'Код', key: 'code' }, { title: 'Кредиты', key: 'credits' }, { title: 'Часы', key: 'hours' }
], [
  { name: 'name', label: 'Название', required: true }, { name: 'code', label: 'Код' },
  { name: 'credits', label: 'Кредиты', type: 'number' }, { name: 'hours', label: 'Часы', type: 'number' }
]);

simpleCrud('rooms', '/rooms', [{ title: 'Аудитория', key: 'name' }, { title: 'Мест', key: 'capacity' }], [
  { name: 'name', label: 'Название', required: true }, { name: 'capacity', label: 'Вместимость', type: 'number' }
]);

routes.terms = async () => {
  const rows = await api('/terms');
  view().innerHTML = `
    <div class="toolbar"><button class="btn primary" id="add">Новый семестр</button></div>
    <div class="panel">${table([
      { title: 'Название', key: 'name' }, { title: 'Начало', key: 'start_date' }, { title: 'Конец', key: 'end_date' },
      { title: '', html: r => r.is_current ? '<span class="badge ok">Текущий</span>' : `<button class="btn sm" data-act="${r.id}">Сделать текущим</button>` },
      { title: '', html: r => `<button class="btn sm danger" data-del="${r.id}">Удалить</button>` }
    ], rows)}</div>
    <div class="panel"><h3>Сгенерировать занятия по расписанию</h3>
      <div class="toolbar">
        <label>С<input type="date" id="gFrom"></label><label>По<input type="date" id="gTo"></label>
        <label>Праздники (через запятую)<input id="gHol" placeholder="2026-12-16, 2026-12-17"></label>
        <button class="btn primary" id="gen">Сгенерировать</button>
      </div>
      <p class="muted">Без дат берутся границы текущего семестра. Уже созданные занятия не дублируются.</p>
    </div>`;
  $('#add').onclick = () => formModal('Новый семестр', [
    { name: 'name', label: 'Название', required: true }, { name: 'start_date', label: 'Начало', type: 'date', required: true },
    { name: 'end_date', label: 'Конец', type: 'date', required: true }, { name: 'is_current', label: 'Сделать текущим', type: 'checkbox' }
  ], null, async v => {
    await api('/terms', { method: 'POST', body: v });
    router();
  });
  view().querySelectorAll('[data-act]').forEach(b => (b.onclick = async () => {
    await api(`/terms/${b.dataset.act}/activate`, { method: 'POST', body: {} });
    router();
  }));
  view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
    if (!confirm('Удалить семестр вместе с нагрузкой и оценками?')) return;
    await api('/terms/' + b.dataset.del, { method: 'DELETE' });
    router();
  }));
  $('#gen').onclick = async () => {
    try {
      const body = {};
      if ($('#gFrom').value) body.from = $('#gFrom').value;
      if ($('#gTo').value) body.to = $('#gTo').value;
      const hol = $('#gHol').value.split(',').map(s => s.trim()).filter(Boolean);
      if (hol.length) body.holidays = hol;
      const r = await api('/schedule/generate-lessons', { method: 'POST', body });
      toast(`Создано занятий: ${r.created}`);
    } catch (e) {
      showError(e);
    }
  };
};

routes.loads = async () => {
  const isAdmin = state.me.role === 'admin';
  const rows = await api('/course-loads');
  view().innerHTML = `
    ${isAdmin ? '<div class="toolbar"><button class="btn primary" id="add">Назначить преподавателя</button></div>' : ''}
    <div class="panel">${table([
      { title: 'Группа', key: 'group_name' }, { title: 'Предмет', key: 'subject_name' }, { title: 'Кредиты', key: 'credits' },
      { title: 'Преподаватель', key: 'teacher_name' }, { title: 'Проведено', get: r => `${r.lessons_done} / ${r.lessons_total}` },
      { title: '', html: r => `<a class="btn sm primary" href="#journal/${r.id}">Журнал</a>${isAdmin ? ` <button class="btn sm" data-re="${r.id}">Сменить</button> <button class="btn sm danger" data-del="${r.id}">Удалить</button>` : ''}` }
    ], rows, 'Нагрузка на текущий семестр не назначена')}</div>`;
  if (!isAdmin) return;
  const [groups, subjects, teachers] = await Promise.all([lookup('groups', '/groups'), lookup('subjects', '/subjects'), api('/users?role=teacher')]);
  const tOpts = teachers.filter(t => t.is_active).map(t => ({ value: t.id, label: t.full_name }));
  $('#add').onclick = () => formModal('Назначение нагрузки', [
    { name: 'group_id', label: 'Группа', type: 'select', numeric: true, options: groups.map(g => ({ value: g.id, label: g.name })) },
    { name: 'subject_id', label: 'Предмет', type: 'select', numeric: true, options: subjects.map(s => ({ value: s.id, label: s.name })) },
    { name: 'teacher_id', label: 'Преподаватель', type: 'select', numeric: true, options: tOpts }
  ], null, async v => {
    await api('/course-loads', { method: 'POST', body: v });
    router();
  });
  view().querySelectorAll('[data-re]').forEach(b => (b.onclick = () => formModal('Сменить преподавателя', [
    { name: 'teacher_id', label: 'Преподаватель', type: 'select', numeric: true, options: tOpts }
  ], rows.find(r => r.id === Number(b.dataset.re)), async v => {
    await api('/course-loads/' + b.dataset.re, { method: 'PATCH', body: v });
    router();
  })));
  view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
    if (!confirm('Удалить нагрузку?')) return;
    try {
      await api('/course-loads/' + b.dataset.del, { method: 'DELETE' });
    } catch (e) {
      if (!confirm(e.message + '\n\nУдалить вместе с оценками?')) return;
      await api('/course-loads/' + b.dataset.del + '?force=1', { method: 'DELETE' });
    }
    router();
  }));
};

routes.schedule = async () => {
  const role = state.me.role;
  const f = routes.schedule.filter || {};
  let toolbar = '';
  if (role === 'admin') {
    const [groups, teachers] = await Promise.all([lookup('groups', '/groups'), api('/users?role=teacher')]);
    toolbar = `<div class="toolbar">
      <label>Группа<select id="sGroup"><option value="">Все</option>${groups.map(g => `<option value="${g.id}" ${String(f.group_id) === String(g.id) ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></label>
      <label>Преподаватель<select id="sTeacher"><option value="">Все</option>${teachers.map(t => `<option value="${t.id}" ${String(f.teacher_id) === String(t.id) ? 'selected' : ''}>${esc(t.full_name)}</option>`).join('')}</select></label>
      <button class="btn" id="sApply">Показать</button><span style="flex:1"></span>
      <button class="btn primary" id="sAdd">Добавить пару</button>
    </div>`;
  }
  const params = new URLSearchParams(f);
  const rows = await api('/schedule?' + params);
  const byDay = {};
  rows.forEach(r => (byDay[r.weekday] ||= []).push(r));
  view().innerHTML = toolbar + `<div class="week">${[1, 2, 3, 4, 5, 6].map(d => `
    <div class="panel day"><h4>${DAYS[d]}</h4>${(byDay[d] || []).map(s => `
      <div class="slot">
        <b>${s.start_time}–${s.end_time} · ${esc(s.subject_name)}</b>
        ${role !== 'student' ? esc(s.group_name) + ' · ' : ''}${role !== 'teacher' ? esc(s.teacher_name) + ' · ' : ''}${esc(s.room_name || '—')} · ${LTYPE[s.lesson_type]}
        ${role === 'admin' ? `<div style="margin-top:6px"><button class="btn sm" data-edit="${s.id}">Изменить</button> <button class="btn sm danger" data-del="${s.id}">×</button></div>` : ''}
      </div>`).join('') || '<p class="muted">—</p>'}
    </div>`).join('')}</div>`;
  if (role !== 'admin') return;
  $('#sApply').onclick = () => {
    routes.schedule.filter = Object.fromEntries(Object.entries({ group_id: $('#sGroup').value, teacher_id: $('#sTeacher').value }).filter(([, v]) => v));
    router();
  };
  const [loads, rooms] = await Promise.all([api('/course-loads'), lookup('rooms', '/rooms')]);
  const slotFields = [
    { name: 'weekday', label: 'День недели', type: 'select', numeric: true, options: [1, 2, 3, 4, 5, 6, 7].map(d => ({ value: d, label: DAYS[d] })) },
    { name: 'start_time', label: 'Начало', type: 'time', required: true }, { name: 'end_time', label: 'Конец', type: 'time', required: true },
    { name: 'room_id', label: 'Аудитория', type: 'select', empty: '—', numeric: true, options: rooms.map(r => ({ value: r.id, label: r.name })) },
    { name: 'lesson_type', label: 'Тип', type: 'select', options: Object.entries(LTYPE).map(([value, label]) => ({ value, label })) }
  ];
  $('#sAdd').onclick = () => formModal('Новая пара', [
    { name: 'course_load_id', label: 'Группа и предмет', type: 'select', numeric: true, options: loads.map(l => ({ value: l.id, label: `${l.group_name} — ${l.subject_name} (${l.teacher_name})` })) },
    ...slotFields
  ], null, async v => {
    await api('/schedule', { method: 'POST', body: v });
    router();
  });
  view().querySelectorAll('[data-edit]').forEach(b => (b.onclick = () => formModal('Изменить пару', [
    ...slotFields, { name: 'update_future_lessons', label: 'Обновить будущие занятия', type: 'checkbox', value: true }
  ], rows.find(r => r.id === Number(b.dataset.edit)), async v => {
    await api('/schedule/' + b.dataset.edit, { method: 'PATCH', body: v });
    router();
  })));
  view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
    if (!confirm('Удалить пару из расписания? Будущие пустые занятия тоже удалятся')) return;
    await api('/schedule/' + b.dataset.del, { method: 'DELETE' });
    router();
  }));
};

routes.lessons = async () => {
  const f = routes.lessons.filter || { from: addDays(today(), -3), to: addDays(today(), 3) };
  const rows = await api('/lessons?' + new URLSearchParams(f));
  const isAdmin = state.me.role === 'admin';
  view().innerHTML = `
    <div class="toolbar">
      <label>С<input type="date" id="lFrom" value="${f.from}"></label>
      <label>По<input type="date" id="lTo" value="${f.to}"></label>
      <button class="btn" id="lApply">Показать</button>
    </div>
    <div class="panel">${table([
      { title: 'Дата', get: r => r.date }, { title: 'Время', get: r => `${r.start_time}–${r.end_time}` },
      { title: 'Группа', key: 'group_name' }, { title: 'Предмет', key: 'subject_name' },
      { title: 'Преподаватель', html: r => esc(r.teacher_name) + (r.substitute_name ? `<br><span class="badge warn">замена: ${esc(r.substitute_name)}</span>` : '') },
      { title: 'Тема', key: 'topic' },
      { title: 'Статус', html: r => ({ planned: '<span class="badge">План</span>', done: '<span class="badge ok">Проведено</span>', cancelled: '<span class="badge bad">Отменено</span>' }[r.status]) },
      { title: '', html: r => `<a class="btn sm primary" href="#lesson/${r.id}">Открыть</a>${isAdmin ? ` <button class="btn sm" data-sub="${r.id}">Замена</button>` : ''}` }
    ], rows, 'Занятий за период нет')}</div>`;
  $('#lApply').onclick = () => {
    routes.lessons.filter = { from: $('#lFrom').value, to: $('#lTo').value };
    router();
  };
  if (!isAdmin) return;
  const teachers = await api('/users?role=teacher');
  view().querySelectorAll('[data-sub]').forEach(b => (b.onclick = () => formModal('Замена / перенос', [
    { name: 'substitute_teacher_id', label: 'Заменяющий преподаватель', type: 'select', empty: 'Без замены', numeric: true, options: teachers.map(t => ({ value: t.id, label: t.full_name })) },
    { name: 'date', label: 'Дата', type: 'date' }, { name: 'start_time', label: 'Начало', type: 'time' }, { name: 'end_time', label: 'Конец', type: 'time' },
    { name: 'status', label: 'Статус', type: 'select', options: [{ value: 'planned', label: 'План' }, { value: 'done', label: 'Проведено' }, { value: 'cancelled', label: 'Отменено' }] }
  ], rows.find(r => r.id === Number(b.dataset.sub)), async v => {
    await api('/lessons/' + b.dataset.sub, { method: 'PATCH', body: v });
    router();
  })));
};

routes.lesson = async id => {
  const l = await api('/lessons/' + id);
  $('#title').textContent = `${l.subject_name} · ${l.group_name}`;
  if (state.me.role === 'student') {
    view().innerHTML = `<div class="panel">
      <p><b>${l.date}</b> ${l.start_time}–${l.end_time}, ауд. ${esc(l.room_name || '—')}</p>
      <p>Тема: ${esc(l.topic || '—')}</p><p>Домашнее задание: ${esc(l.homework || '—')}</p>
      <p>Посещение: ${l.my_attendance ? ATT[l.my_attendance] : '—'}</p>
      <p>Оценки: ${l.my_grades.map(g => badgeScore(g.value, state.me.institution_type)).join(' ') || '—'}</p></div>`;
    return;
  }
  const type = state.me.institution_type;
  const max = type === 'school' ? 5 : 100;
  const min = type === 'school' ? 1 : 0;
  view().innerHTML = `
    <div class="panel">
      <p><b>${l.date}</b> ${l.start_time}–${l.end_time} · ауд. ${esc(l.room_name || '—')} · ${esc(l.teacher_name)}</p>
      <div class="form">
        <label>Тема занятия<input id="topic" value="${esc(l.topic || '')}"></label>
        <label>Домашнее задание<input id="hw" value="${esc(l.homework || '')}"></label>
      </div>
    </div>
    <div class="panel">
      <div class="toolbar"><button class="btn sm" id="allPresent">Все присутствуют</button></div>
      <table><thead><tr><th>Студент</th><th>Посещение</th><th>Оценка (${min}–${max})</th><th>Уже выставлено</th></tr></thead><tbody>
      ${l.students.map(s => `<tr data-id="${s.id}">
        <td>${esc(s.full_name)}</td>
        <td>${Object.entries(ATT).map(([k, v]) => `<label style="margin-right:8px;white-space:nowrap"><input type="radio" style="width:auto" name="a${s.id}" value="${k}" ${s.attendance === k ? 'checked' : ''}> ${v}</label>`).join('')}</td>
        <td><input type="number" min="${min}" max="${max}" class="gr" style="width:90px"></td>
        <td>${s.grades.map(g => badgeScore(g.value, type)).join(' ')}</td>
      </tr>`).join('')}
      </tbody></table>
      <div class="actions"><a class="btn" href="#journal/${l.course_load_id}">Журнал предмета</a><button class="btn primary" id="save">Сохранить</button></div>
    </div>`;
  $('#allPresent').onclick = () => view().querySelectorAll('input[value=present]').forEach(r => (r.checked = true));
  $('#save').onclick = async () => {
    try {
      const items = [];
      const grades = [];
      view().querySelectorAll('tr[data-id]').forEach(tr => {
        const sid = Number(tr.dataset.id);
        const a = tr.querySelector('input[type=radio]:checked');
        if (a) items.push({ student_id: sid, status: a.value });
        const g = tr.querySelector('.gr').value;
        if (g !== '' && a?.value !== 'absent') grades.push({ student_id: sid, value: Number(g) });
      });
      await api('/lessons/' + id, { method: 'PATCH', body: { topic: $('#topic').value, homework: $('#hw').value } });
      if (items.length) await api(`/lessons/${id}/attendance`, { method: 'PUT', body: { items } });
      for (const g of grades) {
        await api('/grades', { method: 'POST', body: { course_load_id: l.course_load_id, lesson_id: Number(id), ...g } });
      }
      toast('Сохранено');
      router();
    } catch (e) {
      showError(e);
    }
  };
};

routes.journal = async id => {
  const j = await api(`/grades/journal/${id}?to=${addDays(today(), 14)}`);
  $('#title').textContent = `Журнал: ${j.course.subject} · ${j.course.group}`;
  const type = j.course.institution_type;
  const controlKinds = j.course.kinds.filter(k => k !== 'current');
  const ctrl = (s, k) => s.control.filter(g => g.kind === k).slice(-1)[0];
  view().innerHTML = `
    <div class="panel">
      <p class="muted">Нажмите на клетку, чтобы отметить посещение или поставить оценку. Шкала: ${j.course.scale.min}–${j.course.scale.max}.</p>
      <table class="journal"><thead><tr>
        <th>Студент</th>
        ${j.lessons.map(l => `<th class="date" title="${esc(l.topic || '')}">${fmtDate(l.date)}</th>`).join('')}
        ${controlKinds.map(k => `<th>${KIND[k]}</th>`).join('')}
        <th>Ср.</th>${type === 'school' ? '' : '<th>Допуск</th><th>Экз.</th><th>Итог</th>'}<th>Посещ.</th>
      </tr></thead><tbody>
      ${j.students.map(s => `<tr>
        <td class="name">${esc(s.full_name)}</td>
        ${j.lessons.map(l => {
          const c = s.cells[l.id];
          const a = c?.attendance ? `<span class="a-${c.attendance}">${ATT_SHORT[c.attendance]}</span>` : '';
          const g = c?.grades?.map(x => `<span class="g">${x.value}</span>`).join(' ') || '';
          return `<td class="cell" data-s="${s.id}" data-l="${l.id}">${g || a}</td>`;
        }).join('')}
        ${controlKinds.map(k => `<td class="cell" data-s="${s.id}" data-k="${k}">${ctrl(s, k)?.value ?? ''}</td>`).join('')}
        <td>${badgeScore(s.summary.currentAvg, type)}</td>
        ${type === 'school' ? '' : `<td>${badgeScore(s.summary.admission, type)}</td><td>${s.summary.exam ?? '—'}</td><td>${s.summary.final != null ? `${s.summary.final} <span class="badge ${s.summary.passed ? 'ok' : 'bad'}">${s.summary.letter}</span>` : '—'}</td>`}
        <td>${s.summary.attendance.percent != null ? s.summary.attendance.percent + '%' : '—'}</td>
      </tr>`).join('')}
      </tbody></table>
    </div>`;

  view().querySelectorAll('td.cell').forEach(td => (td.onclick = () => {
    const student = j.students.find(s => s.id === Number(td.dataset.s));
    if (td.dataset.k) {
      const existing = ctrl(student, td.dataset.k);
      formModal(`${KIND[td.dataset.k]} — ${student.full_name}`, [
        { name: 'value', label: 'Балл', type: 'number', step: 'any', required: true }, { name: 'comment', label: 'Комментарий' }
      ], existing, async v => {
        await api('/grades', { method: 'POST', body: { course_load_id: Number(id), student_id: student.id, kind: td.dataset.k, ...v } });
        router();
      });
      return;
    }
    const lesson = j.lessons.find(l => l.id === Number(td.dataset.l));
    const cell = student.cells[lesson.id];
    modal(`
      <h3>${esc(student.full_name)}</h3>
      <p class="muted">${lesson.date} ${lesson.start_time} · ${esc(lesson.topic || 'без темы')}</p>
      <div class="form">
        <label>Посещение<select id="cAtt"><option value="">—</option>${Object.entries(ATT).map(([k, v]) => `<option value="${k}" ${cell?.attendance === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <label>Новая оценка<input id="cGrade" type="number" step="${type === 'school' ? 1 : 'any'}"></label>
        <label>Комментарий<input id="cComment"></label>
        ${cell?.grades?.length ? `<div><b>Выставлено:</b> ${cell.grades.map(g => `${g.value} <button class="btn sm danger" data-gdel="${g.id}">×</button>`).join(' ')}</div>` : ''}
        <div class="actions"><button class="btn" data-close>Отмена</button><button class="btn primary" id="cSave">Сохранить</button></div>
      </div>`, root => {
      root.querySelector('[data-close]').onclick = closeModal;
      root.querySelectorAll('[data-gdel]').forEach(b => (b.onclick = async () => {
        try {
          await api('/grades/' + b.dataset.gdel, { method: 'DELETE' });
          closeModal();
          router();
        } catch (e) {
          showError(e);
        }
      }));
      root.querySelector('#cSave').onclick = async () => {
        try {
          const att = $('#cAtt').value;
          if (att && att !== cell?.attendance) {
            await api(`/lessons/${lesson.id}/attendance`, { method: 'PUT', body: { items: [{ student_id: student.id, status: att }] } });
          }
          const g = $('#cGrade').value;
          if (g !== '') {
            await api('/grades', { method: 'POST', body: { course_load_id: Number(id), student_id: student.id, lesson_id: lesson.id, value: Number(g), comment: $('#cComment').value || undefined, force: true } });
          }
          closeModal();
          router();
        } catch (e) {
          showError(e);
        }
      };
    });
  }));
};

routes.grades = async () => {
  const d = await api('/grades/my');
  const type = state.me.institution_type;
  if (!d.term) {
    view().innerHTML = '<p class="muted">Семестр не активен</p>';
    return;
  }
  view().innerHTML = `<p class="muted">${esc(d.term.name)}</p>` + d.subjects.map(s => `
    <div class="panel">
      <h3>${esc(s.subject)} ${type === 'school' ? '' : `<span class="muted">· ${s.credits} кр.</span>`}</h3>
      <div style="margin-bottom:10px">${s.grades.filter(g => g.kind === 'current').map(g => `<span title="${esc((g.date || '') + ' ' + (g.topic || ''))}">${badgeScore(g.value, type)}</span>`).join(' ') || '<span class="muted">Оценок нет</span>'}</div>
      ${type === 'school'
        ? `Средний балл: <b>${s.summary.currentAvg ?? '—'}</b> · Прогноз за четверть: <b>${s.summary.quarter ?? s.summary.suggestedQuarter ?? '—'}</b>`
        : `РК1: <b>${s.summary.rk1 ?? '—'}</b> · РК2: <b>${s.summary.rk2 ?? '—'}</b> · Рейтинг допуска: <b>${s.summary.admission ?? '—'}</b>
           ${s.summary.admission != null ? (s.summary.admitted ? '<span class="badge ok">допущен</span>' : '<span class="badge bad">не допущен</span>') : ''}
           · Экзамен: <b>${s.summary.exam ?? '—'}</b> · Итог: <b>${s.summary.final ?? '—'} ${s.summary.letter || ''}</b>`}
      · Посещаемость: <b>${s.summary.attendance.percent ?? '—'}%</b> (пропусков: ${s.summary.attendance.absent})
    </div>`).join('');
};

routes.transcript = async studentId => {
  const t = await api(studentId ? '/reports/transcript/' + studentId : '/reports/transcript');
  const school = t.student.institution_type === 'school';
  $('#title').textContent = 'Транскрипт: ' + t.student.full_name;
  view().innerHTML = `
    <div class="cards">
      <div class="card"><div class="muted">Учебное заведение</div><b>${esc(t.student.institution_name)}</b></div>
      <div class="card"><div class="muted">Группа</div><div class="num">${esc(t.student.group_name || '—')}</div></div>
      ${school ? '' : `<div class="card"><div class="muted">GPA</div><div class="num">${t.total_gpa ?? '—'}</div></div>
      <div class="card"><div class="muted">Кредитов получено</div><div class="num">${t.total_credits}</div></div>`}
    </div>
    ${t.debts.length ? `<div class="panel error">Академическая задолженность: ${t.debts.map(esc).join(', ')}</div>` : ''}
    ${t.terms.map(term => `<div class="panel"><h3>${esc(term.term)} ${term.gpa != null ? `· GPA ${term.gpa}` : ''}${term.avg ? `· средний ${term.avg}` : ''}</h3>
      ${table(school ? [
        { title: 'Предмет', key: 'subject' }, { title: 'Средний', key: 'currentAvg' },
        { title: 'Четверть', get: s => s.quarter ?? s.suggestedQuarter ?? '—' }, { title: 'Посещ.', get: s => s.attendance.percent != null ? s.attendance.percent + '%' : '—' }
      ] : [
        { title: 'Предмет', key: 'subject' }, { title: 'Кредиты', key: 'credits' }, { title: 'Допуск', get: s => s.admission ?? '—' },
        { title: 'Экзамен', get: s => s.exam ?? '—' }, { title: 'Итог', get: s => s.final ?? '—' },
        { title: 'Буква', html: s => s.letter ? `<span class="badge ${s.passed ? 'ok' : 'bad'}">${s.letter}</span>` : '—' },
        { title: 'GPA', get: s => s.gpa ?? '—' }, { title: 'Оценка', get: s => s.traditional || '—' }
      ], term.subjects)}</div>`).join('')}
    <button class="btn" onclick="window.print()">Печать</button>`;
};

routes.exams = async () => {
  const role = state.me.role;
  const rows = await api('/exams');
  view().innerHTML = `
    ${role === 'admin' ? '<div class="toolbar"><button class="btn primary" id="add">Назначить экзамен</button></div>' : ''}
    <div class="panel">${table([
      { title: 'Дата', key: 'date' }, { title: 'Время', key: 'start_time' }, { title: 'Группа', key: 'group_name' },
      { title: 'Предмет', key: 'subject_name' }, { title: 'Тип', get: r => EXAM[r.kind] }, { title: 'Экзаменатор', key: 'examiner_name' },
      { title: 'Ауд.', key: 'room_name' },
      { title: role === 'student' ? 'Результат' : 'Ведомость', html: r => role === 'student'
        ? (r.my_result ? (r.my_result.absent ? '<span class="badge bad">неявка</span>' : badgeScore(r.my_result.score, state.me.institution_type)) : '<span class="muted">—</span>')
        : `<a class="btn sm primary" href="#exam/${r.id}">Открыть</a> ${r.is_closed ? '<span class="badge">закрыта</span>' : ''}` }
    ], rows, 'Экзаменов нет')}</div>`;
  if (role !== 'admin') return;
  const [loads, rooms, teachers] = await Promise.all([api('/course-loads'), lookup('rooms', '/rooms'), api('/users?role=teacher')]);
  $('#add').onclick = () => formModal('Новый экзамен', [
    { name: 'course_load_id', label: 'Группа и предмет', type: 'select', numeric: true, options: loads.map(l => ({ value: l.id, label: `${l.group_name} — ${l.subject_name}` })) },
    { name: 'kind', label: 'Тип', type: 'select', options: Object.entries(EXAM).map(([value, label]) => ({ value, label })) },
    { name: 'date', label: 'Дата', type: 'date', required: true }, { name: 'start_time', label: 'Время', type: 'time', required: true },
    { name: 'room_id', label: 'Аудитория', type: 'select', empty: '—', numeric: true, options: rooms.map(r => ({ value: r.id, label: r.name })) },
    { name: 'examiner_id', label: 'Экзаменатор', type: 'select', empty: 'Ведущий преподаватель', numeric: true, options: teachers.map(t => ({ value: t.id, label: t.full_name })) }
  ], null, async v => {
    await api('/exams', { method: 'POST', body: v });
    router();
  });
};

routes.exam = async id => {
  const e = await api('/exams/' + id);
  const type = state.me.institution_type;
  $('#title').textContent = `${EXAM[e.kind]}: ${e.subject_name} · ${e.group_name}`;
  const locked = e.is_closed && state.me.role === 'teacher';
  view().innerHTML = `
    <div class="panel">
      <p>${e.date} ${e.start_time} · ауд. ${esc(e.room_name || '—')} · ${esc(e.examiner_name)} ${e.is_closed ? '<span class="badge bad">Ведомость закрыта</span>' : ''}</p>
      <table><thead><tr><th>Студент</th><th>Допуск</th><th>Балл</th><th>Неявка</th><th>Итог</th></tr></thead><tbody>
      ${e.students.map(s => `<tr data-id="${s.id}">
        <td>${esc(s.full_name)}</td>
        <td>${badgeScore(s.admission, type)} ${s.admitted === false ? '<span class="badge bad">не допущен</span>' : ''}</td>
        <td><input type="number" class="sc" style="width:90px" value="${s.score ?? ''}" ${locked ? 'disabled' : ''}></td>
        <td><input type="checkbox" class="ab" style="width:auto" ${s.absent ? 'checked' : ''} ${locked ? 'disabled' : ''}></td>
        <td>${s.final != null ? `${s.final} ${s.letter || ''}` : '—'}</td>
      </tr>`).join('')}
      </tbody></table>
      <div class="actions">
        ${state.me.role === 'admin' && e.is_closed ? '<button class="btn" id="reopen">Открыть ведомость</button>' : ''}
        ${locked ? '' : '<button class="btn" id="close">Закрыть ведомость</button><button class="btn primary" id="save">Сохранить</button>'}
      </div>
    </div>`;
  const save = async () => {
    const items = [];
    view().querySelectorAll('tr[data-id]').forEach(tr => {
      const absent = tr.querySelector('.ab').checked;
      const score = tr.querySelector('.sc').value;
      if (absent || score !== '') items.push({ student_id: Number(tr.dataset.id), absent, score: score === '' ? null : Number(score) });
    });
    if (items.length) await api(`/exams/${id}/results`, { method: 'PUT', body: { items } });
  };
  if ($('#save')) $('#save').onclick = async () => {
    try {
      await save();
      toast('Ведомость сохранена');
      router();
    } catch (err) {
      showError(err);
    }
  };
  if ($('#close')) $('#close').onclick = async () => {
    if (!confirm('После закрытия преподаватель не сможет менять баллы. Продолжить?')) return;
    try {
      await save();
      await api(`/exams/${id}/close`, { method: 'POST', body: {} });
      router();
    } catch (err) {
      showError(err);
    }
  };
  if ($('#reopen')) $('#reopen').onclick = async () => {
    await api(`/exams/${id}/reopen`, { method: 'POST', body: {} });
    router();
  };
};

routes.reports = async () => {
  const isAdmin = state.me.role === 'admin';
  const groups = await lookup('groups', '/groups');
  view().innerHTML = `
    <div class="panel"><h3>Посещаемость</h3>
      <div class="toolbar">
        <label>Группа<select id="rGroup"><option value="">Все</option>${groups.map(g => `<option value="${g.id}">${esc(g.name)}</option>`).join('')}</select></label>
        <label>С<input type="date" id="rFrom" value="${addDays(today(), -30)}"></label>
        <label>По<input type="date" id="rTo" value="${today()}"></label>
        <button class="btn primary" id="rGo">Сформировать</button>
      </div>
      <div id="att"></div>
    </div>
    ${isAdmin ? '<div class="panel"><h3>Нагрузка преподавателей</h3><div id="load"></div></div>' : ''}
    <div class="panel"><h3>Успеваемость групп</h3>${groups.map(g => `<a class="btn sm" href="#groupreport/${g.id}">${esc(g.name)}</a>`).join(' ')}</div>`;
  const loadAtt = async () => {
    const p = new URLSearchParams({ from: $('#rFrom').value, to: $('#rTo').value });
    if ($('#rGroup').value) p.set('group_id', $('#rGroup').value);
    const r = await api('/reports/attendance?' + p);
    $('#att').innerHTML = table([
      { title: 'Студент', key: 'full_name' }, { title: 'Группа', key: 'group_name' }, { title: 'Был', key: 'present' },
      { title: 'Опоздал', key: 'late' }, { title: 'Пропуск', key: 'absent' }, { title: 'Уваж.', key: 'excused' },
      { title: '%', html: x => `<span class="badge ${x.percent < 70 ? 'bad' : x.percent < 85 ? 'warn' : 'ok'}">${x.percent}%</span>` }
    ], r.rows);
  };
  $('#rGo').onclick = () => loadAtt().catch(showError);
  loadAtt();
  if (isAdmin) {
    const load = await api('/reports/teacher-load');
    $('#load').innerHTML = table([
      { title: 'Преподаватель', key: 'full_name' }, { title: 'Пар в неделю', key: 'pairs_per_week' }, { title: 'Часов в неделю', key: 'weekly_hours' },
      { title: 'Проведено', key: 'done' }, { title: 'Запланировано', key: 'planned' }, { title: 'Отменено', key: 'cancelled' }
    ], load);
  }
};

routes.groupreport = async id => {
  const r = await api('/reports/group/' + id);
  const type = state.me.institution_type;
  $('#title').textContent = 'Успеваемость: ' + r.group.name;
  view().innerHTML = `
    <div class="panel"><h3>Группа риска</h3>${table([
      { title: 'Студент', key: 'full_name' }, { title: 'Предмет', key: 'subject' }, { title: 'Причины', get: x => x.reasons.join(', ') }
    ], r.at_risk, 'Проблемных студентов нет')}</div>
    ${r.subjects.map(s => `<div class="panel"><h3>${esc(s.subject)} · средний ${s.average ?? '—'}</h3>${table([
      { title: 'Студент', key: 'full_name' }, { title: 'Средний', html: x => badgeScore(x.currentAvg, type) },
      ...(type === 'school' ? [] : [{ title: 'Допуск', html: x => badgeScore(x.admission, type) }, { title: 'Итог', get: x => x.final != null ? `${x.final} ${x.letter}` : '—' }]),
      { title: 'Посещ.', get: x => x.attendance.percent != null ? x.attendance.percent + '%' : '—' }
    ], s.students)}</div>`).join('')}`;
};

routes.news = async () => {
  const rows = await api('/announcements');
  const canPost = state.me.role !== 'student';
  view().innerHTML = `
    ${canPost ? '<div class="toolbar"><button class="btn primary" id="add">Новое объявление</button></div>' : ''}
    ${rows.map(a => `<div class="panel">
      <h3>${esc(a.title)}</h3>
      <p style="white-space:pre-wrap">${esc(a.body)}</p>
      <p class="muted">${esc(a.author_name)} · ${a.created_at.slice(0, 16)} · ${a.group_name ? 'Группа ' + esc(a.group_name) : 'Для всех'}
      ${canPost ? ` <button class="btn sm danger" data-del="${a.id}">Удалить</button>` : ''}</p>
    </div>`).join('') || '<p class="muted">Объявлений нет</p>'}`;
  if (!canPost) return;
  const groups = await lookup('groups', '/groups');
  $('#add').onclick = () => formModal('Объявление', [
    { name: 'title', label: 'Заголовок', required: true }, { name: 'body', label: 'Текст', type: 'textarea' },
    { name: 'group_id', label: 'Кому', type: 'select', empty: state.me.role === 'admin' ? 'Всем' : undefined, numeric: true, options: groups.map(g => ({ value: g.id, label: g.name })) }
  ], null, async v => {
    await api('/announcements', { method: 'POST', body: v });
    router();
  });
  view().querySelectorAll('[data-del]').forEach(b => (b.onclick = async () => {
    try {
      await api('/announcements/' + b.dataset.del, { method: 'DELETE' });
      router();
    } catch (e) {
      showError(e);
    }
  }));
};

function logout() {
  state.token = null;
  state.me = null;
  localStorage.removeItem('token');
  Object.keys(cache).forEach(k => delete cache[k]);
  $('#shell').classList.add('hidden');
  $('#login').classList.remove('hidden');
}

async function boot() {
  if (!state.token) return logout();
  try {
    state.me = await api('/auth/me');
  } catch {
    return logout();
  }
  $('#login').classList.add('hidden');
  $('#shell').classList.remove('hidden');
  $('#me').innerHTML = `<b>${esc(state.me.full_name)}</b>${ROLE[state.me.role]}${state.me.group_name ? ' · ' + esc(state.me.group_name) : ''}<br>${esc(state.me.institution_name || '')}`;
  router();
}

$('#loginForm').onsubmit = async e => {
  e.preventDefault();
  $('#loginError').textContent = '';
  try {
    const r = await api('/auth/login', { method: 'POST', body: { login: e.target.login.value, password: e.target.password.value } });
    state.token = r.token;
    localStorage.setItem('token', r.token);
    location.hash = '';
    boot();
  } catch (err) {
    $('#loginError').textContent = err.message;
  }
};

$('#logout').onclick = logout;
$('#burger').onclick = () => $('.side').classList.toggle('open');
window.addEventListener('hashchange', router);
boot();
