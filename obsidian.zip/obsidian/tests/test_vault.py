import json
import os

import pytest

from obsidian.crypto import CryptoError, DecryptionError, KdfParams
from obsidian.vault import (
    Entry,
    EntryExistsError,
    EntryNotFoundError,
    Vault,
    VaultError,
    VaultExistsError,
    VaultNotFoundError,
)

FAST = KdfParams(n=2**10, r=8, p=1)
PASSWORD = "master-password"


@pytest.fixture
def path(tmp_path):
    return tmp_path / "vault.obs"


@pytest.fixture
def vault(path):
    return Vault.create(path, PASSWORD, FAST)


def sample(name="github", **overrides):
    values = {"username": "alice", "password": "hunter2-secret", "url": "https://github.com"}
    values.update(overrides)
    return Entry(name=name, **values)


def test_create_writes_file(vault, path):
    assert path.is_file()
    assert len(vault) == 0


def test_create_refuses_existing(vault, path):
    with pytest.raises(VaultExistsError):
        Vault.create(path, PASSWORD, FAST)


def test_create_rejects_short_master(path):
    with pytest.raises(VaultError):
        Vault.create(path, "short", FAST)


def test_create_makes_parent_directories(tmp_path):
    target = tmp_path / "nested" / "dir" / "vault.obs"
    Vault.create(target, PASSWORD, FAST)
    assert target.is_file()


def test_open_missing(tmp_path):
    with pytest.raises(VaultNotFoundError):
        Vault.open(tmp_path / "none.obs", PASSWORD)


def test_add_and_get(vault):
    vault.add(sample())
    entry = vault.get("github")
    assert entry.username == "alice"
    assert entry.created and entry.created == entry.updated


def test_persistence(vault, path):
    vault.add(sample(tags=["dev", "code"]))
    vault.save()
    reopened = Vault.open(path, PASSWORD)
    entry = reopened.get("github")
    assert entry.password == "hunter2-secret"
    assert entry.tags == ["dev", "code"]


def test_unicode_roundtrip(vault, path):
    vault.add(sample("почта", username="пользователь", notes="заметка 🔐"))
    vault.save()
    entry = Vault.open(path, PASSWORD).get("почта")
    assert entry.username == "пользователь"
    assert entry.notes == "заметка 🔐"


def test_wrong_password(vault, path):
    with pytest.raises(DecryptionError):
        Vault.open(path, "another-password")


def test_duplicate_entry(vault):
    vault.add(sample())
    with pytest.raises(EntryExistsError):
        vault.add(sample())


def test_blank_name_rejected(vault):
    with pytest.raises(VaultError):
        vault.add(Entry(name="   "))


def test_get_missing(vault):
    with pytest.raises(EntryNotFoundError):
        vault.get("ghost")


def test_remove(vault):
    vault.add(sample())
    vault.remove("github")
    assert "github" not in vault
    with pytest.raises(EntryNotFoundError):
        vault.remove("github")


def test_update_changes_fields_and_timestamp(vault):
    vault.add(sample())
    entry = vault.get("github")
    entry.updated = "2000-01-01T00:00:00+00:00"
    vault.update("github", username="bob", tags=["x", "x", " y "])
    assert entry.username == "bob"
    assert entry.tags == ["x", "y"]
    assert entry.password == "hunter2-secret"
    assert entry.updated != "2000-01-01T00:00:00+00:00"


def test_update_rejects_unknown_field(vault):
    vault.add(sample())
    with pytest.raises(VaultError):
        vault.update("github", created="x")


def test_entries_sorted_and_filtered(vault):
    vault.add(sample("zeta", tags=["a"]))
    vault.add(sample("Alpha", tags=["b"]))
    vault.add(sample("beta", tags=["a"]))
    assert [e.name for e in vault.entries()] == ["Alpha", "beta", "zeta"]
    assert [e.name for e in vault.entries(tag="a")] == ["beta", "zeta"]


def test_search_ignores_password(vault):
    vault.add(sample())
    vault.add(sample("mail", username="carol", url="https://mail.example.com", notes="work"))
    assert [e.name for e in vault.search("GITHUB")] == ["github"]
    assert [e.name for e in vault.search("work")] == ["mail"]
    assert vault.search("hunter2") == []
    assert vault.search("   ") == []


def test_file_contains_no_plaintext(vault, path):
    vault.add(sample(notes="very private note"))
    vault.save()
    raw = path.read_bytes()
    for secret in (b"hunter2-secret", b"alice", b"github", b"very private note"):
        assert secret not in raw


def test_every_save_uses_fresh_nonce(vault, path):
    vault.save()
    first = json.loads(path.read_text())["nonce"]
    vault.save()
    second = json.loads(path.read_text())["nonce"]
    assert first != second


@pytest.mark.skipif(os.name != "posix", reason="POSIX permissions only")
def test_file_permissions(vault, path):
    assert path.stat().st_mode & 0o777 == 0o600


def test_no_temp_files_left(vault, path):
    vault.add(sample())
    vault.save()
    assert [p.name for p in path.parent.iterdir()] == [path.name]


def test_change_password(vault, path):
    vault.add(sample())
    vault.save()
    vault.change_password("brand-new-master")
    with pytest.raises(DecryptionError):
        Vault.open(path, PASSWORD)
    assert Vault.open(path, "brand-new-master").get("github").username == "alice"


def test_change_password_rejects_short(vault):
    with pytest.raises(VaultError):
        vault.change_password("tiny")


def test_corrupted_file(vault, path):
    path.write_text("{ definitely not json")
    with pytest.raises(VaultError):
        Vault.open(path, PASSWORD)


def test_truncated_ciphertext(vault, path):
    vault.add(sample())
    vault.save()
    data = json.loads(path.read_text())
    data["ciphertext"] = data["ciphertext"][:-8]
    path.write_text(json.dumps(data))
    with pytest.raises(CryptoError):
        Vault.open(path, PASSWORD)


def test_export_import_roundtrip(vault, tmp_path):
    vault.add(sample("one", tags=["t"]))
    vault.add(sample("two"))
    exported = vault.export_entries()
    other = Vault.create(tmp_path / "other.obs", PASSWORD, FAST)
    assert other.import_entries(exported) == (2, 0, 0)
    assert other.get("one").tags == ["t"]
    assert other.get("two").password == "hunter2-secret"


def test_import_skips_and_overwrites(vault):
    vault.add(sample("one", password="old"))
    created = vault.get("one").created
    items = [{"name": "one", "password": "new"}, {"name": "fresh", "password": "p"}]
    assert vault.import_entries(items) == (1, 0, 1)
    assert vault.get("one").password == "old"
    assert vault.import_entries(items, overwrite=True) == (0, 2, 0)
    assert vault.get("one").password == "new"
    assert vault.get("one").created == created


def test_import_is_atomic_on_invalid_item(vault):
    with pytest.raises(VaultError):
        vault.import_entries([{"name": "ok"}, {"password": "no name"}])
    assert len(vault) == 0


def test_info(vault):
    vault.add(sample())
    vault.save()
    info = vault.info()
    assert info["entries"] == 1
    assert info["cipher"] == "AES-256-GCM"
    assert "scrypt" in info["kdf"]
