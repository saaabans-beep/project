import string

import pytest

from obsidian.generator import (
    AMBIGUOUS,
    SYMBOLS,
    entropy_bits,
    generate_password,
    strength_label,
)


@pytest.mark.parametrize("length", [4, 8, 20, 64, 1024])
def test_length(length):
    assert len(generate_password(length)) == length


def test_contains_every_enabled_class():
    for _ in range(200):
        password = generate_password(8)
        assert any(c in string.ascii_lowercase for c in password)
        assert any(c in string.ascii_uppercase for c in password)
        assert any(c in string.digits for c in password)
        assert any(c in SYMBOLS for c in password)


def test_disabled_classes_are_absent():
    for _ in range(100):
        password = generate_password(30, upper=False, symbols=False)
        assert not any(c in string.ascii_uppercase for c in password)
        assert not any(c in SYMBOLS for c in password)


def test_avoid_ambiguous():
    for _ in range(200):
        assert not set(generate_password(40, avoid_ambiguous=True)) & AMBIGUOUS


def test_only_digits():
    password = generate_password(12, lower=False, upper=False, symbols=False)
    assert password.isdigit()


def test_passwords_differ():
    assert len({generate_password(24) for _ in range(50)}) == 50


def test_no_character_class_enabled():
    with pytest.raises(ValueError):
        generate_password(10, lower=False, upper=False, digits=False, symbols=False)


@pytest.mark.parametrize("length", [0, 3, 1025, -5])
def test_invalid_length(length):
    with pytest.raises(ValueError):
        generate_password(length)


def test_entropy_grows_with_length_and_variety():
    assert entropy_bits("") == 0.0
    assert entropy_bits("abcd") < entropy_bits("abcdefgh")
    assert entropy_bits("abcdefgh") < entropy_bits("aBcD3fG!")


@pytest.mark.parametrize(
    "bits,label",
    [(10, "weak"), (45, "fair"), (70, "good"), (90, "strong"), (130, "very strong")],
)
def test_strength_labels(bits, label):
    assert strength_label(bits) == label
