import base64
import copy

import pytest

from obsidian.crypto import (
    DecryptionError,
    FormatError,
    KdfParams,
    create_keyring,
    unlock,
)

FAST = KdfParams(n=2**10, r=8, p=1)
PASSWORD = "correct horse battery"


def flip(value):
    raw = bytearray(base64.b64decode(value))
    raw[0] ^= 1
    return base64.b64encode(bytes(raw)).decode("ascii")


@pytest.fixture
def envelope():
    return create_keyring(PASSWORD, FAST).seal(b"secret payload")


def test_roundtrip():
    keyring = create_keyring(PASSWORD, FAST)
    restored, plaintext = unlock(keyring.seal(b"hello"), PASSWORD)
    assert plaintext == b"hello"
    assert restored.key == keyring.key


def test_wrong_password(envelope):
    with pytest.raises(DecryptionError):
        unlock(envelope, "not the password")


def test_tampered_ciphertext(envelope):
    envelope["ciphertext"] = flip(envelope["ciphertext"])
    with pytest.raises(DecryptionError):
        unlock(envelope, PASSWORD)


def test_tampered_nonce(envelope):
    envelope["nonce"] = flip(envelope["nonce"])
    with pytest.raises(DecryptionError):
        unlock(envelope, PASSWORD)


def test_tampered_salt(envelope):
    envelope["salt"] = flip(envelope["salt"])
    with pytest.raises(DecryptionError):
        unlock(envelope, PASSWORD)


def test_tampered_kdf_parameters(envelope):
    envelope["kdf"]["r"] = 9
    with pytest.raises(DecryptionError):
        unlock(envelope, PASSWORD)


def test_nonce_is_unique_per_seal():
    keyring = create_keyring(PASSWORD, FAST)
    first = keyring.seal(b"same")
    second = keyring.seal(b"same")
    assert first["nonce"] != second["nonce"]
    assert first["ciphertext"] != second["ciphertext"]


def test_salt_is_unique_per_keyring():
    assert create_keyring(PASSWORD, FAST).salt != create_keyring(PASSWORD, FAST).salt


def test_unicode_password():
    keyring = create_keyring("пароль-🔐-мастер", FAST)
    _, plaintext = unlock(keyring.seal(b"data"), "пароль-🔐-мастер")
    assert plaintext == b"data"


@pytest.mark.parametrize("field,value", [("magic", "other"), ("version", 99)])
def test_rejects_foreign_envelope(envelope, field, value):
    envelope[field] = value
    with pytest.raises(FormatError):
        unlock(envelope, PASSWORD)


def test_rejects_non_object():
    with pytest.raises(FormatError):
        unlock(["not", "a", "vault"], PASSWORD)


def test_rejects_missing_field(envelope):
    broken = copy.deepcopy(envelope)
    del broken["nonce"]
    with pytest.raises(FormatError):
        unlock(broken, PASSWORD)


def test_rejects_invalid_base64(envelope):
    envelope["ciphertext"] = "%%%not-base64%%%"
    with pytest.raises(FormatError):
        unlock(envelope, PASSWORD)


def test_rejects_unknown_kdf(envelope):
    envelope["kdf"]["name"] = "md5"
    with pytest.raises(FormatError):
        unlock(envelope, PASSWORD)


def test_rejects_excessive_memory(envelope):
    envelope["kdf"]["n"] = 2**24
    with pytest.raises(FormatError):
        unlock(envelope, PASSWORD)


def test_rejects_non_power_of_two(envelope):
    envelope["kdf"]["n"] = 1000
    with pytest.raises(FormatError):
        unlock(envelope, PASSWORD)


def test_params_validation():
    with pytest.raises(FormatError):
        KdfParams(n=2**20, r=32, p=1).validate()
    with pytest.raises(FormatError):
        KdfParams(n=2**10, r=8, p=0).validate()
    KdfParams().validate()
