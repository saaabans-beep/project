import getpass
import json

import pytest

from obsidian.cli import main

MASTER = "master-password"
SECRET = "entry-secret"


@pytest.fixture
def path(tmp_path, monkeypatch):
    target = tmp_path / "cli.obs"
    monkeypatch.setenv("OBSIDIAN_VAULT", str(target))
    monkeypatch.setenv("OBSIDIAN_PASSWORD", MASTER)
    monkeypatch.setattr(getpass, "getpass", lambda prompt="": SECRET)
    return target


@pytest.fixture
def ready(path):
    assert main(["init", "--cost", "14"]) == 0
    return path


def run(capsys, *args):
    code = main(list(args))
    captured = capsys.readouterr()
    return code, captured.out, captured.err


def test_init_creates_vault(path, capsys):
    code, out, _ = run(capsys, "init", "--cost", "14")
    assert code == 0
    assert path.is_file()
    assert "Vault created" in out


def test_init_twice_fails(ready, capsys):
    code, _, err = run(capsys, "init", "--cost", "14")
    assert code == 1
    assert "already exists" in err


def test_init_rejects_short_master(path, monkeypatch, capsys):
    monkeypatch.setenv("OBSIDIAN_PASSWORD", "short")
    code, _, err = run(capsys, "init", "--cost", "14")
    assert code == 1
    assert "at least" in err
    assert not path.exists()


def test_missing_vault(path, capsys):
    code, _, err = run(capsys, "list")
    assert code == 1
    assert "not found" in err


def test_vault_option_after_command(ready, capsys):
    code, out, _ = run(capsys, "list", "--vault", str(ready))
    assert code == 0
    assert "No entries" in out


def test_add_prompts_and_get_password_only(ready, capsys):
    assert run(capsys, "add", "github", "-u", "alice", "-t", "dev")[0] == 0
    code, out, _ = run(capsys, "get", "github", "--password-only")
    assert code == 0
    assert out.strip() == SECRET


def test_get_masks_by_default(ready, capsys):
    run(capsys, "add", "github", "-u", "alice")
    _, out, _ = run(capsys, "get", "github")
    assert "alice" in out
    assert "********" in out
    assert SECRET not in out


def test_get_show_reveals(ready, capsys):
    run(capsys, "add", "github")
    _, out, _ = run(capsys, "get", "github", "--show")
    assert SECRET in out


def test_add_generate(ready, capsys):
    code, out, _ = run(capsys, "add", "site", "--generate", "--length", "30")
    assert code == 0
    assert "bits" in out
    _, out, _ = run(capsys, "get", "site", "-p")
    assert len(out.strip()) == 30


def test_add_duplicate(ready, capsys):
    run(capsys, "add", "github")
    code, _, err = run(capsys, "add", "github")
    assert code == 1
    assert "already exists" in err


def test_password_mismatch(ready, monkeypatch, capsys):
    answers = iter(["one", "two"])
    monkeypatch.setattr(getpass, "getpass", lambda prompt="": next(answers))
    code, _, err = run(capsys, "add", "github")
    assert code == 1
    assert "do not match" in err


def test_list_and_filter(ready, capsys):
    run(capsys, "add", "github", "-t", "dev")
    run(capsys, "add", "bank", "-t", "money")
    _, out, _ = run(capsys, "list")
    assert "github" in out and "bank" in out
    _, out, _ = run(capsys, "ls", "--tag", "money")
    assert "bank" in out and "github" not in out


def test_search(ready, capsys):
    run(capsys, "add", "github", "-u", "alice")
    run(capsys, "add", "bank", "-u", "bob")
    _, out, _ = run(capsys, "search", "ali")
    assert "github" in out and "bank" not in out


def test_edit(ready, capsys):
    run(capsys, "add", "github", "-u", "alice")
    code, _, _ = run(capsys, "edit", "github", "-u", "bob", "--url", "https://x.test")
    assert code == 0
    _, out, _ = run(capsys, "get", "github")
    assert "bob" in out and "https://x.test" in out


def test_edit_password(ready, monkeypatch, capsys):
    run(capsys, "add", "github")
    monkeypatch.setattr(getpass, "getpass", lambda prompt="": "changed-secret")
    assert run(capsys, "edit", "github", "--password")[0] == 0
    _, out, _ = run(capsys, "get", "github", "-p")
    assert out.strip() == "changed-secret"


def test_edit_nothing(ready, capsys):
    run(capsys, "add", "github")
    code, _, err = run(capsys, "edit", "github")
    assert code == 1
    assert "nothing to change" in err


def test_rm_with_yes(ready, capsys):
    run(capsys, "add", "github")
    assert run(capsys, "rm", "github", "--yes")[0] == 0
    code, _, err = run(capsys, "get", "github")
    assert code == 1
    assert "no such entry" in err


def test_rm_cancelled(ready, monkeypatch, capsys):
    run(capsys, "add", "github")
    monkeypatch.setattr("builtins.input", lambda prompt="": "n")
    assert run(capsys, "rm", "github")[0] == 1
    assert run(capsys, "get", "github")[0] == 0


def test_rm_confirmed(ready, monkeypatch, capsys):
    run(capsys, "add", "github")
    monkeypatch.setattr("builtins.input", lambda prompt="": "y")
    assert run(capsys, "rm", "github")[0] == 0
    assert run(capsys, "get", "github")[0] == 1


def test_wrong_master(ready, monkeypatch, capsys):
    monkeypatch.setenv("OBSIDIAN_PASSWORD", "totally-wrong-pass")
    code, _, err = run(capsys, "list")
    assert code == 1
    assert "wrong password" in err


def test_gen(capsys):
    code, out, err = run(capsys, "gen", "--length", "32", "--no-symbols")
    assert code == 0
    password = out.strip()
    assert len(password) == 32
    assert password.isalnum()
    assert "strength" in err


def test_gen_invalid_length(capsys):
    code, _, err = run(capsys, "gen", "--length", "2")
    assert code == 1
    assert "length" in err


def test_passwd(ready, monkeypatch, capsys):
    run(capsys, "add", "github")
    monkeypatch.setattr(getpass, "getpass", lambda prompt="": "new-master-pass")
    assert run(capsys, "passwd")[0] == 0
    code, _, _ = run(capsys, "list")
    assert code == 1
    monkeypatch.setenv("OBSIDIAN_PASSWORD", "new-master-pass")
    code, out, _ = run(capsys, "list")
    assert code == 0 and "github" in out


def test_info(ready, capsys):
    _, out, _ = run(capsys, "info")
    assert "AES-256-GCM" in out
    assert "scrypt" in out


def test_export_and_import(ready, tmp_path, monkeypatch, capsys):
    run(capsys, "add", "github", "-u", "alice", "-t", "dev")
    dump = tmp_path / "dump.json"
    code, _, err = run(capsys, "export", "-o", str(dump))
    assert code == 0
    assert "NOT encrypted" in err
    data = json.loads(dump.read_text())
    assert data["entries"][0]["name"] == "github"

    monkeypatch.setenv("OBSIDIAN_VAULT", str(tmp_path / "second.obs"))
    assert run(capsys, "init", "--cost", "14")[0] == 0
    code, out, _ = run(capsys, "import", str(dump))
    assert code == 0
    assert "1 added" in out
    _, out, _ = run(capsys, "get", "github", "--show")
    assert SECRET in out


def test_export_refuses_overwrite(ready, tmp_path, capsys):
    dump = tmp_path / "dump.json"
    dump.write_text("{}")
    code, _, err = run(capsys, "export", "-o", str(dump))
    assert code == 1
    assert "--force" in err
    assert run(capsys, "export", "-o", str(dump), "--force")[0] == 0


def test_import_bad_file(ready, tmp_path, capsys):
    broken = tmp_path / "broken.json"
    broken.write_text("not json")
    code, _, err = run(capsys, "import", str(broken))
    assert code == 1
    assert "cannot read" in err


def test_version(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert "obsidian" in capsys.readouterr().out
