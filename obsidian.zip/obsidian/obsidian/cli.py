import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from . import __version__
from .crypto import CryptoError, KdfParams
from .generator import entropy_bits, generate_password, strength_label
from .vault import (
    Entry,
    EntryExistsError,
    Vault,
    VaultError,
    VaultNotFoundError,
    check_master_password,
)

DEFAULT_VAULT = Path.home() / ".obsidian" / "vault.obs"
ENV_VAULT = "OBSIDIAN_VAULT"
ENV_PASSWORD = "OBSIDIAN_PASSWORD"
MASK = "*" * 8


def resolve_path(value):
    if value:
        return Path(value).expanduser()
    env = os.environ.get(ENV_VAULT)
    if env:
        return Path(env).expanduser()
    return DEFAULT_VAULT


def confirm_secret(first_prompt, second_prompt):
    first = getpass.getpass(first_prompt)
    second = getpass.getpass(second_prompt)
    if first != second:
        raise VaultError("passwords do not match")
    return first


def ask_master():
    env = os.environ.get(ENV_PASSWORD)
    if env is not None:
        return env
    return getpass.getpass("Master password: ")


def ask_new_master(allow_env=True):
    env = os.environ.get(ENV_PASSWORD) if allow_env else None
    if env is not None:
        secret = env
    else:
        secret = confirm_secret("New master password: ", "Repeat master password: ")
    check_master_password(secret)
    return secret


def open_vault(args):
    path = resolve_path(args.vault)
    if not path.is_file():
        raise VaultNotFoundError(f"vault not found: {path} (run 'obsidian init')")
    return Vault.open(path, ask_master())


def generate_from_args(args):
    return generate_password(
        length=args.length,
        upper=not args.no_upper,
        digits=not args.no_digits,
        symbols=not args.no_symbols,
        avoid_ambiguous=args.avoid_ambiguous,
    )


def entry_secret(args):
    if args.generate:
        return generate_from_args(args)
    secret = confirm_secret("Entry password: ", "Repeat entry password: ")
    if not secret:
        raise VaultError("entry password must not be empty")
    return secret


def strength_line(secret):
    bits = entropy_bits(secret)
    return f"{strength_label(bits)}, {bits:.0f} bits"


def print_entry(entry, reveal):
    rows = [
        ("Name", entry.name),
        ("Username", entry.username),
        ("Password", entry.password if reveal else MASK),
        ("URL", entry.url),
        ("Tags", ", ".join(entry.tags)),
        ("Notes", entry.notes),
        ("Created", entry.created),
        ("Updated", entry.updated),
    ]
    for label, value in rows:
        if value:
            print(f"{label + ':':<10} {value}")


def print_table(entries):
    if not entries:
        print("No entries")
        return
    headers = ("NAME", "USERNAME", "URL", "TAGS")
    rows = [(e.name, e.username, e.url, ",".join(e.tags)) for e in entries]
    widths = [max(len(headers[i]), *(len(row[i]) for row in rows)) for i in range(4)]
    for row in [headers, *rows]:
        line = "  ".join(cell.ljust(widths[i]) for i, cell in enumerate(row))
        print(line.rstrip())


def cmd_init(args):
    path = resolve_path(args.vault)
    if path.exists():
        raise VaultError(f"vault already exists: {path}")
    master = ask_new_master()
    Vault.create(path, master, KdfParams(n=2**args.cost))
    print(f"Vault created: {path}")
    return 0


def cmd_add(args):
    vault = open_vault(args)
    name = args.name.strip()
    if name in vault:
        raise EntryExistsError(f"entry already exists: {name}")
    secret = entry_secret(args)
    entry = Entry(
        name=name,
        username=args.username or "",
        password=secret,
        url=args.url or "",
        notes=args.notes or "",
        tags=args.tag or [],
    )
    vault.add(entry)
    vault.save()
    print(f"Added: {entry.name} [{strength_line(secret)}]")
    return 0


def cmd_get(args):
    vault = open_vault(args)
    entry = vault.get(args.name)
    if args.password_only:
        print(entry.password)
    else:
        print_entry(entry, reveal=args.show)
    return 0


def cmd_list(args):
    vault = open_vault(args)
    print_table(vault.entries(tag=args.tag))
    return 0


def cmd_search(args):
    vault = open_vault(args)
    print_table(vault.search(args.query))
    return 0


def cmd_edit(args):
    vault = open_vault(args)
    vault.get(args.name)
    changes = {
        "username": args.username,
        "url": args.url,
        "notes": args.notes,
        "tags": args.tag,
    }
    if args.generate or args.password:
        changes["password"] = entry_secret(args)
    if all(value is None for value in changes.values()):
        raise VaultError("nothing to change")
    vault.update(args.name, **changes)
    vault.save()
    print(f"Updated: {args.name}")
    return 0


def cmd_rm(args):
    vault = open_vault(args)
    vault.get(args.name)
    if not args.yes:
        answer = input(f"Remove '{args.name}'? [y/N] ")
        if answer.strip().lower() not in ("y", "yes"):
            print("Cancelled")
            return 1
    vault.remove(args.name)
    vault.save()
    print(f"Removed: {args.name}")
    return 0


def cmd_gen(args):
    secret = generate_from_args(args)
    print(secret)
    print(f"strength: {strength_line(secret)}", file=sys.stderr)
    return 0


def cmd_passwd(args):
    vault = open_vault(args)
    vault.change_password(ask_new_master(allow_env=False))
    print("Master password changed")
    return 0


def cmd_info(args):
    vault = open_vault(args)
    for key, value in vault.info().items():
        print(f"{key + ':':<9} {value}")
    return 0


def cmd_export(args):
    vault = open_vault(args)
    target = Path(args.output).expanduser()
    mode = os.O_TRUNC if args.force else os.O_EXCL
    try:
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | mode, 0o600)
    except FileExistsError:
        raise VaultError(f"file exists: {target} (use --force)") from None
    payload = {"format": "obsidian-export", "version": 1, "entries": vault.export_entries()}
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    print(f"Exported {len(vault)} entries to {target}")
    print("warning: the export file is NOT encrypted", file=sys.stderr)
    return 0


def cmd_import(args):
    source = Path(args.input).expanduser()
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise VaultError(f"cannot read {source}: {exc}") from exc
    items = data.get("entries") if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise VaultError("import file has no list of entries")
    vault = open_vault(args)
    added, replaced, skipped = vault.import_entries(items, overwrite=args.overwrite)
    vault.save()
    print(f"Imported: {added} added, {replaced} replaced, {skipped} skipped")
    return 0


def add_generator_options(parser):
    parser.add_argument("-l", "--length", type=int, default=20, help="generated password length")
    parser.add_argument("--no-upper", action="store_true", help="exclude uppercase letters")
    parser.add_argument("--no-digits", action="store_true", help="exclude digits")
    parser.add_argument("--no-symbols", action="store_true", help="exclude symbols")
    parser.add_argument(
        "--avoid-ambiguous", action="store_true", help="exclude look-alike characters"
    )


def build_parser():
    parser = argparse.ArgumentParser(
        prog="obsidian",
        description="Obsidian - CryptVault: encrypted local vault for passwords and secrets",
    )
    parser.add_argument("-V", "--version", action="version", version=f"obsidian {__version__}")
    parser.add_argument("-v", "--vault", default=None, help="path to the vault file")

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "-v", "--vault", default=argparse.SUPPRESS, help="path to the vault file"
    )

    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    p = sub.add_parser("init", parents=[common], help="create a new vault")
    p.add_argument(
        "--cost",
        type=int,
        choices=range(14, 21),
        default=17,
        metavar="N",
        help="scrypt work factor as a power of two, 14-20 (default: 17)",
    )
    p.set_defaults(handler=cmd_init)

    p = sub.add_parser("add", parents=[common], help="add an entry")
    p.add_argument("name")
    p.add_argument("-u", "--username")
    p.add_argument("--url")
    p.add_argument("-n", "--notes")
    p.add_argument("-t", "--tag", action="append", help="tag (repeatable)")
    p.add_argument("-g", "--generate", action="store_true", help="generate the password")
    add_generator_options(p)
    p.set_defaults(handler=cmd_add)

    p = sub.add_parser("get", parents=[common], help="show an entry")
    p.add_argument("name")
    p.add_argument("-s", "--show", action="store_true", help="reveal the password")
    p.add_argument(
        "-p", "--password-only", action="store_true", help="print only the password"
    )
    p.set_defaults(handler=cmd_get)

    p = sub.add_parser("list", aliases=["ls"], parents=[common], help="list entries")
    p.add_argument("-t", "--tag", help="filter by tag")
    p.set_defaults(handler=cmd_list)

    p = sub.add_parser("search", parents=[common], help="search entries")
    p.add_argument("query")
    p.set_defaults(handler=cmd_search)

    p = sub.add_parser("edit", parents=[common], help="edit an entry")
    p.add_argument("name")
    p.add_argument("-u", "--username")
    p.add_argument("--url")
    p.add_argument("-n", "--notes")
    p.add_argument("-t", "--tag", action="append", help="replace tags (repeatable)")
    p.add_argument("-p", "--password", action="store_true", help="prompt for a new password")
    p.add_argument("-g", "--generate", action="store_true", help="generate a new password")
    add_generator_options(p)
    p.set_defaults(handler=cmd_edit)

    p = sub.add_parser("rm", aliases=["remove"], parents=[common], help="remove an entry")
    p.add_argument("name")
    p.add_argument("-y", "--yes", action="store_true", help="do not ask for confirmation")
    p.set_defaults(handler=cmd_rm)

    p = sub.add_parser("gen", help="generate a password without a vault")
    add_generator_options(p)
    p.set_defaults(handler=cmd_gen)

    p = sub.add_parser("passwd", parents=[common], help="change the master password")
    p.set_defaults(handler=cmd_passwd)

    p = sub.add_parser("info", parents=[common], help="show vault information")
    p.set_defaults(handler=cmd_info)

    p = sub.add_parser("export", parents=[common], help="export entries to plain JSON")
    p.add_argument("-o", "--output", required=True)
    p.add_argument("-f", "--force", action="store_true", help="overwrite an existing file")
    p.set_defaults(handler=cmd_export)

    p = sub.add_parser("import", parents=[common], help="import entries from JSON")
    p.add_argument("input")
    p.add_argument("--overwrite", action="store_true", help="replace entries with the same name")
    p.set_defaults(handler=cmd_import)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.handler(args)
    except (VaultError, CryptoError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print(file=sys.stderr)
        return 130
