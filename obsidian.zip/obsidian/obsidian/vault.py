import json
import os
import tempfile
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path

from .crypto import create_keyring, unlock

PAYLOAD_VERSION = 1
MIN_MASTER_LENGTH = 8
EDITABLE_FIELDS = ("username", "password", "url", "notes", "tags")
TEXT_FIELDS = ("username", "password", "url", "notes", "created", "updated")


class VaultError(Exception):
    pass


class VaultExistsError(VaultError):
    pass


class VaultNotFoundError(VaultError):
    pass


class EntryExistsError(VaultError):
    pass


class EntryNotFoundError(VaultError):
    pass


def check_master_password(password):
    if len(password) < MIN_MASTER_LENGTH:
        raise VaultError(f"master password must be at least {MIN_MASTER_LENGTH} characters")


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clean_tags(tags):
    result = []
    for tag in tags or []:
        value = str(tag).strip()
        if value and value not in result:
            result.append(value)
    return result


def _atomic_write(path, data):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".obsidian-", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


@dataclass
class Entry:
    name: str
    username: str = ""
    password: str = ""
    url: str = ""
    notes: str = ""
    tags: list = field(default_factory=list)
    created: str = ""
    updated: str = ""

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise VaultError("entry must be an object")
        name = data.get("name")
        if not isinstance(name, str) or not name.strip():
            raise VaultError("entry has no name")
        allowed = {item.name for item in fields(cls)}
        values = {key: value for key, value in data.items() if key in allowed}
        for key in TEXT_FIELDS:
            if key in values:
                values[key] = "" if values[key] is None else str(values[key])
        values["name"] = name.strip()
        values["tags"] = _clean_tags(values.get("tags"))
        return cls(**values)


class Vault:
    def __init__(self, path, keyring, entries):
        self.path = Path(path)
        self._keyring = keyring
        self._entries = entries

    @classmethod
    def create(cls, path, password, params=None):
        path = Path(path)
        check_master_password(password)
        if path.exists():
            raise VaultExistsError(f"vault already exists: {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        vault = cls(path, create_keyring(password, params), {})
        vault.save()
        return vault

    @classmethod
    def open(cls, path, password):
        path = Path(path)
        if not path.is_file():
            raise VaultNotFoundError(f"vault not found: {path}")
        try:
            envelope = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise VaultError(f"cannot read vault: {exc}") from exc
        keyring, plaintext = unlock(envelope, password)
        try:
            payload = json.loads(plaintext.decode("utf-8"))
            entries = [Entry.from_dict(item) for item in payload["entries"]]
        except (ValueError, KeyError, TypeError) as exc:
            raise VaultError("vault payload is corrupted") from exc
        return cls(path, keyring, {entry.name: entry for entry in entries})

    def __len__(self):
        return len(self._entries)

    def __contains__(self, name):
        return name in self._entries

    def entries(self, tag=None):
        items = sorted(self._entries.values(), key=lambda entry: entry.name.lower())
        if tag is not None:
            items = [entry for entry in items if tag in entry.tags]
        return items

    def get(self, name):
        try:
            return self._entries[name]
        except KeyError:
            raise EntryNotFoundError(f"no such entry: {name}") from None

    def add(self, entry):
        name = entry.name.strip()
        if not name:
            raise VaultError("entry name must not be empty")
        if name in self._entries:
            raise EntryExistsError(f"entry already exists: {name}")
        stamp = _now()
        entry.name = name
        entry.tags = _clean_tags(entry.tags)
        entry.created = stamp
        entry.updated = stamp
        self._entries[name] = entry
        return entry

    def update(self, name, **changes):
        entry = self.get(name)
        unknown = set(changes) - set(EDITABLE_FIELDS)
        if unknown:
            raise VaultError(f"cannot edit field: {', '.join(sorted(unknown))}")
        for key, value in changes.items():
            if value is None:
                continue
            setattr(entry, key, _clean_tags(value) if key == "tags" else value)
        entry.updated = _now()
        return entry

    def remove(self, name):
        self.get(name)
        del self._entries[name]

    def search(self, query):
        needle = query.strip().lower()
        if not needle:
            return []
        hits = []
        for entry in self.entries():
            haystack = [entry.name, entry.username, entry.url, entry.notes, *entry.tags]
            if any(needle in text.lower() for text in haystack):
                hits.append(entry)
        return hits

    def change_password(self, new_password, params=None):
        check_master_password(new_password)
        self._keyring = create_keyring(new_password, params or self._keyring.params)
        self.save()

    def export_entries(self):
        return [asdict(entry) for entry in self.entries()]

    def import_entries(self, items, overwrite=False):
        parsed = [Entry.from_dict(item) for item in items]
        added = replaced = skipped = 0
        stamp = _now()
        for entry in parsed:
            existing = self._entries.get(entry.name)
            if existing is not None and not overwrite:
                skipped += 1
                continue
            entry.created = existing.created if existing else (entry.created or stamp)
            entry.updated = stamp
            self._entries[entry.name] = entry
            if existing is None:
                added += 1
            else:
                replaced += 1
        return added, replaced, skipped

    def info(self):
        params = self._keyring.params
        return {
            "path": str(self.path),
            "entries": len(self._entries),
            "size": self.path.stat().st_size if self.path.exists() else 0,
            "cipher": "AES-256-GCM",
            "kdf": f"scrypt (n={params.n}, r={params.r}, p={params.p})",
        }

    def save(self):
        payload = {
            "version": PAYLOAD_VERSION,
            "entries": [asdict(entry) for entry in self._entries.values()],
        }
        plaintext = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        envelope = self._keyring.seal(plaintext)
        _atomic_write(self.path, json.dumps(envelope, indent=2).encode("utf-8"))
