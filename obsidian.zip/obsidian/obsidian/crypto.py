import base64
import binascii
import json
import os
from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = "obsidian"
FORMAT_VERSION = 1
KEY_LENGTH = 32
SALT_LENGTH = 16
NONCE_LENGTH = 12
MAX_MEMORY = 2**30
MAX_P = 8


class CryptoError(Exception):
    pass


class DecryptionError(CryptoError):
    pass


class FormatError(CryptoError):
    pass


@dataclass(frozen=True)
class KdfParams:
    n: int = 2**17
    r: int = 8
    p: int = 1

    def validate(self):
        if self.n < 2 or self.n & (self.n - 1):
            raise FormatError("KDF parameter n must be a power of two")
        if self.r < 1 or not 1 <= self.p <= MAX_P:
            raise FormatError("KDF parameters r or p are out of range")
        if 128 * self.n * self.r > MAX_MEMORY:
            raise FormatError("KDF parameters require too much memory")


@dataclass
class Keyring:
    key: bytes
    salt: bytes
    params: KdfParams

    def seal(self, plaintext):
        nonce = os.urandom(NONCE_LENGTH)
        header = _header(self.salt, self.params)
        ciphertext = AESGCM(self.key).encrypt(nonce, plaintext, _aad(header))
        return {**header, "nonce": _b64e(nonce), "ciphertext": _b64e(ciphertext)}


def _b64e(raw):
    return base64.b64encode(raw).decode("ascii")


def _b64d(text):
    try:
        return base64.b64decode(text, validate=True)
    except (binascii.Error, ValueError, TypeError) as exc:
        raise FormatError("corrupted vault encoding") from exc


def _header(salt, params):
    return {
        "magic": MAGIC,
        "version": FORMAT_VERSION,
        "kdf": {"name": "scrypt", "n": params.n, "r": params.r, "p": params.p},
        "salt": _b64e(salt),
    }


def _aad(header):
    return json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _derive(password, salt, params):
    kdf = Scrypt(salt=salt, length=KEY_LENGTH, n=params.n, r=params.r, p=params.p)
    return kdf.derive(password.encode("utf-8"))


def create_keyring(password, params=None):
    params = params or KdfParams()
    params.validate()
    salt = os.urandom(SALT_LENGTH)
    return Keyring(_derive(password, salt, params), salt, params)


def unlock(envelope, password):
    if not isinstance(envelope, dict) or envelope.get("magic") != MAGIC:
        raise FormatError("not an Obsidian vault")
    if envelope.get("version") != FORMAT_VERSION:
        raise FormatError("unsupported vault version")
    try:
        kdf = envelope["kdf"]
        if kdf["name"] != "scrypt":
            raise FormatError("unsupported key derivation function")
        params = KdfParams(int(kdf["n"]), int(kdf["r"]), int(kdf["p"]))
        salt = _b64d(envelope["salt"])
        nonce = _b64d(envelope["nonce"])
        ciphertext = _b64d(envelope["ciphertext"])
    except (KeyError, TypeError, ValueError) as exc:
        raise FormatError("corrupted vault header") from exc
    params.validate()
    if len(salt) != SALT_LENGTH or len(nonce) != NONCE_LENGTH:
        raise FormatError("corrupted vault header")
    key = _derive(password, salt, params)
    try:
        plaintext = AESGCM(key).decrypt(nonce, ciphertext, _aad(_header(salt, params)))
    except InvalidTag as exc:
        raise DecryptionError("wrong password or corrupted vault") from exc
    return Keyring(key, salt, params), plaintext
