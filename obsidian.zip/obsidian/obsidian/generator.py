import math
import secrets
import string

AMBIGUOUS = frozenset("O0oIl1|`'\"")
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>?/~"
MIN_LENGTH = 4
MAX_LENGTH = 1024


def _pools(lower, upper, digits, symbols, avoid_ambiguous):
    candidates = []
    if lower:
        candidates.append(string.ascii_lowercase)
    if upper:
        candidates.append(string.ascii_uppercase)
    if digits:
        candidates.append(string.digits)
    if symbols:
        candidates.append(SYMBOLS)
    if avoid_ambiguous:
        candidates = ["".join(ch for ch in pool if ch not in AMBIGUOUS) for pool in candidates]
    return [pool for pool in candidates if pool]


def generate_password(
    length=20,
    lower=True,
    upper=True,
    digits=True,
    symbols=True,
    avoid_ambiguous=False,
):
    if not MIN_LENGTH <= length <= MAX_LENGTH:
        raise ValueError(f"length must be between {MIN_LENGTH} and {MAX_LENGTH}")
    pools = _pools(lower, upper, digits, symbols, avoid_ambiguous)
    if not pools:
        raise ValueError("at least one character class must be enabled")
    alphabet = "".join(pools)
    chars = [secrets.choice(pool) for pool in pools]
    chars.extend(secrets.choice(alphabet) for _ in range(length - len(chars)))
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)


def entropy_bits(password):
    if not password:
        return 0.0
    size = 0
    if any(ch in string.ascii_lowercase for ch in password):
        size += 26
    if any(ch in string.ascii_uppercase for ch in password):
        size += 26
    if any(ch in string.digits for ch in password):
        size += 10
    if any(ch not in string.ascii_letters + string.digits for ch in password):
        size += 32
    return len(password) * math.log2(size)


def strength_label(bits):
    if bits < 40:
        return "weak"
    if bits < 60:
        return "fair"
    if bits < 80:
        return "good"
    if bits < 100:
        return "strong"
    return "very strong"
