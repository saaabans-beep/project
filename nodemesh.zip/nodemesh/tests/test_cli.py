import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest
from support import SECRET, BackgroundCluster

from nodemesh.cli import build_parser, main, parse_params

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def background():
    with BackgroundCluster(workers=1, slots=2) as running:
        yield running


@pytest.fixture
def env(background, monkeypatch):
    monkeypatch.setenv("NODEMESH_SECRET", SECRET)
    monkeypatch.setenv("NODEMESH_HOST", "127.0.0.1")
    monkeypatch.setenv("NODEMESH_PORT", str(background.port))
    return background


def cli(capsys, *args):
    code = main(list(args))
    captured = capsys.readouterr()
    return code, captured.out, captured.err


def test_parse_params():
    assert parse_params(["a=1", "b=text", "c=[1,2]", "d=true", "e=1.5"], None) == {
        "a": 1,
        "b": "text",
        "c": [1, 2],
        "d": True,
        "e": 1.5,
    }
    assert parse_params(["a=2"], '{"a": 1, "b": 3}') == {"a": 2, "b": 3}
    assert parse_params(None, None) == {}


@pytest.mark.parametrize("pairs,raw", [(["novalue"], None), (["=x"], None), ([], "[1]"), ([], "{bad")])
def test_parse_params_errors(pairs, raw):
    with pytest.raises(ValueError):
        parse_params(pairs, raw)


def test_parser_covers_commands():
    parser = build_parser()
    for command in (
        "coordinator", "worker", "submit", "run", "status", "result", "wait",
        "cancel", "jobs", "workers", "stats", "kinds", "demo", "gen-secret",
    ):
        assert command in parser._subparsers._group_actions[0].choices


def test_gen_secret(capsys):
    code, out, _ = cli(capsys, "gen-secret")
    assert code == 0
    assert len(out.strip()) == 64
    assert out.strip() != cli(capsys, "gen-secret")[1].strip()


def test_missing_secret(capsys, monkeypatch):
    monkeypatch.delenv("NODEMESH_SECRET", raising=False)
    code, _, err = cli(capsys, "stats")
    assert code == 1
    assert "secret is required" in err


def test_wrong_secret(env, capsys):
    code, _, err = cli(capsys, "--log-level", "error", "stats", "--secret", "definitely-not-it")
    assert code == 1
    assert "authentication failed" in err


def test_connection_refused(capsys, monkeypatch):
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    monkeypatch.setenv("NODEMESH_SECRET", SECRET)
    code, _, err = cli(capsys, "stats", "--port", str(port))
    assert code == 1
    assert err.startswith("error:")


def test_run_prints_result(env, capsys):
    code, out, _ = cli(capsys, "run", "sum_squares", "-p", "stop=1000", "-p", "parts=4")
    assert code == 0
    assert json.loads(out) == sum(i * i for i in range(1000))


def test_run_with_json_parameters(env, capsys):
    code, out, _ = cli(
        capsys, "run", "word_count", "--json", '{"texts": ["a b a", "b a"], "top": 1}'
    )
    assert code == 0
    assert json.loads(out)["top"] == [["a", 3]]


def test_submit_wait_and_status_flow(env, capsys):
    code, out, _ = cli(capsys, "submit", "echo", "-p", 'value="hi"')
    assert code == 0
    job_id = json.loads(out)["job"]
    code, out, _ = cli(capsys, "wait", job_id, "--timeout", "10")
    assert code == 0
    assert json.loads(out)["result"] == "hi"
    code, out, _ = cli(capsys, "status", job_id)
    assert json.loads(out)["status"] == "done"
    code, out, _ = cli(capsys, "result", job_id)
    assert json.loads(out) == "hi"
    code, out, _ = cli(capsys, "cancel", job_id)
    assert code == 1
    assert json.loads(out) == {"cancelled": False}


def test_submit_with_wait_flag(env, capsys):
    code, out, _ = cli(capsys, "submit", "sum_squares", "-p", "stop=10", "--wait")
    assert code == 0
    assert json.loads(out)["result"] == 285


def test_failed_job_exit_code(env, capsys):
    code, _, err = cli(capsys, "run", "fail", "-p", "message=nope", "--max-attempts", "1")
    assert code == 1
    assert "nope" in err
    code, out, _ = cli(capsys, "submit", "fail", "--max-attempts", "1", "--wait")
    assert code == 1
    assert json.loads(out)["status"] == "failed"


def test_run_timeout_exit_code(env, capsys):
    code, _, err = cli(capsys, "run", "sleep", "-p", "seconds=3", "--timeout", "0.3")
    assert code == 3
    assert "timed out" in err


def test_invalid_job_parameters(env, capsys):
    code, _, err = cli(capsys, "run", "sum_squares", "-p", "stop=abc")
    assert code == 1
    assert "invalid job parameters" in err
    code, _, err = cli(capsys, "run", "no_such_task")
    assert code == 1
    assert "unknown task kind" in err


def test_listing_commands(env, capsys):
    cli(capsys, "run", "echo", "-p", "value=1")
    code, out, _ = cli(capsys, "jobs", "--limit", "5")
    assert code == 0 and isinstance(json.loads(out), list)
    code, out, _ = cli(capsys, "workers")
    assert json.loads(out)[0]["name"] == "bg0"
    code, out, _ = cli(capsys, "stats")
    assert json.loads(out)["workers"] == 1
    code, out, _ = cli(capsys, "kinds")
    assert "count_primes" in json.loads(out)


def test_demo_small(capsys):
    code, out, _ = cli(capsys, "demo", "--size", "small", "--workers", "2", "--slots", "2", "--executor", "thread")
    assert code == 0
    assert "count_primes" in out and "17984" in out
    assert "demo-1" in out and "demo-2" in out


def free_port():
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    return port


def run_cli(env, *args, timeout=60):
    return subprocess.run(
        [sys.executable, "-m", "nodemesh", *args],
        env=env,
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def test_real_processes_end_to_end():
    port = free_port()
    env = {**os.environ, "NODEMESH_SECRET": SECRET, "NODEMESH_PORT": str(port), "PYTHONPATH": str(ROOT)}
    coordinator = subprocess.Popen(
        [sys.executable, "-m", "nodemesh", "--log-level", "warning", "coordinator", "--port", str(port)],
        env=env, cwd=ROOT, stderr=subprocess.PIPE, text=True,
    )
    workers = []
    try:
        deadline = time.time() + 20
        while time.time() < deadline:
            try:
                socket.create_connection(("127.0.0.1", port), timeout=0.5).close()
                break
            except OSError:
                time.sleep(0.1)
        for index in range(2):
            workers.append(
                subprocess.Popen(
                    [sys.executable, "-m", "nodemesh", "--log-level", "warning", "worker",
                     "--name", f"proc-{index}", "--slots", "2", "--executor", "process"],
                    env=env, cwd=ROOT, stderr=subprocess.PIPE, text=True,
                )
            )
        deadline = time.time() + 30
        while time.time() < deadline:
            listing = run_cli(env, "workers")
            if listing.returncode == 0 and len(json.loads(listing.stdout)) == 2:
                break
            time.sleep(0.2)
        else:
            pytest.fail("workers did not register")
        done = run_cli(env, "run", "count_primes", "-p", "stop=500000", "-p", "parts=8")
        assert done.returncode == 0, done.stderr
        assert json.loads(done.stdout) == 41538
        stats = json.loads(run_cli(env, "stats").stdout)
        assert stats["workers"] == 2
        assert stats["tasks_completed"] == 8
        bad = run_cli(env, "stats", "--secret", "wrong-secret-here")
        assert bad.returncode == 1
    finally:
        for process in [*workers, coordinator]:
            process.terminate()
        for process in [*workers, coordinator]:
            try:
                process.wait(10)
            except subprocess.TimeoutExpired:
                process.kill()
