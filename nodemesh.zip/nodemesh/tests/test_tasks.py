import math

import pytest

from nodemesh import tasks
from nodemesh.tasks import TaskError, UnknownTask, execute, job_kind, split_range


def run_job(kind, params):
    spec = job_kind(kind)
    payloads = spec.split(params)
    return spec.reduce([spec.run(payload) for payload in payloads], params)


@pytest.mark.parametrize(
    "start,stop,parts",
    [(0, 10, 3), (5, 6, 4), (0, 100, 7), (-10, 10, 5), (0, 1, 1), (3, 1000, 1000)],
)
def test_split_range_covers_exactly(start, stop, parts):
    ranges = split_range(start, stop, parts)
    assert ranges[0][0] == start
    assert ranges[-1][1] == stop
    assert all(a < b for a, b in ranges)
    assert all(ranges[i][1] == ranges[i + 1][0] for i in range(len(ranges) - 1))
    assert len(ranges) == min(parts, stop - start)
    sizes = [b - a for a, b in ranges]
    assert max(sizes) - min(sizes) <= 1


def test_split_range_empty():
    assert split_range(5, 5, 3) == []
    assert split_range(9, 2, 3) == []


def test_sum_squares_matches_formula():
    n = 5000
    expected = (n - 1) * n * (2 * n - 1) // 6
    assert run_job("sum_squares", {"stop": n, "parts": 7}) == expected


def test_sum_squares_with_offset():
    assert run_job("sum_squares", {"start": 10, "stop": 20, "parts": 3}) == sum(
        i * i for i in range(10, 20)
    )


@pytest.mark.parametrize(
    "stop,expected", [(2, 0), (3, 1), (10, 4), (100, 25), (1000, 168), (100_000, 9592)]
)
def test_count_primes_known_values(stop, expected):
    assert run_job("count_primes", {"stop": stop, "parts": 5}) == expected


def test_count_primes_one_million():
    assert run_job("count_primes", {"stop": 1_000_000, "parts": 9}) == 78498


def test_count_primes_is_independent_of_splitting():
    values = {run_job("count_primes", {"start": 50, "stop": 20_000, "parts": p}) for p in (1, 2, 13, 64)}
    assert len(values) == 1


def test_count_primes_range_not_starting_at_zero():
    brute = sum(
        all(n % d for d in range(2, math.isqrt(n) + 1)) for n in range(1000, 3000)
    )
    assert run_job("count_primes", {"start": 1000, "stop": 3000, "parts": 4}) == brute


def test_monte_carlo_is_deterministic_and_close_to_pi():
    params = {"samples": 200_000, "parts": 4, "seed": 7}
    first = run_job("monte_carlo_pi", params)
    second = run_job("monte_carlo_pi", params)
    assert first == second
    assert first["samples"] == 200_000
    assert abs(first["pi"] - math.pi) < 0.02
    other = run_job("monte_carlo_pi", {**params, "seed": 8})
    assert other["pi"] != first["pi"]


def test_hash_chain_is_deterministic():
    params = {"data": "x", "rounds": 100, "parts": 3}
    first = run_job("hash_chain", params)
    assert first == run_job("hash_chain", params)
    assert first["parts"] == 3
    assert len(first["digest"]) == 64
    assert first != run_job("hash_chain", {**params, "data": "y"})


def test_word_count():
    result = run_job(
        "word_count",
        {"texts": ["the cat and the hat", "The dog", "cat cat"], "parts": 2, "top": 2},
    )
    assert result["total"] == 9
    assert result["unique"] == 5
    assert result["top"] == [["cat", 3], ["the", 3]]


def test_word_count_unicode():
    result = run_job("word_count", {"texts": ["Привет мир привет"], "top": 1})
    assert result["top"] == [["привет", 2]]


def test_sleep_and_echo():
    assert run_job("sleep", {"seconds": 0, "parts": 3}) == {"tasks": 3, "slept": 0}
    assert run_job("echo", {"value": {"a": [1, 2]}}) == {"a": [1, 2]}


@pytest.mark.parametrize(
    "kind,params",
    [
        ("sum_squares", {}),
        ("sum_squares", {"stop": "10"}),
        ("sum_squares", {"stop": 10, "start": 20}),
        ("sum_squares", {"stop": 10, "parts": 0}),
        ("sum_squares", {"stop": 10.5}),
        ("sum_squares", {"stop": True}),
        ("monte_carlo_pi", {"samples": 0}),
        ("word_count", {"texts": []}),
        ("word_count", {"texts": [1, 2]}),
        ("sleep", {"seconds": -1}),
        ("sleep", {"seconds": float("inf")}),
        ("hash_chain", {"data": 5}),
    ],
)
def test_split_validation(kind, params):
    with pytest.raises(TaskError):
        job_kind(kind).split(params)


def test_execute_wraps_errors():
    outcome = execute("fail", {"message": "kaput"})
    assert outcome == {"ok": False, "error": "RuntimeError: kaput"}
    assert execute("echo", {"value": 3}) == {"ok": True, "result": 3}
    unknown = execute("nonexistent", {})
    assert unknown["ok"] is False
    assert "unknown task kind" in unknown["error"]


def test_unknown_kind():
    with pytest.raises(UnknownTask):
        job_kind("nonexistent")


def test_register_custom_task_and_duplicates():
    name = "test_custom_double"

    @tasks.task(name, reduce=lambda results, params: sum(results))
    def double(payload):
        return payload["x"] * 2

    try:
        assert name in tasks.registered()
        assert execute(name, {"x": 21}) == {"ok": True, "result": 42}
        with pytest.raises(TaskError):
            tasks.task(name)(lambda payload: None)
        tasks.task(name, replace=True)(lambda payload: "replaced")
        assert execute(name, {}) == {"ok": True, "result": "replaced"}
    finally:
        tasks._REGISTRY.pop(name, None)


def test_describe_lists_builtins():
    described = tasks.describe()
    for name in ("count_primes", "sum_squares", "monte_carlo_pi", "word_count"):
        assert described[name]


def test_load_plugins(tmp_path, monkeypatch):
    module = tmp_path / "nm_plugin_demo.py"
    module.write_text(
        "from nodemesh.tasks import task\n"
        "@task('plugin_square')\n"
        "def square(payload):\n"
        "    return payload['n'] ** 2\n"
    )
    monkeypatch.syspath_prepend(str(tmp_path))
    try:
        tasks.load_plugins(["nm_plugin_demo"])
        assert execute("plugin_square", {"n": 9}) == {"ok": True, "result": 81}
    finally:
        tasks._REGISTRY.pop("plugin_square", None)
