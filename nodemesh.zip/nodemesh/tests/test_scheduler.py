import pytest

from nodemesh import config
from nodemesh.scheduler import (
    CANCELLED,
    DONE,
    FAILED,
    PENDING,
    RUNNING,
    Scheduler,
    SchedulerError,
    UnknownJob,
)
from nodemesh.tasks import UnknownTask


class Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now

    def advance(self, seconds):
        self.now += seconds


@pytest.fixture
def clock():
    return Clock()


@pytest.fixture
def sched(clock):
    return Scheduler(clock=clock, heartbeat_timeout=10, default_task_timeout=30, default_max_attempts=3)


def finish_all(sched, worker, job):
    for item in sched.assign(worker.id):
        sched.complete(worker.id, item["job"], item["index"], item["attempt"], item["payload"]["stop"])


def test_submit_creates_pending_job(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 4})
    assert job.status == PENDING
    assert len(job.tasks) == 4
    assert sched.get_job(job.id) is job
    assert sched.stats()["queued_tasks"] == 4


def test_full_lifecycle(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 4})
    worker = sched.register_worker("a", 8)
    assignments = sched.assign(worker.id)
    assert len(assignments) == 4
    assert job.status == RUNNING
    for item in assignments:
        payload = item["payload"]
        value = sum(i * i for i in range(payload["start"], payload["stop"]))
        assert sched.complete(worker.id, item["job"], item["index"], item["attempt"], value)
    assert job.status == DONE
    assert job.result == sum(i * i for i in range(100))
    assert worker.completed == 4
    assert worker.free == 8
    assert sched.stats()["tasks_completed"] == 4


def test_assign_respects_slots_and_fifo(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 5})
    worker = sched.register_worker("a", 2)
    first = sched.assign(worker.id)
    assert [item["index"] for item in first] == [0, 1]
    assert sched.assign(worker.id) == []
    sched.complete(worker.id, job.id, 0, 1, 0)
    second = sched.assign(worker.id)
    assert [item["index"] for item in second] == [2]


def test_work_is_shared_between_workers(sched):
    sched.submit("sum_squares", {"stop": 100, "parts": 4})
    a = sched.register_worker("a", 2)
    b = sched.register_worker("b", 2)
    assert len(sched.assign(a.id)) == 2
    assert len(sched.assign(b.id)) == 2


def test_lost_worker_requeues_tasks_with_priority(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 4})
    a = sched.register_worker("a", 2)
    b = sched.register_worker("b", 2)
    sched.assign(a.id)
    assert sched.remove_worker(a.id) == 2
    retried = sched.assign(b.id)
    assert sorted(item["index"] for item in retried) == [0, 1]
    assert all(item["attempt"] == 2 for item in retried)
    assert sched.stats()["tasks_retried"] == 2
    assert job.status == RUNNING


def test_remove_unknown_worker_is_noop(sched):
    assert sched.remove_worker("ghost") == 0


def test_stale_result_after_requeue_is_ignored(sched):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 1})
    a = sched.register_worker("a", 1)
    b = sched.register_worker("b", 1)
    first = sched.assign(a.id)[0]
    sched.remove_worker(a.id)
    second = sched.assign(b.id)[0]
    assert not sched.complete(a.id, job.id, 0, first["attempt"], 1)
    assert sched.complete(b.id, job.id, 0, second["attempt"], 285)
    assert job.result == 285


def test_duplicate_result_is_ignored(sched):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 2})
    worker = sched.register_worker("a", 2)
    items = sched.assign(worker.id)
    assert sched.complete(worker.id, job.id, 0, items[0]["attempt"], 1)
    assert not sched.complete(worker.id, job.id, 0, items[0]["attempt"], 1)
    assert job.done == 1


def test_wrong_worker_cannot_complete(sched):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 1})
    a = sched.register_worker("a", 1)
    b = sched.register_worker("b", 1)
    item = sched.assign(a.id)[0]
    assert not sched.complete(b.id, job.id, 0, item["attempt"], 1)
    assert not sched.complete(a.id, job.id, 0, item["attempt"] + 1, 1)
    assert not sched.complete(a.id, "nope", 0, 1, 1)


def test_task_error_retries_then_fails_job(sched):
    job = sched.submit("fail", {"message": "bad"})
    worker = sched.register_worker("a", 1)
    for attempt in (1, 2, 3):
        item = sched.assign(worker.id)[0]
        assert item["attempt"] == attempt
        assert sched.fail_task(worker.id, job.id, 0, attempt, "RuntimeError: bad")
    assert job.status == FAILED
    assert "after 3 attempts" in job.error
    assert "RuntimeError: bad" in job.error
    assert sched.assign(worker.id) == []
    assert worker.failed == 3
    assert worker.free == 1


def test_max_attempts_is_configurable(sched):
    job = sched.submit("fail", {}, max_attempts=1)
    worker = sched.register_worker("a", 1)
    item = sched.assign(worker.id)[0]
    sched.fail_task(worker.id, job.id, 0, item["attempt"], "x")
    assert job.status == FAILED


def test_task_timeout_requeues_and_keeps_slot_busy(sched, clock):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 1}, task_timeout=5)
    worker = sched.register_worker("a", 1)
    first = sched.assign(worker.id)[0]
    clock.advance(4)
    sched.heartbeat(worker.id)
    assert sched.reap().timed_out == 0
    clock.advance(2)
    sched.heartbeat(worker.id)
    assert sched.reap().timed_out == 1
    assert worker.free == 0
    assert sched.assign(worker.id) == []
    assert not sched.complete(worker.id, job.id, 0, first["attempt"], 1)
    assert worker.free == 1
    second = sched.assign(worker.id)[0]
    assert second["attempt"] == 2
    assert sched.complete(worker.id, job.id, 0, 2, 285)
    assert job.status == DONE


def test_repeated_timeouts_fail_the_job(sched, clock):
    job = sched.submit("sleep", {"seconds": 1}, task_timeout=1, max_attempts=2)
    worker = sched.register_worker("a", 4)
    for _ in range(2):
        sched.assign(worker.id)
        clock.advance(2)
        sched.heartbeat(worker.id)
        sched.reap()
    assert job.status == FAILED
    assert "timed out" in job.error


def test_silent_worker_is_reaped(sched, clock):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 2})
    silent = sched.register_worker("silent", 2)
    alive = sched.register_worker("alive", 2)
    sched.assign(silent.id)
    clock.advance(11)
    sched.heartbeat(alive.id)
    reaped = sched.reap()
    assert reaped.workers == [silent.id]
    assert silent.id not in sched.workers
    assert len(sched.assign(alive.id)) == 2
    assert job.status == RUNNING


def test_heartbeat_keeps_worker_alive(sched, clock):
    worker = sched.register_worker("a", 1)
    for _ in range(5):
        clock.advance(8)
        assert sched.heartbeat(worker.id)
        assert sched.reap().workers == []
    assert not sched.heartbeat("ghost")


def test_cancel(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 4})
    worker = sched.register_worker("a", 2)
    items = sched.assign(worker.id)
    assert sched.cancel(job.id)
    assert job.status == CANCELLED
    assert not sched.cancel(job.id)
    assert sched.assign(worker.id) == []
    assert not sched.complete(worker.id, job.id, 0, items[0]["attempt"], 1)
    assert worker.free == 1
    assert not sched.fail_task(worker.id, job.id, 1, items[1]["attempt"], "late")
    assert worker.free == 2
    assert sched.stats()["queued_tasks"] == 0


def test_cancel_unknown_job(sched):
    with pytest.raises(UnknownJob):
        sched.cancel("nope")


def test_worker_kinds_filter(sched):
    sched.submit("count_primes", {"stop": 100, "parts": 2})
    sched.submit("sum_squares", {"stop": 100, "parts": 2})
    picky = sched.register_worker("picky", 4, kinds=["sum_squares"])
    items = sched.assign(picky.id)
    assert {item["kind"] for item in items} == {"sum_squares"}
    assert sched.stats()["queued_tasks"] == 2
    generalist = sched.register_worker("any", 4)
    assert {item["kind"] for item in sched.assign(generalist.id)} == {"count_primes"}


def test_skipped_tasks_keep_their_order(sched):
    sched.submit("count_primes", {"stop": 100, "parts": 3})
    picky = sched.register_worker("picky", 4, kinds=[])
    assert sched.assign(picky.id) == []
    generalist = sched.register_worker("any", 4)
    assert [item["index"] for item in sched.assign(generalist.id)] == [0, 1, 2]


@pytest.mark.parametrize(
    "kwargs",
    [
        {"params": []},
        {"params": {"stop": 10}, "task_timeout": 0},
        {"params": {"stop": 10}, "task_timeout": "5"},
        {"params": {"stop": 10}, "task_timeout": 10**9},
        {"params": {"stop": 10}, "max_attempts": 0},
        {"params": {"stop": 10}, "max_attempts": 99},
        {"params": {"stop": 10}, "max_attempts": True},
        {"params": {}},
        {"params": {"stop": "x"}},
    ],
)
def test_submit_validation(sched, kwargs):
    with pytest.raises(SchedulerError):
        sched.submit("sum_squares", **kwargs)


def test_submit_unknown_kind(sched):
    with pytest.raises(UnknownTask):
        sched.submit("nope", {})


def test_submit_rejects_too_many_tasks(sched, monkeypatch):
    monkeypatch.setattr(config, "MAX_TASKS_PER_JOB", 5)
    with pytest.raises(SchedulerError):
        sched.submit("sum_squares", {"stop": 100, "parts": 6})
    assert sched.submit("sum_squares", {"stop": 100, "parts": 5})


def test_finished_jobs_are_evicted(clock):
    sched = Scheduler(clock=clock, max_finished=2)
    worker = sched.register_worker("a", 1)
    ids = []
    for _ in range(4):
        job = sched.submit("echo", {"value": 1})
        ids.append(job.id)
        item = sched.assign(worker.id)[0]
        sched.complete(worker.id, job.id, 0, item["attempt"], 1)
    assert list(sched.jobs) == ids[-2:]
    with pytest.raises(UnknownJob):
        sched.get_job(ids[0])


def test_running_jobs_are_never_evicted(clock):
    sched = Scheduler(clock=clock, max_finished=0)
    running = sched.submit("sum_squares", {"stop": 10})
    done = sched.submit("echo", {"value": 1})
    worker = sched.register_worker("a", 1)
    sched.cancel(done.id)
    assert running.id in sched.jobs
    assert done.id not in sched.jobs
    assert worker.free == 1


def test_reduce_failure_fails_job(sched):
    job = sched.submit("sum_squares", {"stop": 10, "parts": 1})
    worker = sched.register_worker("a", 1)
    item = sched.assign(worker.id)[0]
    sched.complete(worker.id, job.id, 0, item["attempt"], "not a number")
    assert job.status == FAILED
    assert "reduce failed" in job.error


def test_views_and_stats(sched):
    job = sched.submit("sum_squares", {"stop": 100, "parts": 4})
    worker = sched.register_worker("a", 2)
    sched.assign(worker.id)
    view = sched.view(job, detail=True)
    assert view["total"] == 4
    assert view["running"] == 2
    assert view["queued"] == 2
    assert view["status"] == RUNNING
    assert "result" not in view
    assert "result" in sched.view(job, include_result=True)
    stats = sched.stats()
    assert stats["workers"] == 1
    assert stats["slots"] == 2
    assert stats["busy"] == 2
    assert stats["queued_tasks"] == 2
    assert stats["jobs"]["running"] == 1
    listed = sched.worker_views()
    assert listed[0]["name"] == "a"
    assert listed[0]["busy"] == 2


def test_list_jobs_newest_first(sched):
    first = sched.submit("echo", {"value": 1})
    second = sched.submit("echo", {"value": 2})
    third = sched.submit("echo", {"value": 3})
    assert [job.id for job in sched.list_jobs(2)] == [third.id, second.id]
    assert [job.id for job in sched.list_jobs()] == [third.id, second.id, first.id]
