import asyncio
import contextlib
import functools
import threading

from nodemesh import Client, Coordinator, Worker

SECRET = "test-secret-value"


def async_test(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        return asyncio.run(asyncio.wait_for(func(*args, **kwargs), 60))

    return wrapper


@contextlib.asynccontextmanager
async def cluster(workers=2, slots=2, secret=SECRET, **coordinator_options):
    coordinator = Coordinator(port=0, secret=secret, **coordinator_options)
    await coordinator.start()
    nodes = [
        Worker(
            port=coordinator.port,
            secret=secret,
            name=f"w{index}",
            slots=slots,
            executor="thread",
        )
        for index in range(workers)
    ]
    runners = [asyncio.create_task(node.run()) for node in nodes]
    try:
        await asyncio.gather(*(node.wait_ready(10) for node in nodes))
        client = Client(port=coordinator.port, secret=secret)
        yield coordinator, nodes, runners, client
    finally:
        for node in nodes:
            await node.stop()
        for runner in runners:
            runner.cancel()
        await asyncio.gather(*runners, return_exceptions=True)
        await coordinator.stop()


async def eventually(predicate, timeout=10.0, interval=0.05):
    deadline = asyncio.get_running_loop().time() + timeout
    while True:
        value = predicate()
        if asyncio.iscoroutine(value):
            value = await value
        if value:
            return value
        if asyncio.get_running_loop().time() > deadline:
            raise AssertionError("condition was not met in time")
        await asyncio.sleep(interval)


class BackgroundCluster:
    def __init__(self, workers=1, slots=2, secret=SECRET):
        self.secret = secret
        self.worker_count = workers
        self.slots = slots
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self.loop.run_forever, daemon=True)
        self.coordinator = None
        self.nodes = []
        self.runners = []

    def call(self, coro, timeout=30):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)

    async def _start(self):
        self.coordinator = Coordinator(port=0, secret=self.secret)
        await self.coordinator.start()
        for index in range(self.worker_count):
            node = Worker(
                port=self.coordinator.port,
                secret=self.secret,
                name=f"bg{index}",
                slots=self.slots,
                executor="thread",
            )
            self.nodes.append(node)
            self.runners.append(asyncio.create_task(node.run()))
        await asyncio.gather(*(node.wait_ready(10) for node in self.nodes))

    async def _stop(self):
        for node in self.nodes:
            await node.stop()
        for runner in self.runners:
            runner.cancel()
        await asyncio.gather(*self.runners, return_exceptions=True)
        await self.coordinator.stop()

    @property
    def port(self):
        return self.coordinator.port

    def __enter__(self):
        self.thread.start()
        self.call(self._start())
        return self

    def __exit__(self, *exc):
        self.call(self._stop())
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join(5)
