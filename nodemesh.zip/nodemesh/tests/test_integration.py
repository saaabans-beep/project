import asyncio
import socket
import subprocess

import pytest
from support import SECRET, async_test, cluster, eventually

from nodemesh import (
    AuthError,
    Client,
    Coordinator,
    JobError,
    JobTimeout,
    RequestError,
    SyncClient,
    Worker,
    config,
    tasks,
)
from nodemesh.protocol import Connection, ConnectionClosed
from nodemesh.security import client_authenticate, client_ssl_context, server_ssl_context


@async_test
async def test_run_distributed_job():
    async with cluster() as (coordinator, nodes, runners, client):
        assert await client.run("sum_squares", {"stop": 10_000, "parts": 12}) == sum(
            i * i for i in range(10_000)
        )
        assert await client.run("count_primes", {"stop": 100_000, "parts": 9}) == 9592


@async_test
async def test_tasks_are_spread_over_all_workers():
    async with cluster(workers=3, slots=2) as (coordinator, nodes, runners, client):
        result = await client.run("sleep", {"seconds": 0.1, "parts": 18}, timeout=30)
        assert result["tasks"] == 18
        counts = {item["name"]: item["completed"] for item in await client.workers()}
        assert sum(counts.values()) == 18
        assert all(count > 0 for count in counts.values()), counts


@async_test
async def test_parallel_speedup():
    async with cluster(workers=2, slots=4) as (coordinator, nodes, runners, client):
        loop = asyncio.get_running_loop()
        started = loop.time()
        await client.run("sleep", {"seconds": 0.3, "parts": 8}, timeout=30)
        assert loop.time() - started < 1.5


@async_test
async def test_concurrent_jobs():
    async with cluster() as (coordinator, nodes, runners, client):
        jobs = await asyncio.gather(
            *(client.run("sum_squares", {"stop": 1000 + n, "parts": 5}) for n in range(6))
        )
        assert jobs == [sum(i * i for i in range(1000 + n)) for n in range(6)]
        stats = await client.stats()
        assert stats["jobs"]["done"] == 6


@async_test
async def test_job_status_and_result_api():
    async with cluster() as (coordinator, nodes, runners, client):
        job_id = await client.submit("sleep", {"seconds": 0.3, "parts": 2})
        status = await client.status(job_id)
        assert status["kind"] == "sleep"
        assert status["total"] == 2
        with pytest.raises(RequestError, match="not finished"):
            await client.result(job_id)
        final = await client.wait(job_id, timeout=10)
        assert final["status"] == "done"
        assert final["done"] == 2
        assert await client.result(job_id) == {"tasks": 2, "slept": 0.6}
        listed = await client.jobs()
        assert listed[0]["id"] == job_id


@async_test
async def test_failing_task_fails_job_after_retries():
    async with cluster() as (coordinator, nodes, runners, client):
        with pytest.raises(JobError) as caught:
            await client.run("fail", {"message": "kaput"}, max_attempts=2, timeout=20)
        assert "after 2 attempts" in str(caught.value)
        assert "kaput" in str(caught.value)
        assert caught.value.job["status"] == "failed"
        stats = await client.stats()
        assert stats["jobs"]["failed"] == 1
        assert stats["busy"] == 0


@async_test
async def test_cancel_running_job():
    async with cluster(workers=1, slots=1) as (coordinator, nodes, runners, client):
        job_id = await client.submit("sleep", {"seconds": 0.5, "parts": 20})
        await asyncio.sleep(0.2)
        assert await client.cancel(job_id) is True
        assert await client.cancel(job_id) is False
        final = await client.wait(job_id, timeout=5)
        assert final["status"] == "cancelled"
        with pytest.raises(JobError):
            await client.result(job_id)
        await eventually(lambda: coordinator.scheduler.stats()["busy"] == 0, timeout=10)


@async_test
async def test_wait_timeout_cancels_job_in_run():
    async with cluster(workers=1, slots=1) as (coordinator, nodes, runners, client):
        with pytest.raises(JobTimeout):
            await client.run("sleep", {"seconds": 2, "parts": 3}, timeout=0.4)
        jobs = await client.jobs()
        assert jobs[0]["status"] == "cancelled"


@async_test
async def test_worker_crash_is_survived():
    async with cluster(workers=2, slots=2) as (coordinator, nodes, runners, client):
        job_id = await client.submit("sleep", {"seconds": 0.4, "parts": 8})
        await eventually(
            lambda: coordinator.scheduler.workers and any(
                w.running for w in coordinator.scheduler.workers.values()
            )
        )
        runners[0].cancel()
        final = await client.wait(job_id, timeout=30)
        assert final["status"] == "done"
        assert final["done"] == 8
        stats = await client.stats()
        assert stats["tasks_retried"] >= 1
        assert stats["workers"] == 1


@async_test
async def test_silent_worker_is_evicted_and_work_moves_on():
    async with cluster(workers=0, heartbeat_timeout=0.5, reap_interval=0.1) as (
        coordinator,
        nodes,
        runners,
        client,
    ):
        reader, writer = await asyncio.open_connection("127.0.0.1", coordinator.port)
        ghost = Connection(reader, writer)
        await client_authenticate(
            ghost, SECRET, "worker", "ghost", {"slots": 1, "kinds": tasks.registered()}
        )
        job_id = await client.submit("echo", {"value": "hello"})
        assigned = await asyncio.wait_for(ghost.recv(), 5)
        assert assigned["type"] == "run"
        with pytest.raises(ConnectionClosed):
            await asyncio.wait_for(ghost.recv(), 5)
        await ghost.close()
        assert (await client.stats())["workers"] == 0

        real = Worker(port=coordinator.port, secret=SECRET, name="real", slots=1, executor="thread")
        runner = asyncio.create_task(real.run())
        try:
            final = await client.wait(job_id, timeout=15)
            assert final["status"] == "done"
            assert final["result"] == "hello"
            assert final["retries"] == 1
        finally:
            await real.stop()
            runner.cancel()
            await asyncio.gather(runner, return_exceptions=True)


@async_test
async def test_job_waits_until_a_worker_joins():
    async with cluster(workers=0) as (coordinator, nodes, runners, client):
        job_id = await client.submit("sum_squares", {"stop": 100, "parts": 3})
        assert (await client.status(job_id))["status"] == "pending"
        worker = Worker(port=coordinator.port, secret=SECRET, slots=2, executor="thread")
        runner = asyncio.create_task(worker.run())
        try:
            final = await client.wait(job_id, timeout=15)
            assert final["result"] == sum(i * i for i in range(100))
        finally:
            await worker.stop()
            runner.cancel()
            await asyncio.gather(runner, return_exceptions=True)


@async_test
async def test_wrong_secret_is_rejected():
    async with cluster() as (coordinator, nodes, runners, client):
        intruder = Client(port=coordinator.port, secret="completely-wrong-secret")
        with pytest.raises(AuthError):
            await intruder.stats()
        worker = Worker(
            port=coordinator.port, secret="completely-wrong-secret", executor="thread", reconnect=False
        )
        with pytest.raises(AuthError):
            await asyncio.wait_for(worker.run(), 10)
        assert (await client.stats())["workers"] == 2


@async_test
async def test_request_errors():
    async with cluster() as (coordinator, nodes, runners, client):
        with pytest.raises(RequestError, match="unknown task kind"):
            await client.submit("nope")
        with pytest.raises(RequestError, match="invalid job parameters"):
            await client.submit("sum_squares", {"stop": "abc"})
        with pytest.raises(RequestError, match="unknown job"):
            await client.status("missing")
        with pytest.raises(RequestError, match="unknown job"):
            await client.cancel("missing")
        with pytest.raises(RequestError, match="task_timeout"):
            await client.submit("echo", {"value": 1}, task_timeout=-5)
        kinds = await client.kinds()
        assert "count_primes" in kinds


@async_test
async def test_unknown_operation_and_bad_request():
    async with cluster() as (coordinator, nodes, runners, client):
        reader, writer = await asyncio.open_connection("127.0.0.1", coordinator.port)
        conn = Connection(reader, writer)
        await client_authenticate(conn, SECRET, "client", "raw")
        await conn.send({"type": "request", "op": "explode", "id": 7})
        reply = await conn.recv()
        assert reply["ok"] is False
        assert reply["id"] == 7
        await conn.send({"type": "request", "op": "status"})
        assert "missing field" in (await conn.recv())["error"]
        await conn.send({"type": "request", "op": "stats", "id": 8})
        assert (await conn.recv())["ok"] is True
        await conn.close()


@async_test
async def test_worker_reconnects_after_coordinator_restart(monkeypatch):
    monkeypatch.setattr(config, "RECONNECT_MIN", 0.1)
    monkeypatch.setattr(config, "RECONNECT_MAX", 0.2)
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()

    first = Coordinator(port=port, secret=SECRET)
    await first.start()
    worker = Worker(port=port, secret=SECRET, name="persistent", slots=2, executor="thread")
    runner = asyncio.create_task(worker.run())
    try:
        await worker.wait_ready(10)
        await first.stop()
        await eventually(lambda: not worker.connected)
        second = Coordinator(port=port, secret=SECRET)
        await second.start()
        try:
            await worker.wait_ready(15)
            client = Client(port=port, secret=SECRET)
            assert await client.run("sum_squares", {"stop": 50, "parts": 2}, timeout=15) == sum(
                i * i for i in range(50)
            )
        finally:
            await worker.stop()
            await second.stop()
    finally:
        runner.cancel()
        await asyncio.gather(runner, return_exceptions=True)


@async_test
async def test_process_executor():
    coordinator = Coordinator(port=0, secret=SECRET)
    await coordinator.start()
    worker = Worker(port=coordinator.port, secret=SECRET, slots=2, executor="process")
    runner = asyncio.create_task(worker.run())
    try:
        await worker.wait_ready(10)
        client = Client(port=coordinator.port, secret=SECRET)
        assert await client.run("count_primes", {"stop": 300_000, "parts": 4}, timeout=60) == 25997
        with pytest.raises(JobError, match="RuntimeError: nope"):
            await client.run("fail", {"message": "nope"}, max_attempts=1, timeout=30)
    finally:
        await worker.stop()
        runner.cancel()
        await asyncio.gather(runner, return_exceptions=True)
        await coordinator.stop()


@async_test
async def test_plugin_task_runs_on_worker(tmp_path, monkeypatch):
    module = tmp_path / "nm_plugin_cluster.py"
    module.write_text(
        "from nodemesh.tasks import task, split_range\n"
        "def split(params):\n"
        "    return [{'n': n} for n in range(params['count'])]\n"
        "@task('plugin_cube', split=split, reduce=lambda results, params: sum(results))\n"
        "def cube(payload):\n"
        "    return payload['n'] ** 3\n"
    )
    monkeypatch.syspath_prepend(str(tmp_path))
    try:
        coordinator = Coordinator(port=0, secret=SECRET, plugins=["nm_plugin_cluster"])
        await coordinator.start()
        worker = Worker(
            port=coordinator.port,
            secret=SECRET,
            slots=2,
            executor="thread",
            plugins=["nm_plugin_cluster"],
        )
        runner = asyncio.create_task(worker.run())
        try:
            await worker.wait_ready(10)
            client = Client(port=coordinator.port, secret=SECRET)
            assert await client.run("plugin_cube", {"count": 10}, timeout=15) == sum(
                n**3 for n in range(10)
            )
        finally:
            await worker.stop()
            runner.cancel()
            await asyncio.gather(runner, return_exceptions=True)
            await coordinator.stop()
    finally:
        tasks._REGISTRY.pop("plugin_cube", None)


@async_test
async def test_task_without_capable_worker_stays_queued():
    name = "only_on_coordinator"
    tasks.task(name)(lambda payload: 1)
    coordinator = Coordinator(port=0, secret=SECRET)
    await coordinator.start()
    worker = Worker(
        port=coordinator.port, secret=SECRET, slots=2, executor="thread", kinds=["echo"]
    )
    runner = asyncio.create_task(worker.run())
    try:
        await worker.wait_ready(10)
        client = Client(port=coordinator.port, secret=SECRET)
        stuck = await client.submit(name, {})
        assert await client.run("echo", {"value": "ok"}, timeout=10) == "ok"
        assert (await client.status(stuck))["status"] == "pending"
        assert (await client.workers())[0]["kinds"] == ["echo"]
        assert await client.cancel(stuck) is True
    finally:
        await worker.stop()
        runner.cancel()
        await asyncio.gather(runner, return_exceptions=True)
        await coordinator.stop()
        tasks._REGISTRY.pop(name, None)


def test_sync_client():
    from support import BackgroundCluster

    with BackgroundCluster() as background:
        client = SyncClient(port=background.port, secret=SECRET)
        assert client.run("sum_squares", {"stop": 100, "parts": 3}) == sum(i * i for i in range(100))
        job_id = client.submit("echo", {"value": [1, 2]})
        assert client.wait(job_id, 10)["result"] == [1, 2]
        assert client.result(job_id) == [1, 2]
        assert client.status(job_id)["status"] == "done"
        assert client.jobs()[0]["id"] == job_id
        assert client.stats()["workers"] == 1
        assert client.workers()[0]["name"] == "bg0"
        assert "echo" in client.kinds()
        assert client.cancel(job_id) is False


def test_coordinator_requires_strong_secret():
    for secret in (None, "", "short"):
        with pytest.raises(ValueError):
            Coordinator(secret=secret)
    with pytest.raises(ValueError):
        Worker(secret="")
    with pytest.raises(ValueError):
        Client(secret="")
    with pytest.raises(ValueError):
        Worker(secret=SECRET, executor="gpu")


@pytest.fixture
def certificate(tmp_path):
    cert = tmp_path / "cert.pem"
    key = tmp_path / "key.pem"
    try:
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(key), "-out", str(cert), "-days", "1",
                "-subj", "/CN=localhost",
                "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
            ],
            check=True,
            capture_output=True,
        )
    except (OSError, subprocess.CalledProcessError):
        pytest.skip("openssl is not available")
    return str(cert), str(key)


@async_test
async def test_tls_cluster(certificate):
    cert, key = certificate
    coordinator = Coordinator(port=0, secret=SECRET, ssl_context=server_ssl_context(cert, key))
    await coordinator.start()
    context = client_ssl_context(cert)
    worker = Worker(
        port=coordinator.port, secret=SECRET, slots=2, executor="thread", ssl_context=context
    )
    runner = asyncio.create_task(worker.run())
    try:
        await worker.wait_ready(10)
        client = Client(port=coordinator.port, secret=SECRET, ssl_context=context)
        assert await client.run("sum_squares", {"stop": 500, "parts": 4}, timeout=15) == sum(
            i * i for i in range(500)
        )
    finally:
        await worker.stop()
        runner.cancel()
        await asyncio.gather(runner, return_exceptions=True)
        await coordinator.stop()


@async_test
async def test_tls_rejects_untrusted_certificate(certificate):
    cert, key = certificate
    coordinator = Coordinator(port=0, secret=SECRET, ssl_context=server_ssl_context(cert, key))
    await coordinator.start()
    try:
        client = Client(port=coordinator.port, secret=SECRET, ssl_context=client_ssl_context())
        with pytest.raises(OSError):
            await client.stats()
    finally:
        await coordinator.stop()
