import asyncio
import json
import struct

import pytest
from support import async_test

from nodemesh import config
from nodemesh.protocol import (
    AuthError,
    Connection,
    ConnectionClosed,
    ProtocolError,
    decode,
    encode,
)
from nodemesh.security import client_authenticate, server_authenticate

SECRET = "shared-secret-123"


class Pair:
    def __init__(self, handler):
        self.handler = handler
        self.server = None
        self.port = None

    async def __aenter__(self):
        self.server = await asyncio.start_server(self._serve, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]
        return self

    async def _serve(self, reader, writer):
        conn = Connection(reader, writer)
        try:
            await self.handler(conn)
        except ProtocolError:
            pass
        finally:
            await conn.close()

    async def connect(self):
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        return Connection(reader, writer)

    async def __aexit__(self, *exc):
        self.server.close()
        await self.server.wait_closed()


def test_encode_decode_roundtrip():
    message = {"a": 1, "b": [1, 2, 3], "c": "привет"}
    frame = encode(message)
    (length,) = struct.unpack(">I", frame[:4])
    assert length == len(frame) - 4
    assert decode(frame[4:]) == message


def test_decode_rejects_garbage():
    with pytest.raises(ProtocolError):
        decode(b"not json")
    with pytest.raises(ProtocolError):
        decode(b"[1, 2]")


def test_encode_rejects_oversized(monkeypatch):
    monkeypatch.setattr(config, "MAX_FRAME", 10)
    with pytest.raises(ProtocolError):
        encode({"data": "x" * 100})


@async_test
async def test_connection_roundtrip_and_close():
    async def echo(conn):
        while True:
            await conn.send(await conn.recv())

    async with Pair(echo) as pair:
        conn = await pair.connect()
        await conn.send({"n": 1})
        assert await conn.recv() == {"n": 1}
        await conn.send({"text": "ж" * 1000})
        assert (await conn.recv())["text"] == "ж" * 1000
        await conn.close()


@async_test
async def test_recv_detects_closed_peer():
    async def hang_up(conn):
        return

    async with Pair(hang_up) as pair:
        conn = await pair.connect()
        with pytest.raises(ConnectionClosed):
            await conn.recv()
        await conn.close()


@async_test
async def test_recv_rejects_oversized_frame():
    async def flood(conn):
        conn.writer.write(struct.pack(">I", 5000) + b"x" * 5000)
        await conn.writer.drain()
        await asyncio.sleep(0.2)

    async with Pair(flood) as pair:
        conn = await pair.connect()
        with pytest.raises(ProtocolError, match="too large"):
            await conn.recv(max_size=1000)
        await conn.close()


@async_test
async def test_recv_rejects_truncated_frame():
    async def truncate(conn):
        conn.writer.write(struct.pack(">I", 100) + b"abc")
        await conn.writer.drain()

    async with Pair(truncate) as pair:
        conn = await pair.connect()
        with pytest.raises(ConnectionClosed):
            await conn.recv()
        await conn.close()


async def authenticated_server(conn, results, secret=SECRET):
    try:
        auth, proof = await server_authenticate(conn, secret)
    except ProtocolError as exc:
        results.append(exc)
        raise
    results.append(auth)
    await conn.send({"type": "welcome", "proof": proof})
    await asyncio.sleep(0.2)


@async_test
async def test_handshake_success():
    results = []

    async def handler(conn):
        await authenticated_server(conn, results)

    async with Pair(handler) as pair:
        conn = await pair.connect()
        reply = await client_authenticate(conn, SECRET, "worker", "node-1", {"slots": 4})
        assert reply["type"] == "welcome"
        await conn.close()
    assert results[0]["role"] == "worker"
    assert results[0]["name"] == "node-1"
    assert results[0]["slots"] == 4


@async_test
async def test_handshake_wrong_secret_rejected_on_both_sides():
    results = []

    async def handler(conn):
        await authenticated_server(conn, results)

    async with Pair(handler) as pair:
        conn = await pair.connect()
        with pytest.raises(AuthError):
            await client_authenticate(conn, "some-other-secret", "client", "c")
        await conn.close()
    assert isinstance(results[0], AuthError)


@async_test
async def test_client_rejects_server_without_secret():
    async def impostor(conn):
        await conn.send({"type": "hello", "version": config.PROTOCOL_VERSION, "challenge": "abc"})
        await conn.recv()
        await conn.send({"type": "welcome", "proof": "0" * 64})
        await asyncio.sleep(0.2)

    async with Pair(impostor) as pair:
        conn = await pair.connect()
        with pytest.raises(AuthError, match="prove"):
            await client_authenticate(conn, SECRET, "client", "c")
        await conn.close()


@async_test
async def test_client_rejects_incompatible_version():
    async def old_server(conn):
        await conn.send({"type": "hello", "version": 999, "challenge": "abc"})
        await asyncio.sleep(0.2)

    async with Pair(old_server) as pair:
        conn = await pair.connect()
        with pytest.raises(ProtocolError, match="incompatible"):
            await client_authenticate(conn, SECRET, "client", "c")
        await conn.close()


@pytest.mark.parametrize(
    "message",
    [
        {"type": "auth"},
        {"type": "auth", "role": "admin", "name": "n", "cnonce": "c", "response": "r"},
        {"type": "auth", "role": "worker", "name": "", "cnonce": "c", "response": "r"},
        {"type": "auth", "role": "worker", "name": "n" * 65, "cnonce": "c", "response": "r"},
        {"type": "auth", "role": "worker", "name": 5, "cnonce": "c", "response": "r"},
        {"type": "nope"},
    ],
)
@async_test
async def test_server_rejects_malformed_auth(message):
    results = []

    async def handler(conn):
        await authenticated_server(conn, results)

    async with Pair(handler) as pair:
        conn = await pair.connect()
        await conn.recv()
        await conn.send(message)
        with pytest.raises(ConnectionClosed):
            await conn.recv()
        await conn.close()
    assert isinstance(results[0], AuthError)


@async_test
async def test_server_times_out_silent_client():
    results = []

    async def handler(conn):
        try:
            await server_authenticate(conn, SECRET, timeout=0.2)
        except asyncio.TimeoutError as exc:
            results.append(exc)

    async with Pair(handler) as pair:
        conn = await pair.connect()
        await conn.recv()
        with pytest.raises(ConnectionClosed):
            await conn.recv()
        await conn.close()
    assert len(results) == 1


@async_test
async def test_handshake_frame_limit():
    results = []

    async def handler(conn):
        try:
            await server_authenticate(conn, SECRET)
        except ProtocolError as exc:
            results.append(exc)

    async with Pair(handler) as pair:
        conn = await pair.connect()
        await conn.recv()
        conn.writer.write(struct.pack(">I", 1_000_000) + b"{" )
        await conn.writer.drain()
        with pytest.raises(ConnectionClosed):
            await conn.recv()
        await conn.close()
    assert "too large" in str(results[0])


def test_message_is_valid_json_on_the_wire():
    frame = encode({"type": "x", "v": [1, {"k": None}]})
    assert json.loads(frame[4:]) == {"type": "x", "v": [1, {"k": None}]}
