import asyncio
import logging
import multiprocessing
import os
import socket
from concurrent.futures import BrokenExecutor, ProcessPoolExecutor, ThreadPoolExecutor

from . import config, tasks
from .protocol import Connection, ConnectionClosed, ProtocolError
from .security import MAX_NAME, AuthError, client_authenticate, connect_kwargs

log = logging.getLogger("nodemesh.worker")

EXECUTORS = ("process", "thread")


class Worker:
    def __init__(
        self,
        host=config.DEFAULT_HOST,
        port=config.DEFAULT_PORT,
        secret=None,
        name=None,
        slots=None,
        executor="process",
        plugins=(),
        ssl_context=None,
        tls_hostname=None,
        reconnect=True,
        kinds=None,
    ):
        if not secret:
            raise ValueError("secret is required")
        if executor not in EXECUTORS:
            raise ValueError(f"executor must be one of {', '.join(EXECUTORS)}")
        self.host = host
        self.port = port
        self.secret = secret
        self.name = (name or f"{socket.gethostname()}-{os.getpid()}")[:MAX_NAME]
        self.slots = max(1, int(slots or os.cpu_count() or 1))
        self.executor = executor
        self.plugins = tuple(plugins)
        self.ssl_context = ssl_context
        self.tls_hostname = tls_hostname
        self.reconnect = reconnect
        self.kinds = None if kinds is None else tuple(kinds)
        self.worker_id = None
        self.completed = 0
        self.failed = 0
        self._ready = asyncio.Event()
        self._stopping = False
        self._conn = None
        self._pool = None

    @property
    def connected(self):
        return self._ready.is_set()

    async def wait_ready(self, timeout=None):
        await asyncio.wait_for(self._ready.wait(), timeout)

    def _make_pool(self):
        if self.executor == "thread":
            return ThreadPoolExecutor(max_workers=self.slots, thread_name_prefix="nodemesh")
        return ProcessPoolExecutor(
            max_workers=self.slots,
            mp_context=multiprocessing.get_context("spawn"),
            initializer=tasks.init_process,
            initargs=(self.plugins,),
        )

    async def run(self):
        tasks.load_plugins(self.plugins)
        self._pool = self._make_pool()
        delay = config.RECONNECT_MIN
        try:
            while not self._stopping:
                try:
                    if await self._session():
                        delay = config.RECONNECT_MIN
                except AuthError:
                    raise
                except (ProtocolError, OSError, asyncio.TimeoutError) as exc:
                    log.warning("connection to %s:%s failed: %s", self.host, self.port, exc)
                if self._stopping or not self.reconnect:
                    break
                log.info("reconnecting in %.1fs", delay)
                await asyncio.sleep(delay)
                delay = min(delay * 2, config.RECONNECT_MAX)
        finally:
            pool, self._pool = self._pool, None
            if pool is not None:
                pool.shutdown(wait=False, cancel_futures=True)

    async def stop(self):
        self._stopping = True
        conn = self._conn
        if conn is not None:
            try:
                await conn.send({"type": "bye"})
            except ProtocolError:
                pass
            await conn.close()

    async def _session(self):
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(
                self.host,
                self.port,
                **connect_kwargs(self.ssl_context, self.tls_hostname or self.host),
            ),
            config.CONNECT_TIMEOUT,
        )
        conn = Connection(reader, writer)
        self._conn = conn
        running = set()
        heartbeat = None
        connected = False
        try:
            kinds = sorted(self.kinds if self.kinds is not None else tasks.registered())
            reply = await client_authenticate(
                conn,
                self.secret,
                "worker",
                self.name,
                {"slots": self.slots, "kinds": kinds},
            )
            connected = True
            self.worker_id = reply.get("worker_id")
            interval = reply.get("heartbeat_interval")
            if isinstance(interval, bool) or not isinstance(interval, (int, float)):
                interval = config.HEARTBEAT_INTERVAL
            self._ready.set()
            log.info("connected to %s:%s as %s", self.host, self.port, self.worker_id)
            heartbeat = asyncio.create_task(self._heartbeat(conn, max(0.05, interval)))
            while True:
                message = await conn.recv()
                if message.get("type") == "run":
                    job = asyncio.create_task(self._execute(conn, message))
                    running.add(job)
                    job.add_done_callback(running.discard)
        except ConnectionClosed:
            return connected
        finally:
            self._ready.clear()
            pending = list(running)
            if heartbeat is not None:
                pending.append(heartbeat)
            for item in pending:
                item.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            self._conn = None
            await conn.close()

    async def _heartbeat(self, conn, interval):
        while True:
            await asyncio.sleep(interval)
            try:
                await conn.send({"type": "heartbeat"})
            except ProtocolError:
                await conn.close()
                return

    async def _execute(self, conn, message):
        try:
            job = str(message["job"])
            index = int(message["index"])
            attempt = int(message["attempt"])
            kind = str(message["kind"])
        except (KeyError, TypeError, ValueError):
            log.warning("malformed task message ignored")
            return
        pool = self._pool
        loop = asyncio.get_running_loop()
        try:
            outcome = await loop.run_in_executor(pool, tasks.execute, kind, message.get("payload"))
        except BrokenExecutor as exc:
            outcome = {"ok": False, "error": f"executor failed: {exc}"}
            if self._pool is pool and not self._stopping:
                self._pool = self._make_pool()
                pool.shutdown(wait=False, cancel_futures=True)
        except Exception as exc:
            outcome = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        base = {"job": job, "index": index, "attempt": attempt}
        if outcome["ok"]:
            sent = await self._report(conn, {"type": "result", **base, "result": outcome["result"]}, base)
            if sent:
                self.completed += 1
                return
        else:
            await self._report(conn, {"type": "error", **base, "error": outcome["error"]}, base)
        self.failed += 1

    async def _report(self, conn, message, base):
        try:
            await conn.send(message)
            return True
        except ConnectionClosed:
            return False
        except (ProtocolError, TypeError, ValueError) as exc:
            fallback = {"type": "error", **base, "error": f"result could not be sent: {exc}"}
            try:
                await conn.send(fallback)
            except ProtocolError:
                pass
            return False
