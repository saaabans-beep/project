import asyncio
import logging

from . import config, tasks
from .protocol import Connection, ConnectionClosed, ProtocolError
from .scheduler import Scheduler, SchedulerError
from .security import server_authenticate

log = logging.getLogger("nodemesh.coordinator")

MIN_SECRET_LENGTH = 8
MAX_WAIT = 3600.0
DEFAULT_WAIT = 30.0


def _text(request, key):
    value = request.get(key)
    if not isinstance(value, str) or not value:
        raise SchedulerError(f"missing field: {key}")
    return value


def _seconds(value, default, maximum):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    return max(0.0, min(float(value), maximum))


def _clamp(value, low, high, default):
    if isinstance(value, bool) or not isinstance(value, int):
        return default
    return max(low, min(value, high))


class Coordinator:
    def __init__(
        self,
        host=config.DEFAULT_HOST,
        port=config.DEFAULT_PORT,
        secret=None,
        ssl_context=None,
        scheduler=None,
        heartbeat_interval=config.HEARTBEAT_INTERVAL,
        heartbeat_timeout=config.HEARTBEAT_TIMEOUT,
        reap_interval=config.REAP_INTERVAL,
        plugins=(),
    ):
        if not isinstance(secret, str) or len(secret) < MIN_SECRET_LENGTH:
            raise ValueError(f"secret must be at least {MIN_SECRET_LENGTH} characters")
        tasks.load_plugins(plugins)
        self.host = host
        self.port = port
        self.ssl_context = ssl_context
        self.heartbeat_interval = heartbeat_interval
        self.reap_interval = reap_interval
        self.scheduler = scheduler or Scheduler(heartbeat_timeout=heartbeat_timeout)
        self._secret = secret
        self._server = None
        self._reaper = None
        self._changed = None
        self._handlers = set()
        self._worker_conns = {}
        self._ops = {
            "submit": self._op_submit,
            "status": self._op_status,
            "result": self._op_result,
            "wait": self._op_wait,
            "cancel": self._op_cancel,
            "jobs": self._op_jobs,
            "stats": self._op_stats,
            "workers": self._op_workers,
            "kinds": self._op_kinds,
        }

    async def start(self):
        self._changed = asyncio.Condition()
        self._server = await asyncio.start_server(
            self._handle, self.host, self.port, ssl=self.ssl_context
        )
        self.port = self._server.sockets[0].getsockname()[1]
        self._reaper = asyncio.create_task(self._reap_loop())
        log.info("coordinator listening on %s:%s", self.host, self.port)

    async def serve_forever(self):
        await self._server.serve_forever()

    async def stop(self):
        if self._reaper is not None:
            self._reaper.cancel()
            await asyncio.gather(self._reaper, return_exceptions=True)
            self._reaper = None
        if self._server is not None:
            self._server.close()
        handlers = list(self._handlers)
        for handler in handlers:
            handler.cancel()
        await asyncio.gather(*handlers, return_exceptions=True)
        if self._server is not None:
            await self._server.wait_closed()
            self._server = None
        log.info("coordinator stopped")

    async def _notify(self):
        async with self._changed:
            self._changed.notify_all()

    async def _dispatch(self):
        for worker_id, conn in list(self._worker_conns.items()):
            if worker_id not in self.scheduler.workers:
                continue
            for assignment in self.scheduler.assign(worker_id):
                try:
                    await conn.send({"type": "run", **assignment})
                except (ProtocolError, OSError, TypeError, ValueError) as exc:
                    log.warning("dispatch to worker %s failed: %s", worker_id, exc)
                    await conn.close()
                    break

    async def _reap_loop(self):
        while True:
            await asyncio.sleep(self.reap_interval)
            try:
                reaped = self.scheduler.reap()
                for worker_id in reaped.workers:
                    log.warning("worker %s missed its heartbeat deadline", worker_id)
                    conn = self._worker_conns.get(worker_id)
                    if conn is not None:
                        await conn.close()
                if reaped.workers or reaped.timed_out:
                    await self._notify()
                    await self._dispatch()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("reaper failed")

    async def _handle(self, reader, writer):
        conn = Connection(reader, writer)
        self._handlers.add(asyncio.current_task())
        try:
            try:
                auth, proof = await server_authenticate(conn, self._secret)
            except (ProtocolError, asyncio.TimeoutError) as exc:
                log.warning("rejected connection from %s: %s", conn.peer, exc)
                return
            if auth["role"] == "worker":
                await self._serve_worker(conn, auth, proof)
            else:
                await self._serve_client(conn, auth, proof)
        except ConnectionClosed:
            pass
        except Exception:
            log.exception("session with %s failed", conn.peer)
        finally:
            self._handlers.discard(asyncio.current_task())
            await conn.close()

    async def _serve_worker(self, conn, auth, proof):
        slots = _clamp(auth.get("slots"), 1, config.MAX_SLOTS, 1)
        kinds = auth.get("kinds")
        if isinstance(kinds, list) and all(isinstance(item, str) for item in kinds):
            kinds = frozenset(kinds)
        else:
            kinds = None
        worker = self.scheduler.register_worker(auth["name"], slots, kinds)
        self._worker_conns[worker.id] = conn
        log.info("worker %s (%s) joined with %d slots", worker.id, worker.name, worker.slots)
        try:
            await conn.send(
                {
                    "type": "welcome",
                    "proof": proof,
                    "worker_id": worker.id,
                    "heartbeat_interval": self.heartbeat_interval,
                }
            )
            await self._dispatch()
            while True:
                message = await conn.recv()
                self.scheduler.heartbeat(worker.id)
                kind = message.get("type")
                if kind == "heartbeat":
                    continue
                if kind == "bye":
                    break
                key = self._task_key(message)
                if key is None:
                    log.debug("ignoring message from %s: %r", worker.id, kind)
                    continue
                if kind == "result":
                    self.scheduler.complete(worker.id, *key, message.get("result"))
                elif kind == "error":
                    reason = str(message.get("error") or "unknown error")
                    log.warning("task %s/%s failed on %s: %s", key[0], key[1], worker.id, reason)
                    self.scheduler.fail_task(worker.id, *key, reason)
                else:
                    continue
                await self._notify()
                await self._dispatch()
        finally:
            self._worker_conns.pop(worker.id, None)
            requeued = self.scheduler.remove_worker(worker.id)
            log.info("worker %s left, %d task(s) requeued", worker.id, requeued)
            try:
                await self._notify()
                await self._dispatch()
            except Exception:
                log.debug("cleanup after worker %s failed", worker.id, exc_info=True)

    @staticmethod
    def _task_key(message):
        job, index, attempt = message.get("job"), message.get("index"), message.get("attempt")
        if (
            isinstance(job, str)
            and isinstance(index, int)
            and isinstance(attempt, int)
            and not isinstance(index, bool)
            and not isinstance(attempt, bool)
            and index >= 0
        ):
            return job, index, attempt
        return None

    async def _serve_client(self, conn, auth, proof):
        await conn.send({"type": "welcome", "proof": proof})
        while True:
            request = await conn.recv()
            response = await self._respond(request)
            await conn.send(response)

    async def _respond(self, request):
        envelope = {"type": "response", "id": request.get("id")}
        handler = self._ops.get(request.get("op"))
        if handler is None:
            return {**envelope, "ok": False, "error": f"unknown operation: {request.get('op')}"}
        try:
            return {**envelope, "ok": True, **(await handler(request))}
        except (SchedulerError, tasks.TaskError) as exc:
            return {**envelope, "ok": False, "error": str(exc)}
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("operation %s failed", request.get("op"))
            return {**envelope, "ok": False, "error": "internal error"}

    async def _op_submit(self, request):
        job = self.scheduler.submit(
            _text(request, "kind"),
            request.get("params"),
            request.get("task_timeout"),
            request.get("max_attempts"),
        )
        log.info("job %s (%s) submitted with %d tasks", job.id, job.kind, len(job.tasks))
        await self._notify()
        await self._dispatch()
        return {"job": job.id, "tasks": len(job.tasks)}

    async def _op_status(self, request):
        job = self.scheduler.get_job(_text(request, "job"))
        return {"job": self.scheduler.view(job, detail=True)}

    async def _op_result(self, request):
        job = self.scheduler.get_job(_text(request, "job"))
        if not job.terminal:
            raise SchedulerError("job is not finished")
        return {"job": self.scheduler.view(job, detail=True, include_result=True)}

    async def _op_wait(self, request):
        job = self.scheduler.get_job(_text(request, "job"))
        timeout = _seconds(request.get("timeout"), DEFAULT_WAIT, MAX_WAIT)
        if not job.terminal and timeout > 0:
            async with self._changed:
                try:
                    await asyncio.wait_for(
                        self._changed.wait_for(lambda: job.terminal), timeout
                    )
                except asyncio.TimeoutError:
                    pass
        return {"job": self.scheduler.view(job, detail=True, include_result=True)}

    async def _op_cancel(self, request):
        cancelled = self.scheduler.cancel(_text(request, "job"))
        if cancelled:
            await self._notify()
        return {"cancelled": cancelled}

    async def _op_jobs(self, request):
        limit = _clamp(request.get("limit"), 1, 1000, 100)
        return {"jobs": [self.scheduler.view(job) for job in self.scheduler.list_jobs(limit)]}

    async def _op_stats(self, request):
        return {"stats": self.scheduler.stats()}

    async def _op_workers(self, request):
        return {"workers": self.scheduler.worker_views()}

    async def _op_kinds(self, request):
        return {"kinds": tasks.describe()}
