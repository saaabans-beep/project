import collections
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from . import config, tasks

PENDING = "pending"
RUNNING = "running"
DONE = "done"
FAILED = "failed"
CANCELLED = "cancelled"
STATUSES = (PENDING, RUNNING, DONE, FAILED, CANCELLED)
TERMINAL = frozenset((DONE, FAILED, CANCELLED))

QUEUED = "queued"
ACTIVE = "active"
FINISHED = "finished"

MAX_TIMEOUT = 86400.0
MAX_ATTEMPTS_LIMIT = 20
MAX_PAYLOAD = config.MAX_FRAME - 4096

Reaped = collections.namedtuple("Reaped", "workers timed_out")


class SchedulerError(Exception):
    pass


class UnknownJob(SchedulerError):
    pass


@dataclass
class Task:
    index: int
    payload: Any
    state: str = QUEUED
    attempts: int = 0
    worker: Any = None
    deadline: float = 0.0
    result: Any = None


@dataclass
class Job:
    id: str
    kind: str
    params: dict
    task_timeout: float
    max_attempts: int
    tasks: list
    created: float
    status: str = PENDING
    started: Any = None
    finished: Any = None
    error: Any = None
    result: Any = None
    done: int = 0

    @property
    def terminal(self):
        return self.status in TERMINAL


@dataclass
class WorkerInfo:
    id: str
    name: str
    slots: int
    kinds: Any
    last_seen: float
    joined: float
    running: set = field(default_factory=set)
    completed: int = 0
    failed: int = 0

    @property
    def free(self):
        return self.slots - len(self.running)


class Scheduler:
    def __init__(
        self,
        clock=time.monotonic,
        heartbeat_timeout=config.HEARTBEAT_TIMEOUT,
        max_finished=config.MAX_FINISHED_JOBS,
        default_task_timeout=config.TASK_TIMEOUT,
        default_max_attempts=config.MAX_ATTEMPTS,
    ):
        self.clock = clock
        self.heartbeat_timeout = heartbeat_timeout
        self.max_finished = max_finished
        self.default_task_timeout = default_task_timeout
        self.default_max_attempts = default_max_attempts
        self.jobs = {}
        self.workers = {}
        self.tasks_completed = 0
        self.tasks_retried = 0
        self.started = time.time()
        self._queue = collections.deque()
        self._active = set()

    def submit(self, kind, params=None, task_timeout=None, max_attempts=None):
        spec = tasks.job_kind(kind)
        if params is None:
            params = {}
        if not isinstance(params, dict):
            raise SchedulerError("params must be an object")
        task_timeout = self._bounded_number(
            task_timeout, self.default_task_timeout, 0.001, MAX_TIMEOUT, "task_timeout"
        )
        max_attempts = int(
            self._bounded_number(
                max_attempts, self.default_max_attempts, 1, MAX_ATTEMPTS_LIMIT, "max_attempts"
            )
        )
        try:
            payloads = list(spec.split(params))
        except Exception as exc:
            raise SchedulerError(f"invalid job parameters: {exc}") from exc
        if not payloads:
            raise SchedulerError("job has no tasks")
        if len(payloads) > config.MAX_TASKS_PER_JOB:
            raise SchedulerError(f"job has too many tasks (limit {config.MAX_TASKS_PER_JOB})")
        try:
            for payload in payloads:
                if len(json.dumps(payload)) > MAX_PAYLOAD:
                    raise SchedulerError("task payload is too large")
        except (TypeError, ValueError) as exc:
            raise SchedulerError(f"task payload is not JSON serializable: {exc}") from exc
        job = Job(
            id=uuid.uuid4().hex[:12],
            kind=kind,
            params=params,
            task_timeout=task_timeout,
            max_attempts=max_attempts,
            tasks=[Task(index=i, payload=p) for i, p in enumerate(payloads)],
            created=time.time(),
        )
        self.jobs[job.id] = job
        self._queue.extend((job.id, task.index) for task in job.tasks)
        return job

    @staticmethod
    def _bounded_number(value, default, minimum, maximum, label):
        if value is None:
            return default
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise SchedulerError(f"{label} must be a number")
        if not minimum <= value <= maximum:
            raise SchedulerError(f"{label} must be between {minimum} and {maximum}")
        return value

    def get_job(self, job_id):
        try:
            return self.jobs[job_id]
        except KeyError:
            raise UnknownJob(f"unknown job: {job_id}") from None

    def list_jobs(self, limit=100):
        items = list(self.jobs.values())[-limit:]
        items.reverse()
        return items

    def register_worker(self, name, slots, kinds=None):
        now = self.clock()
        worker = WorkerInfo(
            id=uuid.uuid4().hex[:8],
            name=name,
            slots=max(1, int(slots)),
            kinds=frozenset(kinds) if kinds is not None else None,
            last_seen=now,
            joined=time.time(),
        )
        self.workers[worker.id] = worker
        return worker

    def heartbeat(self, worker_id):
        worker = self.workers.get(worker_id)
        if worker is None:
            return False
        worker.last_seen = self.clock()
        return True

    def remove_worker(self, worker_id):
        worker = self.workers.pop(worker_id, None)
        if worker is None:
            return 0
        requeued = 0
        for job_id, index, attempt in sorted(worker.running):
            job = self.jobs.get(job_id)
            if job is None or job.terminal:
                continue
            task = job.tasks[index]
            if task.state == ACTIVE and task.worker == worker_id and task.attempts == attempt:
                self._retry(job, task, f"worker {worker.name} was lost")
                requeued += 1
        worker.running.clear()
        return requeued

    def assign(self, worker_id):
        worker = self.workers.get(worker_id)
        if worker is None or worker.free <= 0:
            return []
        now = self.clock()
        capacity = worker.free
        assignments = []
        skipped = []
        while self._queue and len(assignments) < capacity:
            job_id, index = self._queue.popleft()
            job = self.jobs.get(job_id)
            if job is None or job.terminal:
                continue
            task = job.tasks[index]
            if task.state != QUEUED:
                continue
            if worker.kinds is not None and job.kind not in worker.kinds:
                skipped.append((job_id, index))
                continue
            task.state = ACTIVE
            task.attempts += 1
            task.worker = worker.id
            task.deadline = now + job.task_timeout
            worker.running.add((job.id, index, task.attempts))
            self._active.add((job.id, index))
            if job.status == PENDING:
                job.status = RUNNING
                job.started = time.time()
            assignments.append(
                {
                    "job": job.id,
                    "index": index,
                    "attempt": task.attempts,
                    "kind": job.kind,
                    "payload": task.payload,
                    "timeout": job.task_timeout,
                }
            )
        self._queue.extendleft(reversed(skipped))
        return assignments

    def _claim(self, worker_id, job_id, index, attempt):
        worker = self.workers.get(worker_id)
        if worker is None:
            return None
        key = (job_id, index, attempt)
        if key not in worker.running:
            return None
        worker.running.discard(key)
        job = self.jobs.get(job_id)
        if job is None or job.terminal:
            return None
        task = job.tasks[index]
        if task.state != ACTIVE or task.worker != worker_id or task.attempts != attempt:
            return None
        return worker, job, task

    def complete(self, worker_id, job_id, index, attempt, result):
        claim = self._claim(worker_id, job_id, index, attempt)
        if claim is None:
            return False
        worker, job, task = claim
        task.state = FINISHED
        task.result = result
        task.worker = None
        self._active.discard((job.id, index))
        job.done += 1
        worker.completed += 1
        self.tasks_completed += 1
        if job.done == len(job.tasks):
            self._finish(job)
        return True

    def fail_task(self, worker_id, job_id, index, attempt, error):
        claim = self._claim(worker_id, job_id, index, attempt)
        if claim is None:
            return False
        worker, job, task = claim
        worker.failed += 1
        self._retry(job, task, str(error))
        return True

    def cancel(self, job_id):
        job = self.get_job(job_id)
        if job.terminal:
            return False
        job.status = CANCELLED
        job.finished = time.time()
        self._seal(job)
        return True

    def reap(self):
        now = self.clock()
        dead = [
            worker.id
            for worker in self.workers.values()
            if now - worker.last_seen > self.heartbeat_timeout
        ]
        for worker_id in dead:
            self.remove_worker(worker_id)
        timed_out = 0
        for job_id, index in sorted(self._active):
            job = self.jobs.get(job_id)
            if job is None or job.terminal:
                self._active.discard((job_id, index))
                continue
            task = job.tasks[index]
            if task.state == ACTIVE and now > task.deadline:
                timed_out += 1
                self._retry(job, task, f"task timed out after {job.task_timeout:g}s")
        return Reaped(dead, timed_out)

    def _retry(self, job, task, reason):
        self._active.discard((job.id, task.index))
        task.worker = None
        if job.terminal:
            return
        if task.attempts >= job.max_attempts:
            self._fail_job(
                job, f"task {task.index} failed after {task.attempts} attempts: {reason}"
            )
            return
        task.state = QUEUED
        self.tasks_retried += 1
        self._queue.appendleft((job.id, task.index))

    def _finish(self, job):
        spec = tasks.job_kind(job.kind)
        try:
            result = spec.reduce([task.result for task in job.tasks], job.params)
            json.dumps(result)
        except Exception as exc:
            self._fail_job(job, f"reduce failed: {type(exc).__name__}: {exc}")
            return
        job.result = result
        job.status = DONE
        job.finished = time.time()
        self._seal(job)

    def _fail_job(self, job, error):
        job.status = FAILED
        job.error = error
        job.finished = time.time()
        self._seal(job)

    def _seal(self, job):
        for task in job.tasks:
            self._active.discard((job.id, task.index))
            task.payload = None
            task.result = None
        self._evict()

    def _evict(self):
        finished = [job_id for job_id, job in self.jobs.items() if job.terminal]
        for job_id in finished[: max(0, len(finished) - self.max_finished)]:
            del self.jobs[job_id]

    def view(self, job, detail=False, include_result=False):
        end = job.finished if job.finished is not None else time.time()
        data = {
            "id": job.id,
            "kind": job.kind,
            "status": job.status,
            "total": len(job.tasks),
            "done": job.done,
            "created": job.created,
            "started": job.started,
            "finished": job.finished,
            "elapsed": round(end - job.created, 3),
            "error": job.error,
        }
        if detail:
            data["running"] = sum(1 for task in job.tasks if task.state == ACTIVE)
            data["queued"] = sum(1 for task in job.tasks if task.state == QUEUED)
            data["retries"] = sum(max(0, task.attempts - 1) for task in job.tasks)
            data["task_timeout"] = job.task_timeout
            data["max_attempts"] = job.max_attempts
        if include_result:
            data["result"] = job.result
        return data

    def worker_views(self):
        now = self.clock()
        return [
            {
                "id": worker.id,
                "name": worker.name,
                "slots": worker.slots,
                "busy": len(worker.running),
                "completed": worker.completed,
                "failed": worker.failed,
                "idle": round(now - worker.last_seen, 2),
                "kinds": sorted(worker.kinds) if worker.kinds is not None else None,
                "connected": round(time.time() - worker.joined, 1),
            }
            for worker in self.workers.values()
        ]

    def stats(self):
        counts = collections.Counter(job.status for job in self.jobs.values())
        queued = 0
        for job_id, index in self._queue:
            job = self.jobs.get(job_id)
            if job is not None and not job.terminal and job.tasks[index].state == QUEUED:
                queued += 1
        return {
            "uptime": round(time.time() - self.started, 1),
            "workers": len(self.workers),
            "slots": sum(worker.slots for worker in self.workers.values()),
            "busy": sum(len(worker.running) for worker in self.workers.values()),
            "queued_tasks": queued,
            "jobs": {status: counts.get(status, 0) for status in STATUSES},
            "tasks_completed": self.tasks_completed,
            "tasks_retried": self.tasks_retried,
        }
