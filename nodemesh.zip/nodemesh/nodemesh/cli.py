import argparse
import asyncio
import json
import logging
import secrets
import signal
import sys
import time

from . import __version__, config, tasks
from .client import Client, JobError, JobTimeout, RequestError
from .coordinator import Coordinator
from .protocol import ProtocolError
from .security import client_ssl_context, server_ssl_context
from .worker import Worker

log = logging.getLogger("nodemesh")

DEMO_JOBS = {
    "small": [
        ("count_primes", {"stop": 200_000, "parts": 8}),
        ("monte_carlo_pi", {"samples": 200_000, "parts": 8}),
    ],
    "medium": [
        ("count_primes", {"stop": 5_000_000, "parts": 16}),
        ("monte_carlo_pi", {"samples": 4_000_000, "parts": 16}),
        ("hash_chain", {"rounds": 300_000, "parts": 16}),
    ],
    "large": [
        ("count_primes", {"stop": 40_000_000, "parts": 32}),
        ("monte_carlo_pi", {"samples": 30_000_000, "parts": 32}),
        ("hash_chain", {"rounds": 1_000_000, "parts": 32}),
    ],
}


def dump(value):
    print(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False))


def parse_params(pairs, raw):
    params = {}
    if raw:
        try:
            loaded = json.loads(raw)
        except ValueError as exc:
            raise ValueError(f"invalid --json value: {exc}") from exc
        if not isinstance(loaded, dict):
            raise ValueError("--json must be an object")
        params.update(loaded)
    for pair in pairs or []:
        key, separator, value = pair.partition("=")
        if not separator or not key:
            raise ValueError(f"invalid --param, expected key=value: {pair}")
        try:
            params[key] = json.loads(value)
        except ValueError:
            params[key] = value
    return params


def resolve_secret(args):
    secret = args.secret or config.env_secret()
    if not secret:
        raise ValueError(f"a secret is required: set {config.ENV_SECRET} or pass --secret")
    return secret


def client_tls(args):
    if args.cafile:
        return client_ssl_context(args.cafile)
    if args.tls:
        return client_ssl_context()
    return None


def make_client(args):
    return Client(
        host=args.host,
        port=args.port,
        secret=resolve_secret(args),
        ssl_context=client_tls(args),
        tls_hostname=args.tls_hostname,
    )


async def with_signals(coro):
    loop = asyncio.get_running_loop()
    main_task = asyncio.current_task()
    for name in ("SIGTERM", "SIGINT"):
        number = getattr(signal, name, None)
        if number is None:
            continue
        try:
            loop.add_signal_handler(number, main_task.cancel)
        except (NotImplementedError, RuntimeError, ValueError):
            pass
    try:
        return await coro
    except asyncio.CancelledError:
        return 0


async def serve_coordinator(args):
    ssl_context = None
    if args.cert or args.key:
        if not (args.cert and args.key):
            raise ValueError("--cert and --key must be given together")
        ssl_context = server_ssl_context(args.cert, args.key)
    coordinator = Coordinator(
        host=args.host,
        port=args.port,
        secret=resolve_secret(args),
        ssl_context=ssl_context,
        heartbeat_timeout=args.heartbeat_timeout,
        plugins=args.plugin,
    )
    await coordinator.start()
    try:
        await coordinator.serve_forever()
    finally:
        await coordinator.stop()
    return 0


async def serve_worker(args):
    worker = Worker(
        host=args.host,
        port=args.port,
        secret=resolve_secret(args),
        name=args.name,
        slots=args.slots,
        executor=args.executor,
        plugins=args.plugin,
        ssl_context=client_tls(args),
        tls_hostname=args.tls_hostname,
        reconnect=not args.no_reconnect,
    )
    runner = asyncio.create_task(worker.run())
    try:
        await runner
    finally:
        await worker.stop()
        runner.cancel()
        await asyncio.gather(runner, return_exceptions=True)
    return 0


async def cmd_submit(args):
    client = make_client(args)
    params = parse_params(args.param, args.json)
    job_id = await client.submit(
        args.kind, params, task_timeout=args.task_timeout, max_attempts=args.max_attempts
    )
    if not args.wait:
        dump({"job": job_id})
        return 0
    job = await client.wait(job_id, args.timeout)
    dump(job)
    return 0 if job["status"] == "done" else 1


async def cmd_run(args):
    client = make_client(args)
    params = parse_params(args.param, args.json)
    result = await client.run(
        args.kind,
        params,
        timeout=args.timeout,
        task_timeout=args.task_timeout,
        max_attempts=args.max_attempts,
    )
    dump(result)
    return 0


async def cmd_status(args):
    dump(await make_client(args).status(args.job))
    return 0


async def cmd_result(args):
    dump(await make_client(args).result(args.job))
    return 0


async def cmd_wait(args):
    job = await make_client(args).wait(args.job, args.timeout)
    dump(job)
    return 0 if job["status"] == "done" else 1


async def cmd_cancel(args):
    cancelled = await make_client(args).cancel(args.job)
    dump({"cancelled": cancelled})
    return 0 if cancelled else 1


async def cmd_jobs(args):
    dump(await make_client(args).jobs(args.limit))
    return 0


async def cmd_workers(args):
    dump(await make_client(args).workers())
    return 0


async def cmd_stats(args):
    dump(await make_client(args).stats())
    return 0


async def cmd_kinds(args):
    dump(await make_client(args).kinds())
    return 0


async def cmd_demo(args):
    secret = secrets.token_hex(16)
    coordinator = Coordinator(host="127.0.0.1", port=0, secret=secret)
    await coordinator.start()
    workers = [
        Worker(
            host="127.0.0.1",
            port=coordinator.port,
            secret=secret,
            name=f"demo-{index + 1}",
            slots=args.slots,
            executor=args.executor,
        )
        for index in range(args.workers)
    ]
    runners = [asyncio.create_task(worker.run()) for worker in workers]
    try:
        await asyncio.gather(*(worker.wait_ready(30) for worker in workers))
        client = Client(port=coordinator.port, secret=secret)
        print(f"cluster: {args.workers} workers x {args.slots} slots")
        for kind, params in DEMO_JOBS[args.size]:
            started = time.perf_counter()
            result = await client.run(kind, params, timeout=600)
            elapsed = time.perf_counter() - started
            print(f"{kind:<16} {elapsed:6.2f}s  {json.dumps(result)}")
        for item in await client.workers():
            print(f"{item['name']:<10} tasks completed: {item['completed']}")
        return 0
    finally:
        for worker in workers:
            await worker.stop()
        for runner in runners:
            runner.cancel()
        await asyncio.gather(*runners, return_exceptions=True)
        await coordinator.stop()


def cmd_gen_secret(args):
    print(secrets.token_hex(32))
    return 0


def add_connection(parser):
    parser.add_argument("--host", default=config.env_host(), help="coordinator address")
    parser.add_argument("--port", type=int, default=config.env_port(), help="coordinator port")
    parser.add_argument("--secret", default=None, help=f"shared secret (prefer {config.ENV_SECRET})")
    parser.add_argument("--tls", action="store_true", help="connect over TLS using system CAs")
    parser.add_argument("--cafile", default=None, help="CA certificate for TLS (implies --tls)")
    parser.add_argument("--tls-hostname", default=None, help="expected TLS server name")


def add_job_options(parser):
    parser.add_argument("kind", help="task kind, see 'nodemesh kinds'")
    parser.add_argument("-p", "--param", action="append", help="job parameter key=value (JSON values allowed)")
    parser.add_argument("--json", default=None, help="job parameters as a JSON object")
    parser.add_argument("--task-timeout", type=float, default=None, help="seconds allowed per task")
    parser.add_argument("--max-attempts", type=int, default=None, help="attempts per task")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="nodemesh",
        description="NodeMesh: distributed computing system where several computers run shared jobs",
    )
    parser.add_argument("-V", "--version", action="version", version=f"nodemesh {__version__}")
    parser.add_argument(
        "--log-level",
        default="info",
        choices=("debug", "info", "warning", "error"),
        help="logging verbosity",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    p = sub.add_parser("coordinator", help="run the coordinator")
    p.add_argument("--host", default="127.0.0.1", help="address to listen on")
    p.add_argument("--port", type=int, default=config.env_port(), help="port to listen on")
    p.add_argument("--secret", default=None, help=f"shared secret (prefer {config.ENV_SECRET})")
    p.add_argument("--cert", default=None, help="TLS certificate chain (PEM)")
    p.add_argument("--key", default=None, help="TLS private key (PEM)")
    p.add_argument("--heartbeat-timeout", type=float, default=config.HEARTBEAT_TIMEOUT)
    p.add_argument("--plugin", action="append", default=[], help="module with custom tasks")
    p.set_defaults(run=lambda args: with_signals(serve_coordinator(args)))

    p = sub.add_parser("worker", help="run a worker that executes tasks")
    add_connection(p)
    p.add_argument("--name", default=None, help="worker name")
    p.add_argument("--slots", type=int, default=None, help="parallel tasks (default: CPU count)")
    p.add_argument("--executor", choices=("process", "thread"), default="process")
    p.add_argument("--plugin", action="append", default=[], help="module with custom tasks")
    p.add_argument("--no-reconnect", action="store_true", help="exit when the connection is lost")
    p.set_defaults(run=lambda args: with_signals(serve_worker(args)))

    p = sub.add_parser("submit", help="submit a job")
    add_connection(p)
    add_job_options(p)
    p.add_argument("--wait", action="store_true", help="wait for completion and print the job")
    p.add_argument("--timeout", type=float, default=None, help="seconds to wait with --wait")
    p.set_defaults(run=cmd_submit)

    p = sub.add_parser("run", help="submit a job, wait, and print only its result")
    add_connection(p)
    add_job_options(p)
    p.add_argument("--timeout", type=float, default=None, help="seconds to wait")
    p.set_defaults(run=cmd_run)

    for name, handler, text in (
        ("status", cmd_status, "show job status"),
        ("result", cmd_result, "print the result of a finished job"),
        ("wait", cmd_wait, "wait for a job to finish"),
        ("cancel", cmd_cancel, "cancel a job"),
    ):
        p = sub.add_parser(name, help=text)
        add_connection(p)
        p.add_argument("job")
        if name == "wait":
            p.add_argument("--timeout", type=float, default=None)
        p.set_defaults(run=handler)

    p = sub.add_parser("jobs", help="list recent jobs")
    add_connection(p)
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(run=cmd_jobs)

    for name, handler, text in (
        ("workers", cmd_workers, "list connected workers"),
        ("stats", cmd_stats, "show cluster statistics"),
        ("kinds", cmd_kinds, "list available task kinds"),
    ):
        p = sub.add_parser(name, help=text)
        add_connection(p)
        p.set_defaults(run=handler)

    p = sub.add_parser("demo", help="run a local cluster and a few sample jobs")
    p.add_argument("--workers", type=int, default=3)
    p.add_argument("--slots", type=int, default=2)
    p.add_argument("--executor", choices=("process", "thread"), default="process")
    p.add_argument("--size", choices=tuple(DEMO_JOBS), default="medium")
    p.set_defaults(run=cmd_demo)

    p = sub.add_parser("gen-secret", help="print a random shared secret")
    p.set_defaults(run=cmd_gen_secret, sync=True)

    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )
    try:
        if getattr(args, "sync", False):
            return args.run(args)
        return asyncio.run(args.run(args)) or 0
    except JobTimeout as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3
    except JobError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except (
        RequestError,
        ProtocolError,
        tasks.TaskError,
        OSError,
        ValueError,
        asyncio.TimeoutError,
    ) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
