import hashlib
import importlib
import math
import random
import re
import time
from collections import Counter
from dataclasses import dataclass
from typing import Any, Callable


class TaskError(Exception):
    pass


class UnknownTask(TaskError):
    pass


@dataclass(frozen=True)
class TaskSpec:
    name: str
    run: Callable
    split: Callable
    reduce: Callable
    description: str = ""


_REGISTRY = {}


def _default_split(params):
    return [params]


def _default_reduce(results, params):
    return results


def task(name, split=None, reduce=None, description="", replace=False):
    def decorator(func):
        if name in _REGISTRY and not replace:
            raise TaskError(f"task already registered: {name}")
        _REGISTRY[name] = TaskSpec(
            name=name,
            run=func,
            split=split or _default_split,
            reduce=reduce or _default_reduce,
            description=description,
        )
        return func

    return decorator


def job_kind(name):
    try:
        return _REGISTRY[name]
    except KeyError:
        raise UnknownTask(f"unknown task kind: {name}") from None


def registered():
    return sorted(_REGISTRY)


def describe():
    return {name: _REGISTRY[name].description for name in registered()}


def load_plugins(modules):
    for module in modules or ():
        importlib.import_module(module)


def init_process(plugins):
    load_plugins(plugins)


def execute(kind, payload):
    try:
        return {"ok": True, "result": job_kind(kind).run(payload)}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def split_range(start, stop, parts):
    total = stop - start
    if total <= 0:
        return []
    parts = max(1, min(parts, total))
    size, extra = divmod(total, parts)
    ranges = []
    cursor = start
    for index in range(parts):
        width = size + (1 if index < extra else 0)
        ranges.append((cursor, cursor + width))
        cursor += width
    return ranges


def _int(params, key, default=None, minimum=None, maximum=None):
    value = params.get(key, default)
    if value is None:
        raise TaskError(f"missing parameter: {key}")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TaskError(f"parameter {key} must be a number")
    if isinstance(value, float):
        if not value.is_integer():
            raise TaskError(f"parameter {key} must be an integer")
        value = int(value)
    if minimum is not None and value < minimum:
        raise TaskError(f"parameter {key} must be at least {minimum}")
    if maximum is not None and value > maximum:
        raise TaskError(f"parameter {key} must be at most {maximum}")
    return value


def _float(params, key, default=None, minimum=None, maximum=None):
    value = params.get(key, default)
    if value is None:
        raise TaskError(f"missing parameter: {key}")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TaskError(f"parameter {key} must be a number")
    if not math.isfinite(value):
        raise TaskError(f"parameter {key} must be finite")
    if minimum is not None and value < minimum:
        raise TaskError(f"parameter {key} must be at least {minimum}")
    if maximum is not None and value > maximum:
        raise TaskError(f"parameter {key} must be at most {maximum}")
    return float(value)


def _range_split(params):
    start = _int(params, "start", 0)
    stop = _int(params, "stop")
    parts = _int(params, "parts", 8, 1, 10000)
    if stop <= start:
        raise TaskError("stop must be greater than start")
    return [{"start": a, "stop": b} for a, b in split_range(start, stop, parts)]


def _sum_reduce(results, params):
    return sum(results)


def _echo_split(params):
    return [{"value": params.get("value")}]


@task("echo", split=_echo_split, reduce=lambda results, params: results[0], description="return the given value")
def echo(payload):
    return payload["value"]


@task(
    "sum_squares",
    split=_range_split,
    reduce=_sum_reduce,
    description="sum of i*i for i in [start, stop)",
)
def sum_squares(payload):
    return sum(i * i for i in range(payload["start"], payload["stop"]))


@task(
    "count_primes",
    split=_range_split,
    reduce=_sum_reduce,
    description="count primes in [start, stop)",
)
def count_primes(payload):
    low = max(2, payload["start"])
    high = payload["stop"]
    if high <= low:
        return 0
    root = math.isqrt(high - 1) + 1
    base = bytearray([1]) * (root + 1)
    base[0:2] = b"\x00\x00"
    for i in range(2, math.isqrt(root) + 1):
        if base[i]:
            base[i * i :: i] = bytearray(len(range(i * i, root + 1, i)))
    size = high - low
    segment = bytearray([1]) * size
    for p in range(2, root + 1):
        if not base[p]:
            continue
        first = max(p * p, ((low + p - 1) // p) * p)
        if first >= high:
            continue
        segment[first - low :: p] = bytearray(len(range(first - low, size, p)))
    return sum(segment)


def _pi_split(params):
    samples = _int(params, "samples", 1_000_000, 1, 10**12)
    parts = _int(params, "parts", 8, 1, 10000)
    seed = _int(params, "seed", 0)
    return [
        {"samples": b - a, "seed": f"{seed}:{index}"}
        for index, (a, b) in enumerate(split_range(0, samples, parts))
    ]


def _pi_reduce(results, params):
    inside = sum(item["inside"] for item in results)
    samples = sum(item["samples"] for item in results)
    return {"pi": 4.0 * inside / samples, "samples": samples}


@task(
    "monte_carlo_pi",
    split=_pi_split,
    reduce=_pi_reduce,
    description="estimate pi with Monte Carlo sampling",
)
def monte_carlo_pi(payload):
    rand = random.Random(payload["seed"]).random
    inside = 0
    for _ in range(payload["samples"]):
        x = rand()
        y = rand()
        if x * x + y * y <= 1.0:
            inside += 1
    return {"inside": inside, "samples": payload["samples"]}


def _hash_split(params):
    data = params.get("data", "nodemesh")
    if not isinstance(data, str):
        raise TaskError("parameter data must be a string")
    rounds = _int(params, "rounds", 200_000, 1, 10**9)
    parts = _int(params, "parts", 8, 1, 10000)
    return [{"seed": f"{data}:{index}", "rounds": rounds} for index in range(parts)]


def _hash_reduce(results, params):
    digest = hashlib.sha256("".join(results).encode("ascii")).hexdigest()
    return {"digest": digest, "parts": len(results)}


@task(
    "hash_chain",
    split=_hash_split,
    reduce=_hash_reduce,
    description="iterated SHA-256 chains combined into one digest",
)
def hash_chain(payload):
    digest = hashlib.sha256(payload["seed"].encode("utf-8")).digest()
    for _ in range(payload["rounds"]):
        digest = hashlib.sha256(digest).digest()
    return digest.hex()


WORD = re.compile(r"\w+", re.UNICODE)


def _words_split(params):
    texts = params.get("texts")
    if not isinstance(texts, list) or not texts or not all(isinstance(t, str) for t in texts):
        raise TaskError("parameter texts must be a non-empty list of strings")
    parts = _int(params, "parts", 4, 1, 10000)
    _int(params, "top", 10, 1, 1000)
    return [{"texts": texts[a:b]} for a, b in split_range(0, len(texts), parts)]


def _words_reduce(results, params):
    merged = Counter()
    for counts in results:
        merged.update(counts)
    top = _int(params, "top", 10, 1, 1000)
    ranked = sorted(merged.items(), key=lambda item: (-item[1], item[0]))
    return {
        "total": sum(merged.values()),
        "unique": len(merged),
        "top": [[word, count] for word, count in ranked[:top]],
    }


@task(
    "word_count",
    split=_words_split,
    reduce=_words_reduce,
    description="count words across a list of texts",
)
def word_count(payload):
    counts = Counter()
    for text in payload["texts"]:
        counts.update(WORD.findall(text.lower()))
    return dict(counts)


def _sleep_split(params):
    seconds = _float(params, "seconds", 0.1, 0.0, 3600.0)
    parts = _int(params, "parts", 1, 1, 10000)
    return [{"seconds": seconds} for _ in range(parts)]


def _sleep_reduce(results, params):
    return {"tasks": len(results), "slept": round(sum(results), 6)}


@task(
    "sleep",
    split=_sleep_split,
    reduce=_sleep_reduce,
    description="sleep for the given number of seconds in each task",
)
def sleep(payload):
    time.sleep(payload["seconds"])
    return payload["seconds"]


def _fail_split(params):
    parts = _int(params, "parts", 1, 1, 10000)
    message = str(params.get("message", "boom"))
    return [{"message": message} for _ in range(parts)]


@task("fail", split=_fail_split, description="always fails; useful for testing error handling")
def fail(payload):
    raise RuntimeError(payload["message"])
