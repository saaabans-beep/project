import asyncio
import json
import struct

from . import config


class ProtocolError(Exception):
    pass


class ConnectionClosed(ProtocolError):
    pass


class AuthError(ProtocolError):
    pass


HEADER = struct.Struct(">I")


def encode(message):
    payload = json.dumps(message, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    if len(payload) > config.MAX_FRAME:
        raise ProtocolError("message too large")
    return HEADER.pack(len(payload)) + payload


def decode(payload):
    try:
        message = json.loads(payload)
    except ValueError as exc:
        raise ProtocolError("invalid JSON") from exc
    if not isinstance(message, dict):
        raise ProtocolError("message must be an object")
    return message


class Connection:
    def __init__(self, reader, writer):
        self.reader = reader
        self.writer = writer
        self.peer = str(writer.get_extra_info("peername"))
        self._lock = asyncio.Lock()

    async def send(self, message):
        data = encode(message)
        async with self._lock:
            try:
                self.writer.write(data)
                await self.writer.drain()
            except OSError as exc:
                raise ConnectionClosed(str(exc)) from exc

    async def recv(self, max_size=None):
        limit = config.MAX_FRAME if max_size is None else max_size
        try:
            header = await self.reader.readexactly(HEADER.size)
            (length,) = HEADER.unpack(header)
            if length > limit:
                raise ProtocolError("frame too large")
            payload = await self.reader.readexactly(length)
        except asyncio.IncompleteReadError as exc:
            raise ConnectionClosed("connection closed by peer") from exc
        except OSError as exc:
            raise ConnectionClosed(str(exc)) from exc
        return decode(payload)

    async def close(self):
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except OSError:
            pass
