import asyncio
import hashlib
import hmac
import os
import ssl

from . import config
from .protocol import AuthError, ProtocolError

ROLES = ("worker", "client")
MAX_NAME = 64


def new_nonce():
    return os.urandom(16).hex()


def _mac(secret, *parts):
    digest = hmac.new(secret.encode("utf-8"), digestmod=hashlib.sha256)
    for part in parts:
        digest.update(part.encode("utf-8"))
        digest.update(b"\x00")
    return digest.hexdigest()


def _same(left, right):
    return hmac.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


async def server_authenticate(conn, secret, timeout=config.HANDSHAKE_TIMEOUT):
    challenge = new_nonce()
    await conn.send({"type": "hello", "version": config.PROTOCOL_VERSION, "challenge": challenge})
    message = await asyncio.wait_for(conn.recv(config.HANDSHAKE_FRAME), timeout)
    role = message.get("role")
    name = message.get("name")
    cnonce = message.get("cnonce")
    response = message.get("response")
    valid = (
        message.get("type") == "auth"
        and role in ROLES
        and all(isinstance(value, str) for value in (name, cnonce, response))
        and 0 < len(name) <= MAX_NAME
        and 0 < len(cnonce) <= 128
    )
    if not valid:
        raise AuthError("malformed authentication message")
    expected = _mac(secret, "client", challenge, cnonce, role, name)
    if not _same(expected, response):
        try:
            await conn.send({"type": "denied", "reason": "authentication failed"})
        except ProtocolError:
            pass
        raise AuthError("authentication failed")
    return message, _mac(secret, "server", challenge, cnonce)


async def client_authenticate(conn, secret, role, name, extra=None, timeout=config.HANDSHAKE_TIMEOUT):
    hello = await asyncio.wait_for(conn.recv(config.HANDSHAKE_FRAME), timeout)
    challenge = hello.get("challenge")
    if (
        hello.get("type") != "hello"
        or hello.get("version") != config.PROTOCOL_VERSION
        or not isinstance(challenge, str)
    ):
        raise ProtocolError("incompatible server")
    cnonce = new_nonce()
    message = dict(extra or {})
    message.update(
        {
            "type": "auth",
            "role": role,
            "name": name,
            "cnonce": cnonce,
            "response": _mac(secret, "client", challenge, cnonce, role, name),
        }
    )
    await conn.send(message)
    reply = await asyncio.wait_for(conn.recv(config.HANDSHAKE_FRAME), timeout)
    if reply.get("type") == "denied":
        raise AuthError(str(reply.get("reason") or "authentication failed"))
    if reply.get("type") != "welcome":
        raise ProtocolError("unexpected handshake reply")
    proof = reply.get("proof")
    if not isinstance(proof, str) or not _same(proof, _mac(secret, "server", challenge, cnonce)):
        raise AuthError("server failed to prove knowledge of the secret")
    return reply


def server_ssl_context(certfile, keyfile):
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile, keyfile)
    return context


def client_ssl_context(cafile=None):
    context = ssl.create_default_context(cafile=cafile)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    return context


def connect_kwargs(ssl_context, tls_hostname=None):
    if ssl_context is None:
        return {}
    return {"ssl": ssl_context, "server_hostname": tls_hostname}
