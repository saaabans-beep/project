import asyncio
import os

from . import config
from .protocol import Connection
from .scheduler import TERMINAL
from .security import client_authenticate, connect_kwargs

WAIT_CHUNK = 30.0
READ_SLACK = 30.0


class RequestError(Exception):
    pass


class JobError(Exception):
    def __init__(self, job):
        self.job = job
        super().__init__(job.get("error") or f"job {job.get('id')} {job.get('status')}")


class JobTimeout(Exception):
    def __init__(self, job_id):
        self.job_id = job_id
        super().__init__(f"timed out waiting for job {job_id}")


class Client:
    def __init__(
        self,
        host=config.DEFAULT_HOST,
        port=config.DEFAULT_PORT,
        secret=None,
        name=None,
        ssl_context=None,
        tls_hostname=None,
        connect_timeout=config.CONNECT_TIMEOUT,
    ):
        if not secret:
            raise ValueError("secret is required")
        self.host = host
        self.port = port
        self.secret = secret
        self.name = (name or f"client-{os.getpid()}")[:64]
        self.ssl_context = ssl_context
        self.tls_hostname = tls_hostname
        self.connect_timeout = connect_timeout

    async def _request(self, op, read_timeout=READ_SLACK, **fields):
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(
                self.host,
                self.port,
                **connect_kwargs(self.ssl_context, self.tls_hostname or self.host),
            ),
            self.connect_timeout,
        )
        conn = Connection(reader, writer)
        try:
            await client_authenticate(conn, self.secret, "client", self.name)
            await conn.send({"type": "request", "op": op, **fields})
            response = await asyncio.wait_for(conn.recv(), read_timeout)
        finally:
            await conn.close()
        if not response.get("ok"):
            raise RequestError(str(response.get("error") or "request failed"))
        return response

    async def submit(self, kind, params=None, *, task_timeout=None, max_attempts=None):
        fields = {"kind": kind, "params": params or {}}
        if task_timeout is not None:
            fields["task_timeout"] = task_timeout
        if max_attempts is not None:
            fields["max_attempts"] = max_attempts
        response = await self._request("submit", **fields)
        return response["job"]

    async def status(self, job_id):
        return (await self._request("status", job=job_id))["job"]

    async def result(self, job_id):
        job = (await self._request("result", job=job_id))["job"]
        if job["status"] != "done":
            raise JobError(job)
        return job["result"]

    async def wait(self, job_id, timeout=None):
        loop = asyncio.get_running_loop()
        deadline = None if timeout is None else loop.time() + timeout
        while True:
            chunk = WAIT_CHUNK
            if deadline is not None:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise JobTimeout(job_id)
                chunk = min(chunk, remaining)
            response = await self._request(
                "wait", read_timeout=chunk + READ_SLACK, job=job_id, timeout=chunk
            )
            job = response["job"]
            if job["status"] in TERMINAL:
                return job

    async def run(self, kind, params=None, *, timeout=None, task_timeout=None, max_attempts=None):
        job_id = await self.submit(
            kind, params, task_timeout=task_timeout, max_attempts=max_attempts
        )
        try:
            job = await self.wait(job_id, timeout)
        except JobTimeout:
            await self.cancel(job_id)
            raise
        if job["status"] != "done":
            raise JobError(job)
        return job["result"]

    async def cancel(self, job_id):
        return (await self._request("cancel", job=job_id))["cancelled"]

    async def jobs(self, limit=100):
        return (await self._request("jobs", limit=limit))["jobs"]

    async def stats(self):
        return (await self._request("stats"))["stats"]

    async def workers(self):
        return (await self._request("workers"))["workers"]

    async def kinds(self):
        return (await self._request("kinds"))["kinds"]


class SyncClient:
    def __init__(self, *args, **kwargs):
        self._client = Client(*args, **kwargs)

    def _call(self, name, *args, **kwargs):
        return asyncio.run(getattr(self._client, name)(*args, **kwargs))

    def submit(self, kind, params=None, **options):
        return self._call("submit", kind, params, **options)

    def status(self, job_id):
        return self._call("status", job_id)

    def result(self, job_id):
        return self._call("result", job_id)

    def wait(self, job_id, timeout=None):
        return self._call("wait", job_id, timeout)

    def run(self, kind, params=None, **options):
        return self._call("run", kind, params, **options)

    def cancel(self, job_id):
        return self._call("cancel", job_id)

    def jobs(self, limit=100):
        return self._call("jobs", limit)

    def stats(self):
        return self._call("stats")

    def workers(self):
        return self._call("workers")

    def kinds(self):
        return self._call("kinds")
