import 'package:flutter_test/flutter_test.dart';
import 'package:zavod_uchet/models/item.dart';
import 'package:zavod_uchet/models/movement.dart';
import 'package:zavod_uchet/utils/format.dart';

void main() {
  test('Item остаток ниже минимума', () {
    const item = Item(name: 'Болт', code: 'B', kind: ItemKind.raw, unit: 'шт', quantity: 10, minQuantity: 20, price: 5);
    expect(item.isLow, isTrue);
    expect(item.totalValue, 50);
    expect(Item.fromMap(item.toMap()).name, 'Болт');
  });

  test('Знак движения', () {
    final inc = Movement(itemId: 1, type: MovementType.income, quantity: 5, date: DateTime(2026));
    final out = Movement(itemId: 1, type: MovementType.outcome, quantity: 5, date: DateTime(2026));
    expect(inc.signedQuantity, 5);
    expect(out.signedQuantity, -5);
  });

  test('Разбор чисел', () {
    expect(parseNum('1 250,5'), 1250.5);
    expect(parseNum('abc'), isNull);
  });
}
