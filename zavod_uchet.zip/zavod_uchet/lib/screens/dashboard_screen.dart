import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../models/movement.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/movement_tile.dart';
import '../widgets/stat_card.dart';
import 'item_detail_screen.dart';

class DashboardScreen extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const DashboardScreen({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.loading) return const Center(child: CircularProgressIndicator());
    final scheme = Theme.of(context).colorScheme;
    return RefreshIndicator(
      onRefresh: s.load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.55,
            children: [
              StatCard(title: 'Стоимость склада', value: fmtMoney(s.stockValue), icon: Icons.account_balance_wallet_outlined, color: scheme.primary),
              StatCard(title: 'Позиций', value: '${s.items.length}', subtitle: 'сырьё ${s.rawMaterials.length} · прод. ${s.products.length}', icon: Icons.inventory_2_outlined, color: scheme.tertiary, onTap: () => onNavigate(1)),
              StatCard(title: 'Открытых заказов', value: '${s.openOrders.length}', icon: Icons.factory_outlined, color: Colors.orange, onTap: () => onNavigate(3)),
              StatCard(title: 'Ниже минимума', value: '${s.lowStock.length}', icon: Icons.warning_amber_rounded, color: s.lowStock.isEmpty ? Colors.green : scheme.error, onTap: () => onNavigate(1)),
            ],
          ),
          const SizedBox(height: 20),
          _WeekChart(stats: s.weekStats),
          const SizedBox(height: 20),
          _ValueSplit(raw: s.valueOf(ItemKind.raw), product: s.valueOf(ItemKind.product)),
          if (s.lowStock.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('Требуют пополнения', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  for (final i in s.lowStock)
                    ListTile(
                      leading: Icon(Icons.warning_amber_rounded, color: scheme.error),
                      title: Text(i.name),
                      subtitle: Text('${i.kind.label} · мин. ${fmtQty(i.minQuantity)} ${i.unit}'),
                      trailing: Text('${fmtQty(i.quantity)} ${i.unit}', style: TextStyle(color: scheme.error, fontWeight: FontWeight.w600)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemDetailScreen(itemId: i.id!))),
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: Text('Последние операции', style: Theme.of(context).textTheme.titleMedium)),
              TextButton(onPressed: () => onNavigate(2), child: const Text('Все')),
            ],
          ),
          Card(
            child: s.movements.isEmpty
                ? const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Операций пока нет')))
                : Column(children: [for (final m in s.movements.take(6)) MovementTile(movement: m)]),
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _WeekChart extends StatelessWidget {
  final Map<DateTime, Map<MovementType, double>> stats;
  const _WeekChart({required this.stats});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final days = stats.keys.toList()..sort();
    double total(DateTime d) => stats[d]!.values.fold(0, (a, b) => a + b);
    double inCount(DateTime d) => (stats[d]![MovementType.income] ?? 0) + (stats[d]![MovementType.productionIn] ?? 0);
    final maxV = days.isEmpty ? 1.0 : days.map(total).fold<double>(1, (a, b) => a > b ? a : b);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Операций за 7 дней', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 4),
            Row(
              children: [
                _Legend(color: scheme.primary, label: 'приход / выпуск'),
                const SizedBox(width: 12),
                _Legend(color: scheme.tertiary, label: 'расход'),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 140,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (final d in days)
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          if (total(d) > 0) Text(fmtQty(total(d)), style: Theme.of(context).textTheme.labelSmall),
                          const SizedBox(height: 2),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            height: 84 * (total(d) - inCount(d)) / maxV,
                            decoration: BoxDecoration(color: scheme.tertiary, borderRadius: const BorderRadius.vertical(top: Radius.circular(4))),
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            height: 84 * inCount(d) / maxV,
                            color: scheme.primary,
                          ),
                          const SizedBox(height: 4),
                          Text(fmtDay(d), style: Theme.of(context).textTheme.labelSmall),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 4),
        Text(label, style: Theme.of(context).textTheme.labelSmall),
      ],
    );
  }
}

class _ValueSplit extends StatelessWidget {
  final double raw;
  final double product;
  const _ValueSplit({required this.raw, required this.product});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final total = raw + product;
    final rawShare = total == 0 ? 0.5 : raw / total;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Структура запасов', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: SizedBox(
                height: 14,
                child: Row(
                  children: [
                    Expanded(flex: (rawShare * 1000).round().clamp(1, 999), child: Container(color: scheme.primary)),
                    Expanded(flex: ((1 - rawShare) * 1000).round().clamp(1, 999), child: Container(color: scheme.tertiary)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _Legend(color: scheme.primary, label: 'Сырьё ${fmtMoney(raw)}')),
                _Legend(color: scheme.tertiary, label: 'Продукция ${fmtMoney(product)}'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
