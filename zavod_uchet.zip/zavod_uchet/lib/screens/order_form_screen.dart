import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/production_order.dart';
import '../models/recipe_line.dart';
import '../state/app_state.dart';
import '../utils/format.dart';

class OrderFormScreen extends StatefulWidget {
  const OrderFormScreen({super.key});

  @override
  State<OrderFormScreen> createState() => _OrderFormScreenState();
}

class _OrderFormScreenState extends State<OrderFormScreen> {
  final _form = GlobalKey<FormState>();
  final _qty = TextEditingController();
  final _workshop = TextEditingController();
  final _note = TextEditingController();
  int? _productId;
  String _number = '';
  List<RecipeLine> _recipe = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    context.read<AppState>().nextOrderNumber().then((n) {
      if (mounted) setState(() => _number = n);
    });
    _qty.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _qty.dispose();
    _workshop.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _selectProduct(int? id) async {
    setState(() {
      _productId = id;
      _recipe = [];
    });
    if (id == null) return;
    final r = await context.read<AppState>().recipe(id);
    if (mounted && _productId == id) setState(() => _recipe = r);
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    await context.read<AppState>().createOrder(ProductionOrder(
          number: _number,
          productId: _productId!,
          quantity: parseNum(_qty.text)!,
          createdAt: DateTime.now(),
          workshop: _workshop.text.trim(),
          note: _note.text.trim(),
        ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final product = _productId == null ? null : s.itemById(_productId!);
    final qty = parseNum(_qty.text) ?? 0;
    return Scaffold(
      appBar: AppBar(title: Text(_number.isEmpty ? 'Новый заказ' : 'Заказ $_number')),
      body: s.products.isEmpty
          ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Сначала добавьте продукцию на складе', textAlign: TextAlign.center)))
          : Form(
              key: _form,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  DropdownButtonFormField<int>(
                    value: _productId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Продукция'),
                    items: [for (final p in s.products) DropdownMenuItem(value: p.id, child: Text(p.name, overflow: TextOverflow.ellipsis))],
                    onChanged: _selectProduct,
                    validator: (v) => v == null ? 'Выберите продукцию' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _qty,
                    decoration: InputDecoration(labelText: 'Количество к выпуску', suffixText: product?.unit),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: (v) {
                      final n = parseNum(v ?? '');
                      return (n == null || n <= 0) ? 'Введите положительное число' : null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(controller: _workshop, decoration: const InputDecoration(labelText: 'Цех / участок')),
                  const SizedBox(height: 16),
                  TextFormField(controller: _note, decoration: const InputDecoration(labelText: 'Примечание'), maxLines: 2),
                  if (product != null) ...[
                    const SizedBox(height: 20),
                    Text('Потребность в сырье', style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 8),
                    Card(
                      child: _recipe.isEmpty
                          ? const Padding(padding: EdgeInsets.all(16), child: Text('Рецептура не задана'))
                          : Column(
                              children: [
                                for (final l in _recipe)
                                  Builder(builder: (context) {
                                    final have = s.itemById(l.materialId)?.quantity ?? 0;
                                    final need = l.quantity * qty;
                                    final ok = have + 1e-9 >= need;
                                    return ListTile(
                                      dense: true,
                                      leading: Icon(ok ? Icons.check_circle_outline : Icons.error_outline, color: ok ? Colors.green : Theme.of(context).colorScheme.error),
                                      title: Text(l.materialName ?? ''),
                                      subtitle: Text('Норма ${fmtQty(l.quantity)} ${l.materialUnit} · есть ${fmtQty(have)}'),
                                      trailing: Text('${fmtQty(need)} ${l.materialUnit}', style: const TextStyle(fontWeight: FontWeight.w600)),
                                    );
                                  }),
                              ],
                            ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: _saving || _number.isEmpty ? null : _save,
                    icon: const Icon(Icons.check),
                    label: const Text('Создать заказ'),
                  ),
                ],
              ),
            ),
    );
  }
}
