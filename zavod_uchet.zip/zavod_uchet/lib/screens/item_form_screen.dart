import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../state/app_state.dart';
import '../utils/format.dart';

class ItemFormScreen extends StatefulWidget {
  final Item? item;
  const ItemFormScreen({super.key, this.item});

  @override
  State<ItemFormScreen> createState() => _ItemFormScreenState();
}

class _ItemFormScreenState extends State<ItemFormScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _code;
  late final TextEditingController _unit;
  late final TextEditingController _qty;
  late final TextEditingController _min;
  late final TextEditingController _price;
  late ItemKind _kind;
  bool _saving = false;

  static const _units = ['шт', 'кг', 'т', 'м', 'м²', 'м³', 'л', 'компл'];

  bool get _isNew => widget.item == null;

  @override
  void initState() {
    super.initState();
    final i = widget.item;
    _name = TextEditingController(text: i?.name ?? '');
    _code = TextEditingController(text: i?.code ?? '');
    _unit = TextEditingController(text: i?.unit ?? 'шт');
    _qty = TextEditingController(text: i == null ? '' : fmtQty(i.quantity));
    _min = TextEditingController(text: i == null || i.minQuantity == 0 ? '' : i.minQuantity.toString());
    _price = TextEditingController(text: i == null || i.price == 0 ? '' : i.price.toString());
    _kind = i?.kind ?? ItemKind.raw;
  }

  @override
  void dispose() {
    for (final c in [_name, _code, _unit, _qty, _min, _price]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _numValidator(String? v) {
    if (v == null || v.trim().isEmpty) return null;
    final n = parseNum(v);
    if (n == null || n < 0) return 'Введите неотрицательное число';
    return null;
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final base = widget.item;
    final item = Item(
      id: base?.id,
      name: _name.text.trim(),
      code: _code.text.trim(),
      kind: _kind,
      unit: _unit.text.trim(),
      quantity: _isNew ? (parseNum(_qty.text) ?? 0) : base!.quantity,
      minQuantity: parseNum(_min.text) ?? 0,
      price: parseNum(_price.text) ?? 0,
    );
    await context.read<AppState>().saveItem(item);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isNew ? 'Новая позиция' : 'Редактирование')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<ItemKind>(
              segments: [
                for (final k in ItemKind.values) ButtonSegment(value: k, label: Text(k.label)),
              ],
              selected: {_kind},
              onSelectionChanged: (v) => setState(() => _kind = v.first),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Наименование'),
              textCapitalization: TextCapitalization.sentences,
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Обязательное поле' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: _code, decoration: const InputDecoration(labelText: 'Артикул / код')),
            const SizedBox(height: 12),
            TextFormField(
              controller: _unit,
              decoration: const InputDecoration(labelText: 'Единица измерения'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Обязательное поле' : null,
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: [
                for (final u in _units)
                  ActionChip(label: Text(u), onPressed: () => setState(() => _unit.text = u)),
              ],
            ),
            const SizedBox(height: 12),
            if (_isNew) ...[
              TextFormField(
                controller: _qty,
                decoration: const InputDecoration(labelText: 'Начальный остаток'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: _numValidator,
              ),
              const SizedBox(height: 12),
            ],
            TextFormField(
              controller: _min,
              decoration: const InputDecoration(labelText: 'Минимальный остаток', helperText: 'При достижении будет предупреждение'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: _numValidator,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _price,
              decoration: const InputDecoration(labelText: 'Цена за единицу, ₸'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: _numValidator,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.check),
              label: const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
  }
}
