import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/movement.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/movement_tile.dart';

class MovementsScreen extends StatefulWidget {
  const MovementsScreen({super.key});

  @override
  State<MovementsScreen> createState() => _MovementsScreenState();
}

class _MovementsScreenState extends State<MovementsScreen> {
  MovementType? _type;

  Future<void> _confirmDelete(Movement m) async {
    final s = context.read<AppState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Отменить операцию?'),
        content: Text('${m.type.label}: ${m.itemName}, ${fmtQty(m.quantity)} ${m.itemUnit}.\nОстаток будет пересчитан.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Нет')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Отменить операцию')),
        ],
      ),
    );
    if (ok == true) await s.deleteMovement(m);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = _type == null ? s.movements : s.movements.where((m) => m.type == _type).toList();
    final groups = <DateTime, List<Movement>>{};
    for (final m in list) {
      groups.putIfAbsent(DateTime(m.date.year, m.date.month, m.date.day), () => []).add(m);
    }
    return Column(
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Row(
            children: [
              ChoiceChip(label: const Text('Все'), selected: _type == null, onSelected: (_) => setState(() => _type = null)),
              for (final t in MovementType.values) ...[
                const SizedBox(width: 8),
                ChoiceChip(label: Text(t.label), selected: _type == t, onSelected: (_) => setState(() => _type = t)),
              ],
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? const Center(child: Text('Операций нет'))
              : RefreshIndicator(
                  onRefresh: s.load,
                  child: ListView(
                    padding: const EdgeInsets.only(bottom: 88),
                    children: [
                      for (final e in groups.entries) ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                          child: Text(fmtDate(e.key), style: Theme.of(context).textTheme.labelLarge?.copyWith(color: Theme.of(context).colorScheme.primary)),
                        ),
                        for (final m in e.value) MovementTile(movement: m, onLongPress: () => _confirmDelete(m)),
                      ],
                    ],
                  ),
                ),
        ),
      ],
    );
  }
}
