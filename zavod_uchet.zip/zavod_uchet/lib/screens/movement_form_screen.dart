import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/app_database.dart';
import '../models/item.dart';
import '../models/movement.dart';
import '../state/app_state.dart';
import '../utils/format.dart';

class MovementFormScreen extends StatefulWidget {
  final Item? item;
  final MovementType? type;
  const MovementFormScreen({super.key, this.item, this.type});

  @override
  State<MovementFormScreen> createState() => _MovementFormScreenState();
}

class _MovementFormScreenState extends State<MovementFormScreen> {
  final _form = GlobalKey<FormState>();
  final _qty = TextEditingController();
  final _note = TextEditingController();
  late MovementType _type;
  int? _itemId;
  DateTime _date = DateTime.now();
  bool _saving = false;

  static const _manualTypes = [MovementType.income, MovementType.outcome, MovementType.writeOff];

  @override
  void initState() {
    super.initState();
    _type = widget.type ?? MovementType.income;
    _itemId = widget.item?.id;
  }

  @override
  void dispose() {
    _qty.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_date));
    setState(() => _date = DateTime(d.year, d.month, d.day, t?.hour ?? _date.hour, t?.minute ?? _date.minute));
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<AppState>().addMovement(Movement(
            itemId: _itemId!,
            type: _type,
            quantity: parseNum(_qty.text)!,
            date: _date,
            note: _note.text.trim(),
          ));
      if (mounted) Navigator.pop(context);
      messenger.showSnackBar(SnackBar(content: Text('${_type.label} проведён')));
    } on InsufficientStockException catch (e) {
      setState(() => _saving = false);
      messenger.showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final item = _itemId == null ? null : s.itemById(_itemId!);
    return Scaffold(
      appBar: AppBar(title: const Text('Складская операция')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<MovementType>(
              segments: [for (final t in _manualTypes) ButtonSegment(value: t, label: Text(t.label), icon: Icon(t.icon))],
              selected: {_type},
              showSelectedIcon: false,
              onSelectionChanged: (v) => setState(() => _type = v.first),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _itemId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Позиция'),
              items: [
                for (final i in s.items)
                  DropdownMenuItem(value: i.id, child: Text('${i.name} (${i.kind.label.toLowerCase()})', overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _itemId = v),
              validator: (v) => v == null ? 'Выберите позицию' : null,
            ),
            if (item != null)
              Padding(
                padding: const EdgeInsets.only(top: 6, left: 4),
                child: Text('Текущий остаток: ${fmtQty(item.quantity)} ${item.unit}', style: Theme.of(context).textTheme.bodySmall),
              ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _qty,
              autofocus: widget.item != null,
              decoration: InputDecoration(labelText: 'Количество', suffixText: item?.unit),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (v) {
                final n = parseNum(v ?? '');
                if (n == null || n <= 0) return 'Введите положительное число';
                if (!_type.isPositive && item != null && n > item.quantity + 1e-9) {
                  return 'Больше остатка (${fmtQty(item.quantity)})';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: const Text('Дата операции'),
              subtitle: Text(fmtDateTime(_date)),
              onTap: _pickDate,
            ),
            TextFormField(
              controller: _note,
              decoration: InputDecoration(
                labelText: 'Комментарий',
                hintText: _type == MovementType.income ? 'Поставщик, накладная №' : 'Покупатель, причина',
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.check),
              label: const Text('Провести'),
            ),
          ],
        ),
      ),
    );
  }
}
