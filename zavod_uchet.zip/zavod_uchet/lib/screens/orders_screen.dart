import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/app_database.dart';
import '../models/production_order.dart';
import '../models/recipe_line.dart';
import '../state/app_state.dart';
import '../utils/format.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  bool _openOnly = true;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = _openOnly ? s.openOrders : s.orders;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: true, label: Text('Активные')),
              ButtonSegment(value: false, label: Text('Все')),
            ],
            selected: {_openOnly},
            onSelectionChanged: (v) => setState(() => _openOnly = v.first),
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? const Center(child: Text('Производственных заказов нет'))
              : RefreshIndicator(
                  onRefresh: s.load,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                    itemCount: list.length,
                    itemBuilder: (_, i) => _OrderCard(order: list[i]),
                  ),
                ),
        ),
      ],
    );
  }
}

class _OrderCard extends StatelessWidget {
  final ProductionOrder order;
  const _OrderCard({required this.order});

  Future<void> _complete(BuildContext context) async {
    final s = context.read<AppState>();
    final messenger = ScaffoldMessenger.of(context);
    final lines = await s.recipe(order.productId);
    if (!context.mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Выпуск по ${order.number}'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Оприходовать: ${fmtQty(order.quantity)} ${order.productUnit} «${order.productName}»'),
              const SizedBox(height: 12),
              if (lines.isEmpty)
                const Text('Рецептура не задана — сырьё не будет списано.')
              else ...[
                const Text('Будет списано:'),
                const SizedBox(height: 6),
                for (final l in lines) _RequirementRow(line: l, multiplier: order.quantity),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Провести выпуск')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await s.completeOrder(order);
      messenger.showSnackBar(SnackBar(content: Text('Заказ ${order.number} выполнен')));
    } on InsufficientStockException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.toString()), duration: const Duration(seconds: 6)));
    }
  }

  Future<void> _menu(BuildContext context, String action) async {
    final s = context.read<AppState>();
    switch (action) {
      case 'start':
        await s.setOrderStatus(order, OrderStatus.inProgress);
      case 'cancel':
        await s.setOrderStatus(order, OrderStatus.cancelled);
      case 'delete':
        await s.deleteOrder(order);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final statusColor = order.status.color(scheme);
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(order.number, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
                  child: Text(order.status.label, style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
                const Spacer(),
                PopupMenuButton<String>(
                  onSelected: (a) => _menu(context, a),
                  itemBuilder: (_) => [
                    if (order.status == OrderStatus.planned) const PopupMenuItem(value: 'start', child: Text('Взять в работу')),
                    if (order.isOpen) const PopupMenuItem(value: 'cancel', child: Text('Отменить')),
                    if (order.status != OrderStatus.done) const PopupMenuItem(value: 'delete', child: Text('Удалить')),
                  ],
                ),
              ],
            ),
            Text(order.productName ?? '', style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 4),
            Text(
              [
                '${fmtQty(order.quantity)} ${order.productUnit}',
                if (order.workshop.isNotEmpty) order.workshop,
                'от ${fmtDate(order.createdAt)}',
                if (order.completedAt != null) 'выпуск ${fmtDate(order.completedAt!)}',
              ].join(' · '),
              style: Theme.of(context).textTheme.bodySmall,
            ),
            if (order.note.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(order.note, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic)),
            ],
            if (order.isOpen) ...[
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilledButton.icon(
                    onPressed: () => _complete(context),
                    icon: const Icon(Icons.done_all),
                    label: const Text('Выпуск'),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _RequirementRow extends StatelessWidget {
  final RecipeLine line;
  final double multiplier;
  const _RequirementRow({required this.line, required this.multiplier});

  @override
  Widget build(BuildContext context) {
    final have = context.read<AppState>().itemById(line.materialId)?.quantity ?? 0;
    final need = line.quantity * multiplier;
    final ok = have + 1e-9 >= need;
    final color = ok ? null : Theme.of(context).colorScheme.error;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle_outline : Icons.error_outline, size: 16, color: ok ? Colors.green : color),
          const SizedBox(width: 6),
          Expanded(child: Text(line.materialName ?? '', style: TextStyle(color: color))),
          Text('${fmtQty(need)} / ${fmtQty(have)} ${line.materialUnit}', style: TextStyle(color: color, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
