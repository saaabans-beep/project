import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'movement_form_screen.dart';
import 'movements_screen.dart';
import 'orders_screen.dart';
import 'order_form_screen.dart';
import 'stock_screen.dart';
import 'item_form_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  static const _titles = ['Сводка', 'Склад', 'Движения', 'Производство'];

  void _go(int i) => setState(() => _index = i);

  Widget? _fab() {
    switch (_index) {
      case 1:
        return FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ItemFormScreen())),
          icon: const Icon(Icons.add),
          label: const Text('Позиция'),
        );
      case 2:
        return FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MovementFormScreen())),
          icon: const Icon(Icons.swap_vert),
          label: const Text('Операция'),
        );
      case 3:
        return FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderFormScreen())),
          icon: const Icon(Icons.add_task),
          label: const Text('Заказ'),
        );
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(onNavigate: _go),
      const StockScreen(),
      const MovementsScreen(),
      const OrdersScreen(),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(_titles[_index])),
      body: IndexedStack(index: _index, children: pages),
      floatingActionButton: _fab(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _go,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Сводка'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Склад'),
          NavigationDestination(icon: Icon(Icons.swap_vert), label: 'Движения'),
          NavigationDestination(icon: Icon(Icons.factory_outlined), selectedIcon: Icon(Icons.factory), label: 'Производство'),
        ],
      ),
    );
  }
}
