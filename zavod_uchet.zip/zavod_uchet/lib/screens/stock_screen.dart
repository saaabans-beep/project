import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import 'item_detail_screen.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  String _query = '';
  ItemKind? _kind;
  bool _lowOnly = false;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final q = _query.toLowerCase();
    final list = s.items.where((i) {
      if (_kind != null && i.kind != _kind) return false;
      if (_lowOnly && !i.isLow) return false;
      if (q.isEmpty) return true;
      return i.name.toLowerCase().contains(q) || i.code.toLowerCase().contains(q);
    }).toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: SearchBar(
            hintText: 'Поиск по названию или артикулу',
            leading: const Icon(Icons.search),
            elevation: const WidgetStatePropertyAll(0),
            onChanged: (v) => setState(() => _query = v),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              ChoiceChip(label: const Text('Все'), selected: _kind == null, onSelected: (_) => setState(() => _kind = null)),
              const SizedBox(width: 8),
              for (final k in ItemKind.values) ...[
                ChoiceChip(label: Text(k.label), selected: _kind == k, onSelected: (_) => setState(() => _kind = k)),
                const SizedBox(width: 8),
              ],
              FilterChip(
                label: const Text('Ниже минимума'),
                selected: _lowOnly,
                onSelected: (v) => setState(() => _lowOnly = v),
              ),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? const Center(child: Text('Ничего не найдено'))
              : RefreshIndicator(
                  onRefresh: s.load,
                  child: ListView.separated(
                    padding: const EdgeInsets.only(bottom: 88),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
                    itemBuilder: (_, i) => _ItemTile(item: list[i]),
                  ),
                ),
        ),
      ],
    );
  }
}

class _ItemTile extends StatelessWidget {
  final Item item;
  const _ItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isRaw = item.kind == ItemKind.raw;
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: isRaw ? scheme.primaryContainer : scheme.tertiaryContainer,
        child: Icon(isRaw ? Icons.category_outlined : Icons.widgets_outlined, color: isRaw ? scheme.onPrimaryContainer : scheme.onTertiaryContainer),
      ),
      title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text([if (item.code.isNotEmpty) item.code, fmtMoney(item.totalValue)].join(' · ')),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '${fmtQty(item.quantity)} ${item.unit}',
            style: TextStyle(fontWeight: FontWeight.w600, color: item.isLow ? scheme.error : null),
          ),
          if (item.isLow) Text('мин. ${fmtQty(item.minQuantity)}', style: TextStyle(fontSize: 11, color: scheme.error)),
        ],
      ),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemDetailScreen(itemId: item.id!))),
    );
  }
}
