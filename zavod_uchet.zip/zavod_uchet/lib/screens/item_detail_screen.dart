import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../models/movement.dart';
import '../models/recipe_line.dart';
import '../state/app_state.dart';
import '../utils/format.dart';
import '../widgets/movement_tile.dart';
import 'item_form_screen.dart';
import 'movement_form_screen.dart';

class ItemDetailScreen extends StatelessWidget {
  final int itemId;
  const ItemDetailScreen({super.key, required this.itemId});

  Future<void> _delete(BuildContext context, Item item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Удалить позицию?'),
        content: Text('«${item.name}» и вся история движений будут удалены.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      final state = context.read<AppState>();
      Navigator.pop(context);
      await state.deleteItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final item = s.itemById(itemId);
    if (item == null) return const Scaffold(body: SizedBox.shrink());
    final scheme = Theme.of(context).colorScheme;
    final isProduct = item.kind == ItemKind.product;
    return DefaultTabController(
      length: isProduct ? 2 : 1,
      child: Scaffold(
        appBar: AppBar(
          title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemFormScreen(item: item))),
            ),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(context, item)),
          ],
        ),
        body: NestedScrollView(
          headerSliverBuilder: (_, __) => [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Card(
                  color: item.isLow ? scheme.errorContainer : scheme.surfaceContainerHigh,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${item.kind.label}${item.code.isNotEmpty ? ' · ${item.code}' : ''}', style: Theme.of(context).textTheme.labelLarge),
                        const SizedBox(height: 8),
                        Text('${fmtQty(item.quantity)} ${item.unit}', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 16,
                          runSpacing: 4,
                          children: [
                            Text('Мин.: ${fmtQty(item.minQuantity)} ${item.unit}'),
                            Text('Цена: ${fmtMoney(item.price)}'),
                            Text('Сумма: ${fmtMoney(item.totalValue)}'),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.tonalIcon(
                                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MovementFormScreen(item: item, type: MovementType.income))),
                                icon: const Icon(Icons.add),
                                label: const Text('Приход'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton.tonalIcon(
                                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MovementFormScreen(item: item, type: isProduct ? MovementType.outcome : MovementType.writeOff))),
                                icon: const Icon(Icons.remove),
                                label: Text(isProduct ? 'Отгрузка' : 'Списание'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            if (isProduct)
              const SliverToBoxAdapter(
                child: TabBar(tabs: [Tab(text: 'История'), Tab(text: 'Рецептура')]),
              ),
          ],
          body: isProduct
              ? TabBarView(children: [_History(item: item), _Recipe(product: item)])
              : _History(item: item),
        ),
      ),
    );
  }
}

class _History extends StatelessWidget {
  final Item item;
  const _History({required this.item});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return FutureBuilder<List<Movement>>(
      future: s.itemMovements(item.id!),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final list = snap.data!;
        if (list.isEmpty) return const Center(child: Text('Движений нет'));
        return ListView.builder(
          padding: EdgeInsets.zero,
          itemCount: list.length,
          itemBuilder: (_, i) => MovementTile(movement: list[i], showItem: false),
        );
      },
    );
  }
}

class _Recipe extends StatelessWidget {
  final Item product;
  const _Recipe({required this.product});

  Future<void> _edit(BuildContext context, List<RecipeLine> current, [RecipeLine? line]) async {
    final s = context.read<AppState>();
    final used = current.map((l) => l.materialId).toSet();
    final materials = s.rawMaterials.where((m) => line != null ? m.id == line.materialId : !used.contains(m.id)).toList();
    if (materials.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Нет доступного сырья для добавления')));
      return;
    }
    int materialId = line?.materialId ?? materials.first.id!;
    final qty = TextEditingController(text: line == null ? '' : fmtQty(line.quantity));
    final result = await showDialog<RecipeLine>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(line == null ? 'Добавить компонент' : 'Норма расхода'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                value: materialId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Сырьё'),
                items: [for (final m in materials) DropdownMenuItem(value: m.id, child: Text(m.name, overflow: TextOverflow.ellipsis))],
                onChanged: line != null ? null : (v) => set(() => materialId = v!),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: qty,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: 'Расход на 1 ${product.unit}',
                  suffixText: s.itemById(materialId)?.unit,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('Отмена')),
            FilledButton(
              onPressed: () {
                final v = parseNum(qty.text);
                if (v == null || v <= 0) return;
                Navigator.pop(c, RecipeLine(productId: product.id!, materialId: materialId, quantity: v));
              },
              child: const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
    if (result != null) await s.saveRecipeLine(result);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return FutureBuilder<List<RecipeLine>>(
      future: s.recipe(product.id!),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final lines = snap.data!;
        final cost = lines.fold<double>(0, (sum, l) => sum + l.quantity * (s.itemById(l.materialId)?.price ?? 0));
        return ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            if (lines.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Рецептура не задана. Без неё выпуск продукции не будет списывать сырьё.', textAlign: TextAlign.center),
              ),
            for (final l in lines)
              Dismissible(
                key: ValueKey(l.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  color: Theme.of(context).colorScheme.errorContainer,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  child: const Icon(Icons.delete_outline),
                ),
                onDismissed: (_) => s.deleteRecipeLine(l.id!),
                child: ListTile(
                  leading: const Icon(Icons.category_outlined),
                  title: Text(l.materialName ?? ''),
                  subtitle: Text('Остаток: ${fmtQty(s.itemById(l.materialId)?.quantity ?? 0)} ${l.materialUnit}'),
                  trailing: Text('${fmtQty(l.quantity)} ${l.materialUnit}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  onTap: () => _edit(context, lines, l),
                ),
              ),
            if (lines.isNotEmpty)
              ListTile(
                title: const Text('Себестоимость сырья на 1 ед.'),
                trailing: Text(fmtMoney(cost), style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: OutlinedButton.icon(
                onPressed: () => _edit(context, lines),
                icon: const Icon(Icons.add),
                label: const Text('Добавить компонент'),
              ),
            ),
          ],
        );
      },
    );
  }
}
