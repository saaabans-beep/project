enum ItemKind { raw, product }

extension ItemKindX on ItemKind {
  String get label => this == ItemKind.raw ? 'Сырьё' : 'Продукция';
}

class Item {
  final int? id;
  final String name;
  final String code;
  final ItemKind kind;
  final String unit;
  final double quantity;
  final double minQuantity;
  final double price;

  const Item({
    this.id,
    required this.name,
    required this.code,
    required this.kind,
    required this.unit,
    this.quantity = 0,
    this.minQuantity = 0,
    this.price = 0,
  });

  bool get isLow => minQuantity > 0 && quantity <= minQuantity;
  double get totalValue => quantity * price;

  Item copyWith({
    int? id,
    String? name,
    String? code,
    ItemKind? kind,
    String? unit,
    double? quantity,
    double? minQuantity,
    double? price,
  }) {
    return Item(
      id: id ?? this.id,
      name: name ?? this.name,
      code: code ?? this.code,
      kind: kind ?? this.kind,
      unit: unit ?? this.unit,
      quantity: quantity ?? this.quantity,
      minQuantity: minQuantity ?? this.minQuantity,
      price: price ?? this.price,
    );
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'code': code,
        'kind': kind.index,
        'unit': unit,
        'quantity': quantity,
        'min_quantity': minQuantity,
        'price': price,
      };

  factory Item.fromMap(Map<String, Object?> m) => Item(
        id: m['id'] as int?,
        name: m['name'] as String,
        code: (m['code'] as String?) ?? '',
        kind: ItemKind.values[m['kind'] as int],
        unit: m['unit'] as String,
        quantity: (m['quantity'] as num).toDouble(),
        minQuantity: (m['min_quantity'] as num).toDouble(),
        price: (m['price'] as num).toDouble(),
      );
}
