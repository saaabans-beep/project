import 'package:flutter/material.dart';

enum OrderStatus { planned, inProgress, done, cancelled }

extension OrderStatusX on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.planned:
        return 'Запланирован';
      case OrderStatus.inProgress:
        return 'В работе';
      case OrderStatus.done:
        return 'Выполнен';
      case OrderStatus.cancelled:
        return 'Отменён';
    }
  }

  Color color(ColorScheme scheme) {
    switch (this) {
      case OrderStatus.planned:
        return scheme.secondary;
      case OrderStatus.inProgress:
        return Colors.orange;
      case OrderStatus.done:
        return Colors.green;
      case OrderStatus.cancelled:
        return scheme.outline;
    }
  }
}

class ProductionOrder {
  final int? id;
  final String number;
  final int productId;
  final double quantity;
  final DateTime createdAt;
  final DateTime? completedAt;
  final OrderStatus status;
  final String workshop;
  final String note;
  final String? productName;
  final String? productUnit;

  const ProductionOrder({
    this.id,
    required this.number,
    required this.productId,
    required this.quantity,
    required this.createdAt,
    this.completedAt,
    this.status = OrderStatus.planned,
    this.workshop = '',
    this.note = '',
    this.productName,
    this.productUnit,
  });

  bool get isOpen => status == OrderStatus.planned || status == OrderStatus.inProgress;

  ProductionOrder copyWith({OrderStatus? status, DateTime? completedAt}) {
    return ProductionOrder(
      id: id,
      number: number,
      productId: productId,
      quantity: quantity,
      createdAt: createdAt,
      completedAt: completedAt ?? this.completedAt,
      status: status ?? this.status,
      workshop: workshop,
      note: note,
      productName: productName,
      productUnit: productUnit,
    );
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'number': number,
        'product_id': productId,
        'quantity': quantity,
        'created_at': createdAt.millisecondsSinceEpoch,
        'completed_at': completedAt?.millisecondsSinceEpoch,
        'status': status.index,
        'workshop': workshop,
        'note': note,
      };

  factory ProductionOrder.fromMap(Map<String, Object?> m) => ProductionOrder(
        id: m['id'] as int?,
        number: m['number'] as String,
        productId: m['product_id'] as int,
        quantity: (m['quantity'] as num).toDouble(),
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
        completedAt: m['completed_at'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(m['completed_at'] as int),
        status: OrderStatus.values[m['status'] as int],
        workshop: (m['workshop'] as String?) ?? '',
        note: (m['note'] as String?) ?? '',
        productName: m['product_name'] as String?,
        productUnit: m['product_unit'] as String?,
      );
}
