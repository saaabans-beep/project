import 'package:flutter/material.dart';

enum MovementType { income, outcome, productionIn, productionOut, writeOff }

extension MovementTypeX on MovementType {
  String get label {
    switch (this) {
      case MovementType.income:
        return 'Приход';
      case MovementType.outcome:
        return 'Отгрузка';
      case MovementType.productionIn:
        return 'Выпуск';
      case MovementType.productionOut:
        return 'Списание в производство';
      case MovementType.writeOff:
        return 'Брак / списание';
    }
  }

  bool get isPositive => this == MovementType.income || this == MovementType.productionIn;

  IconData get icon {
    switch (this) {
      case MovementType.income:
        return Icons.south_west;
      case MovementType.outcome:
        return Icons.north_east;
      case MovementType.productionIn:
        return Icons.precision_manufacturing;
      case MovementType.productionOut:
        return Icons.settings_input_component;
      case MovementType.writeOff:
        return Icons.delete_sweep;
    }
  }
}

class Movement {
  final int? id;
  final int itemId;
  final MovementType type;
  final double quantity;
  final DateTime date;
  final String note;
  final int? orderId;
  final String? itemName;
  final String? itemUnit;

  const Movement({
    this.id,
    required this.itemId,
    required this.type,
    required this.quantity,
    required this.date,
    this.note = '',
    this.orderId,
    this.itemName,
    this.itemUnit,
  });

  double get signedQuantity => type.isPositive ? quantity : -quantity;

  Map<String, Object?> toMap() => {
        'id': id,
        'item_id': itemId,
        'type': type.index,
        'quantity': quantity,
        'date': date.millisecondsSinceEpoch,
        'note': note,
        'order_id': orderId,
      };

  factory Movement.fromMap(Map<String, Object?> m) => Movement(
        id: m['id'] as int?,
        itemId: m['item_id'] as int,
        type: MovementType.values[m['type'] as int],
        quantity: (m['quantity'] as num).toDouble(),
        date: DateTime.fromMillisecondsSinceEpoch(m['date'] as int),
        note: (m['note'] as String?) ?? '',
        orderId: m['order_id'] as int?,
        itemName: m['item_name'] as String?,
        itemUnit: m['item_unit'] as String?,
      );
}
