class RecipeLine {
  final int? id;
  final int productId;
  final int materialId;
  final double quantity;
  final String? materialName;
  final String? materialUnit;

  const RecipeLine({
    this.id,
    required this.productId,
    required this.materialId,
    required this.quantity,
    this.materialName,
    this.materialUnit,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'product_id': productId,
        'material_id': materialId,
        'quantity': quantity,
      };

  factory RecipeLine.fromMap(Map<String, Object?> m) => RecipeLine(
        id: m['id'] as int?,
        productId: m['product_id'] as int,
        materialId: m['material_id'] as int,
        quantity: (m['quantity'] as num).toDouble(),
        materialName: m['material_name'] as String?,
        materialUnit: m['material_unit'] as String?,
      );
}
