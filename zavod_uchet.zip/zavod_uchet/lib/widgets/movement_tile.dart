import 'package:flutter/material.dart';
import '../models/movement.dart';
import '../utils/format.dart';

class MovementTile extends StatelessWidget {
  final Movement movement;
  final bool showItem;
  final VoidCallback? onLongPress;

  const MovementTile({super.key, required this.movement, this.showItem = true, this.onLongPress});

  @override
  Widget build(BuildContext context) {
    final m = movement;
    final positive = m.type.isPositive;
    final color = positive ? Colors.green.shade600 : Theme.of(context).colorScheme.error;
    final sub = [m.type.label, fmtDateTime(m.date), if (m.note.isNotEmpty) m.note].join(' · ');
    return ListTile(
      onLongPress: onLongPress,
      leading: CircleAvatar(
        backgroundColor: color.withValues(alpha: 0.12),
        child: Icon(m.type.icon, color: color, size: 20),
      ),
      title: Text(showItem ? (m.itemName ?? '') : m.type.label, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(showItem ? sub : [fmtDateTime(m.date), if (m.note.isNotEmpty) m.note].join(' · '), maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: Text(
        '${positive ? '+' : '−'}${fmtQty(m.quantity)} ${m.itemUnit ?? ''}',
        style: TextStyle(color: color, fontWeight: FontWeight.w600),
      ),
    );
  }
}
