import 'package:intl/intl.dart';

final _qty = NumberFormat('#,##0.##', 'ru');
final _money = NumberFormat.currency(locale: 'ru', symbol: '₸', decimalDigits: 0);
final _date = DateFormat('dd.MM.yyyy', 'ru');
final _dateTime = DateFormat('dd.MM.yyyy HH:mm', 'ru');
final _dayShort = DateFormat('E', 'ru');

String fmtQty(double v) => _qty.format(v);
String fmtMoney(double v) => _money.format(v);
String fmtDate(DateTime d) => _date.format(d);
String fmtDateTime(DateTime d) => _dateTime.format(d);
String fmtDay(DateTime d) => _dayShort.format(d);

double? parseNum(String s) => double.tryParse(s.trim().replaceAll(' ', '').replaceAll(',', '.'));
