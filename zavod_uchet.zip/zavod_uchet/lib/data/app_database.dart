import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/item.dart';
import '../models/movement.dart';
import '../models/production_order.dart';
import '../models/recipe_line.dart';

class InsufficientStockException implements Exception {
  final List<String> lines;
  InsufficientStockException(this.lines);

  @override
  String toString() => 'Недостаточно сырья:\n${lines.join('\n')}';
}

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, 'zavod_uchet.db'),
      version: 1,
      onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT NOT NULL DEFAULT '',
            kind INTEGER NOT NULL,
            unit TEXT NOT NULL,
            quantity REAL NOT NULL DEFAULT 0,
            min_quantity REAL NOT NULL DEFAULT 0,
            price REAL NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE movements(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            type INTEGER NOT NULL,
            quantity REAL NOT NULL,
            date INTEGER NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            order_id INTEGER
          )
        ''');
        await db.execute('''
          CREATE TABLE recipes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            material_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            quantity REAL NOT NULL,
            UNIQUE(product_id, material_id)
          )
        ''');
        await db.execute('''
          CREATE TABLE orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            number TEXT NOT NULL,
            product_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            quantity REAL NOT NULL,
            created_at INTEGER NOT NULL,
            completed_at INTEGER,
            status INTEGER NOT NULL,
            workshop TEXT NOT NULL DEFAULT '',
            note TEXT NOT NULL DEFAULT ''
          )
        ''');
        await db.execute('CREATE INDEX idx_mov_item ON movements(item_id)');
        await db.execute('CREATE INDEX idx_mov_date ON movements(date)');
        await _seed(db);
      },
    );
  }

  Future<void> _seed(Database db) async {
    final steel = await db.insert('items', const Item(name: 'Лист стальной 2 мм', code: 'RM-001', kind: ItemKind.raw, unit: 'кг', quantity: 1200, minQuantity: 300, price: 650).toMap());
    final paint = await db.insert('items', const Item(name: 'Краска порошковая', code: 'RM-002', kind: ItemKind.raw, unit: 'кг', quantity: 80, minQuantity: 50, price: 3200).toMap());
    final bolt = await db.insert('items', const Item(name: 'Болт М8', code: 'RM-003', kind: ItemKind.raw, unit: 'шт', quantity: 5000, minQuantity: 1000, price: 25).toMap());
    final box = await db.insert('items', const Item(name: 'Шкаф электрический ШР-1', code: 'PR-001', kind: ItemKind.product, unit: 'шт', quantity: 12, minQuantity: 5, price: 85000).toMap());
    final shelf = await db.insert('items', const Item(name: 'Стеллаж складской С-2', code: 'PR-002', kind: ItemKind.product, unit: 'шт', quantity: 4, minQuantity: 5, price: 42000).toMap());
    for (final r in [
      [box, steel, 25.0],
      [box, paint, 1.2],
      [box, bolt, 16.0],
      [shelf, steel, 18.0],
      [shelf, paint, 0.8],
      [shelf, bolt, 24.0],
    ]) {
      await db.insert('recipes', {'product_id': r[0], 'material_id': r[1], 'quantity': r[2]});
    }
    final now = DateTime.now();
    for (final m in [
      Movement(itemId: steel, type: MovementType.income, quantity: 1200, date: now.subtract(const Duration(days: 3)), note: 'Начальный остаток'),
      Movement(itemId: paint, type: MovementType.income, quantity: 80, date: now.subtract(const Duration(days: 3)), note: 'Начальный остаток'),
      Movement(itemId: bolt, type: MovementType.income, quantity: 5000, date: now.subtract(const Duration(days: 3)), note: 'Начальный остаток'),
      Movement(itemId: box, type: MovementType.income, quantity: 12, date: now.subtract(const Duration(days: 3)), note: 'Начальный остаток'),
      Movement(itemId: shelf, type: MovementType.income, quantity: 4, date: now.subtract(const Duration(days: 3)), note: 'Начальный остаток'),
    ]) {
      await db.insert('movements', m.toMap());
    }
  }

  Future<List<Item>> items() async {
    final rows = await (await db).query('items', orderBy: 'kind, name COLLATE NOCASE');
    return rows.map(Item.fromMap).toList();
  }

  Future<int> saveItem(Item item) async {
    final d = await db;
    if (item.id == null) {
      final map = item.toMap()..remove('id');
      return d.transaction((txn) async {
        final id = await txn.insert('items', map);
        if (item.quantity > 0) {
          await txn.insert(
            'movements',
            Movement(itemId: id, type: MovementType.income, quantity: item.quantity, date: DateTime.now(), note: 'Начальный остаток').toMap(),
          );
        }
        return id;
      });
    }
    final map = item.toMap()..remove('quantity');
    await d.update('items', map, where: 'id = ?', whereArgs: [item.id]);
    return item.id!;
  }

  Future<void> deleteItem(int id) async {
    await (await db).delete('items', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Movement>> movements({int? itemId, int limit = 500}) async {
    final rows = await (await db).rawQuery('''
      SELECT m.*, i.name AS item_name, i.unit AS item_unit
      FROM movements m JOIN items i ON i.id = m.item_id
      ${itemId != null ? 'WHERE m.item_id = ?' : ''}
      ORDER BY m.date DESC, m.id DESC
      LIMIT $limit
    ''', itemId != null ? [itemId] : []);
    return rows.map(Movement.fromMap).toList();
  }

  Future<void> _applyMovement(Transaction txn, Movement m, {bool allowNegative = false}) async {
    final rows = await txn.query('items', columns: ['quantity', 'name', 'unit'], where: 'id = ?', whereArgs: [m.itemId]);
    if (rows.isEmpty) throw StateError('Позиция не найдена');
    final current = (rows.first['quantity'] as num).toDouble();
    final next = current + m.signedQuantity;
    if (!allowNegative && next < -1e-9) {
      throw InsufficientStockException(['${rows.first['name']}: остаток $current ${rows.first['unit']}, требуется ${m.quantity}']);
    }
    await txn.update('items', {'quantity': next}, where: 'id = ?', whereArgs: [m.itemId]);
    await txn.insert('movements', m.toMap()..remove('id'));
  }

  Future<void> addMovement(Movement m) async {
    await (await db).transaction((txn) => _applyMovement(txn, m));
  }

  Future<void> deleteMovement(Movement m) async {
    await (await db).transaction((txn) async {
      await txn.rawUpdate('UPDATE items SET quantity = quantity - ? WHERE id = ?', [m.signedQuantity, m.itemId]);
      await txn.delete('movements', where: 'id = ?', whereArgs: [m.id]);
    });
  }

  Future<List<RecipeLine>> recipe(int productId) async {
    final rows = await (await db).rawQuery('''
      SELECT r.*, i.name AS material_name, i.unit AS material_unit
      FROM recipes r JOIN items i ON i.id = r.material_id
      WHERE r.product_id = ?
      ORDER BY i.name COLLATE NOCASE
    ''', [productId]);
    return rows.map(RecipeLine.fromMap).toList();
  }

  Future<void> saveRecipeLine(RecipeLine line) async {
    await (await db).insert('recipes', line.toMap()..remove('id'), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteRecipeLine(int id) async {
    await (await db).delete('recipes', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ProductionOrder>> orders() async {
    final rows = await (await db).rawQuery('''
      SELECT o.*, i.name AS product_name, i.unit AS product_unit
      FROM orders o JOIN items i ON i.id = o.product_id
      ORDER BY o.status IN (2, 3), o.created_at DESC
    ''');
    return rows.map(ProductionOrder.fromMap).toList();
  }

  Future<String> nextOrderNumber() async {
    final r = await (await db).rawQuery('SELECT COUNT(*) AS c FROM orders');
    final n = ((r.first['c'] as int?) ?? 0) + 1;
    return 'ПЗ-${n.toString().padLeft(4, '0')}';
  }

  Future<int> createOrder(ProductionOrder o) async {
    return (await db).insert('orders', o.toMap()..remove('id'));
  }

  Future<void> setOrderStatus(ProductionOrder o, OrderStatus status) async {
    await (await db).update('orders', {'status': status.index}, where: 'id = ?', whereArgs: [o.id]);
  }

  Future<void> deleteOrder(int id) async {
    await (await db).delete('orders', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> completeOrder(ProductionOrder o) async {
    final lines = await recipe(o.productId);
    await (await db).transaction((txn) async {
      final shortages = <String>[];
      for (final l in lines) {
        final need = l.quantity * o.quantity;
        final rows = await txn.query('items', columns: ['quantity'], where: 'id = ?', whereArgs: [l.materialId]);
        final have = (rows.first['quantity'] as num).toDouble();
        if (have + 1e-9 < need) {
          shortages.add('${l.materialName}: нужно ${_fmt(need)}, есть ${_fmt(have)} ${l.materialUnit}');
        }
      }
      if (shortages.isNotEmpty) throw InsufficientStockException(shortages);
      final now = DateTime.now();
      for (final l in lines) {
        await _applyMovement(
          txn,
          Movement(itemId: l.materialId, type: MovementType.productionOut, quantity: l.quantity * o.quantity, date: now, note: 'Заказ ${o.number}', orderId: o.id),
        );
      }
      await _applyMovement(
        txn,
        Movement(itemId: o.productId, type: MovementType.productionIn, quantity: o.quantity, date: now, note: 'Заказ ${o.number}', orderId: o.id),
      );
      await txn.update(
        'orders',
        {'status': OrderStatus.done.index, 'completed_at': now.millisecondsSinceEpoch},
        where: 'id = ?',
        whereArgs: [o.id],
      );
    });
  }

  Future<Map<DateTime, Map<MovementType, double>>> dailyStats(int days) async {
    final from = DateTime.now().subtract(Duration(days: days - 1));
    final start = DateTime(from.year, from.month, from.day);
    final rows = await (await db).query('movements', where: 'date >= ?', whereArgs: [start.millisecondsSinceEpoch]);
    final result = <DateTime, Map<MovementType, double>>{};
    for (var i = 0; i < days; i++) {
      result[start.add(Duration(days: i))] = {};
    }
    for (final r in rows) {
      final m = Movement.fromMap(r);
      final key = DateTime(m.date.year, m.date.month, m.date.day);
      final bucket = result[key];
      if (bucket == null) continue;
      bucket[m.type] = (bucket[m.type] ?? 0) + 1;
    }
    return result;
  }

  static String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
}
