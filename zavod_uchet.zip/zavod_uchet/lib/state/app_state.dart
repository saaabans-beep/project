import 'package:flutter/foundation.dart';
import '../data/app_database.dart';
import '../models/item.dart';
import '../models/movement.dart';
import '../models/production_order.dart';
import '../models/recipe_line.dart';

class AppState extends ChangeNotifier {
  final AppDatabase _db = AppDatabase.instance;

  bool loading = true;
  List<Item> items = [];
  List<Movement> movements = [];
  List<ProductionOrder> orders = [];
  Map<DateTime, Map<MovementType, double>> weekStats = {};

  List<Item> get rawMaterials => items.where((i) => i.kind == ItemKind.raw).toList();
  List<Item> get products => items.where((i) => i.kind == ItemKind.product).toList();
  List<Item> get lowStock => items.where((i) => i.isLow).toList();
  List<ProductionOrder> get openOrders => orders.where((o) => o.isOpen).toList();
  double get stockValue => items.fold(0, (s, i) => s + i.totalValue);
  double valueOf(ItemKind kind) => items.where((i) => i.kind == kind).fold(0, (s, i) => s + i.totalValue);

  Item? itemById(int id) {
    for (final i in items) {
      if (i.id == id) return i;
    }
    return null;
  }

  Future<void> load() async {
    items = await _db.items();
    movements = await _db.movements();
    orders = await _db.orders();
    weekStats = await _db.dailyStats(7);
    loading = false;
    notifyListeners();
  }

  Future<void> saveItem(Item item) async {
    await _db.saveItem(item);
    await load();
  }

  Future<void> deleteItem(Item item) async {
    await _db.deleteItem(item.id!);
    await load();
  }

  Future<void> addMovement(Movement m) async {
    await _db.addMovement(m);
    await load();
  }

  Future<void> deleteMovement(Movement m) async {
    await _db.deleteMovement(m);
    await load();
  }

  Future<List<Movement>> itemMovements(int itemId) => _db.movements(itemId: itemId);

  Future<List<RecipeLine>> recipe(int productId) => _db.recipe(productId);

  Future<void> saveRecipeLine(RecipeLine line) async {
    await _db.saveRecipeLine(line);
    notifyListeners();
  }

  Future<void> deleteRecipeLine(int id) async {
    await _db.deleteRecipeLine(id);
    notifyListeners();
  }

  Future<String> nextOrderNumber() => _db.nextOrderNumber();

  Future<void> createOrder(ProductionOrder o) async {
    await _db.createOrder(o);
    await load();
  }

  Future<void> setOrderStatus(ProductionOrder o, OrderStatus s) async {
    await _db.setOrderStatus(o, s);
    await load();
  }

  Future<void> completeOrder(ProductionOrder o) async {
    await _db.completeOrder(o);
    await load();
  }

  Future<void> deleteOrder(ProductionOrder o) async {
    await _db.deleteOrder(o.id!);
    await load();
  }
}
